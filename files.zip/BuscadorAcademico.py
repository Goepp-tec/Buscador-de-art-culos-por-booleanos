#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Buscador Académico Booleano 2.0  (un solo archivo, sin instalar nada)
=====================================================================

Convierte una pregunta escrita en español en una ecuación booleana, pide aclaraciones
cuando falta información, busca en PubMed, Europe PMC y OpenAlex (APIs públicas y
gratuitas), abre la misma búsqueda en SciELO, BVS/LILACS, Google Académico y
ScienceDirect, y genera citas en formato APA 7.

CÓMO ABRIRLO
  * Windows: doble clic en "Abrir_Buscador_Windows.bat".
  * macOS:   doble clic en "Abrir_Buscador_Mac.command".
  * Terminal: python3 BuscadorAcademico.py
  El programa abre una pestaña en tu navegador. Todo se ejecuta en tu computadora:
  la pestaña solo se comunica con este programa (dirección 127.0.0.1).

REQUISITOS
  Python 3.9 o superior (https://www.python.org/downloads/). Solo usa la biblioteca
  estándar: http.server para la interfaz, urllib para internet y json para guardar datos.

ARQUITECTURA (resumen)
  1. Motor de traducción local basado en reglas (PARTE 2):
     normalización -> detección de años -> emparejamiento con un diccionario de conceptos
     (el más largo gana) -> negaciones ("sin", "excepto") -> enlaces "o" entre conceptos
     -> términos desconocidos (corrector ortográfico + cognados) -> preguntas PICO
     -> ecuación: OR entre sinónimos de un concepto, AND entre conceptos, NOT al final.
     Sigue la guía de Lane Library (Stanford): MeSH + palabras de texto [tw],
     sinónimos entre paréntesis, truncamiento de 4+ letras, frases entre comillas.
  2. Revisor de sintaxis (PARTE 3): avisa de paréntesis o comillas abiertas, operadores
     en minúsculas, mezclas AND/OR sin paréntesis y truncamientos demasiado cortos.
  3. Búsqueda (PARTE 4): E-utilities de PubMed, Europe PMC, OpenAlex y Crossref (DOI).
  4. Citas APA 7 en español o inglés (PARTE 5) y lista de Citados guardada en disco (PARTE 6).
  5. Servidor local + interfaz web (PARTES 7 y 8).

  Para integrar un modelo local (Ollama) sin cambiar el resto: reemplaza extract() por una
  llamada a http://localhost:11434/api/generate que devuelva los conceptos en JSON y
  conserva build_rows()/render_query(), que son los que garantizan una sintaxis válida.

DATOS DEL USUARIO
  Referencias guardadas:  <carpeta personal>/BuscadorAcademico/citados.json
  Registro de errores:    <carpeta personal>/BuscadorAcademico/errores.log

OPCIONES
  python3 BuscadorAcademico.py --prueba          prueba el motor sin internet
  python3 BuscadorAcademico.py --sin-navegador   no abre el navegador automáticamente
"""
from __future__ import annotations

import difflib
import itertools
import json
import os
import platform
import re
import ssl
import sys
import threading
import time
import traceback
import unicodedata
import webbrowser
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from itertools import zip_longest
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, quote_plus, urlencode, urlparse
from urllib.request import Request, urlopen

APP_NAME = "Buscador Académico"
APP_VERSION = "3.0"
DATA_DIR = Path.home() / "BuscadorAcademico"
CITED_FILE = DATA_DIR / "citados.json"
LOG_FILE = DATA_DIR / "errores.log"
HIST_FILE = DATA_DIR / "historial.json"
CURRENT_YEAR = date.today().year


# ============================================================================
# PARTE 1. DICCIONARIO (español -> MeSH + palabras de texto en inglés)
#   Para ampliar el buscador, agrega conceptos aquí.
#   es:    frases en español, en minúsculas y SIN acentos.
#   mesh:  encabezados MeSH (se buscan con [Mesh]; al excluir, con [Majr]).
#   sh:    subencabezados MeSH (solo PubMed, ej. "therapy"[sh]).
#   pt:    tipos de publicación de PubMed ([pt]).
#   terms: sinónimos en inglés para título/resumen ([tw]). El * trunca: mínimo 4 letras antes.
#   core:  1-2 términos principales para bases que no aceptan ecuaciones largas.
# ============================================================================
CONCEPTS: dict[str, dict] = {
    # ------------------------------------------------------------------ CONDICIONES
    "hypertension": {
        "cat": "condition", "label": "Hipertensión",
        "es": ["hipertension", "hipertension arterial", "presion alta", "presion arterial alta", "tension alta"],
        "mesh": ["Hypertension"], "terms": ["hypertens*", "high blood pressure"], "core": ["hypertension"],
    },
    "preeclampsia": {
        "cat": "condition", "label": "Preeclampsia / hipertensión gestacional",
        "es": ["preeclampsia", "pre eclampsia", "hipertension gestacional", "hipertension del embarazo",
               "hipertension en el embarazo", "eclampsia"],
        "mesh": ["Hypertension, Pregnancy-Induced", "Pre-Eclampsia"],
        "terms": ["preeclampsia", "pre-eclampsia", "gestational hypertension", "pregnancy-induced hypertension"],
        "core": ["preeclampsia", "gestational hypertension"],
    },
    "diabetes_any": {
        "cat": "condition", "label": "Diabetes (cualquier tipo)",
        "es": ["diabetes", "diabetes mellitus", "diabeticos", "diabeticas"],
        "mesh": ["Diabetes Mellitus"], "terms": ["diabet*"], "core": ["diabetes"],
        "ambiguous": {
            "text": "Mencionaste diabetes. ¿A qué tipo te refieres?",
            "options": [
                {"value": "diabetes_t2", "label": "Tipo 2"},
                {"value": "diabetes_t1", "label": "Tipo 1"},
                {"value": "gestational_diabetes", "label": "Gestacional"},
                {"value": "diabetes_any", "label": "Cualquier tipo"},
            ],
        },
    },
    "diabetes_t1": {
        "cat": "condition", "label": "Diabetes tipo 1",
        "es": ["diabetes tipo 1", "diabetes tipo i", "diabetes mellitus tipo 1", "dm1", "dmt1"],
        "mesh": ["Diabetes Mellitus, Type 1"], "terms": ["type 1 diabetes", "T1DM", "insulin-dependent diabetes"],
        "core": ["type 1 diabetes"],
    },
    "diabetes_t2": {
        "cat": "condition", "label": "Diabetes tipo 2",
        "es": ["diabetes tipo 2", "diabetes tipo ii", "diabetes mellitus tipo 2", "dm2", "dmt2"],
        "mesh": ["Diabetes Mellitus, Type 2"], "terms": ["type 2 diabetes", "T2DM", "non-insulin-dependent diabetes"],
        "core": ["type 2 diabetes"],
    },
    "gestational_diabetes": {
        "cat": "condition", "label": "Diabetes gestacional",
        "es": ["diabetes gestacional", "diabetes del embarazo", "diabetes en el embarazo"],
        "mesh": ["Diabetes, Gestational"], "terms": ["gestational diabetes", "GDM"], "core": ["gestational diabetes"],
    },
    "obesity": {
        "cat": "condition", "label": "Obesidad / sobrepeso",
        "es": ["obesidad", "sobrepeso", "obesos", "obesas", "obesidad infantil"],
        "mesh": ["Obesity", "Overweight"], "terms": ["obes*", "overweight"], "core": ["obesity"],
    },
    "metabolic_syndrome": {
        "cat": "condition", "label": "Síndrome metabólico",
        "es": ["sindrome metabolico"], "mesh": ["Metabolic Syndrome"], "terms": ["metabolic syndrome"],
    },
    "dyslipidemia": {
        "cat": "condition", "label": "Dislipidemia / colesterol alto",
        "es": ["dislipidemia", "dislipidemias", "colesterol alto", "hipercolesterolemia", "trigliceridos altos"],
        "mesh": ["Dyslipidemias"], "terms": ["dyslipid*", "hypercholesterol*"], "core": ["dyslipidemia"],
    },
    "depression": {
        "cat": "condition", "label": "Depresión",
        "es": ["depresion", "trastorno depresivo", "depresion mayor", "sintomas depresivos"],
        "mesh": ["Depression", "Depressive Disorder"], "terms": ["depress*"], "core": ["depression"],
    },
    "anxiety": {
        "cat": "condition", "label": "Ansiedad",
        "es": ["ansiedad", "trastorno de ansiedad", "trastornos de ansiedad"],
        "mesh": ["Anxiety", "Anxiety Disorders"], "terms": ["anxiety", "anxious"], "core": ["anxiety"],
    },
    "burnout": {
        "cat": "condition", "label": "Burnout / desgaste profesional",
        "es": ["burnout", "sindrome de burnout", "desgaste profesional", "agotamiento laboral"],
        "mesh": ["Burnout, Professional", "Burnout, Psychological"], "terms": ["burnout", "burn-out"],
    },
    "autism": {
        "cat": "condition", "label": "Autismo (TEA)",
        "es": ["autismo", "trastorno del espectro autista", "tea", "autistas"],
        "mesh": ["Autism Spectrum Disorder"], "terms": ["autis*"], "core": ["autism"],
    },
    "adhd": {
        "cat": "condition", "label": "TDAH",
        "es": ["tdah", "deficit de atencion", "trastorno por deficit de atencion", "hiperactividad"],
        "mesh": ["Attention Deficit Disorder with Hyperactivity"],
        "terms": ["ADHD", "attention deficit hyperactivity disorder"], "core": ["ADHD"],
    },
    "epilepsy": {
        "cat": "condition", "label": "Epilepsia",
        "es": ["epilepsia", "crisis epilepticas", "convulsiones"], "mesh": ["Epilepsy", "Seizures"],
        "terms": ["epilep*", "seizure*"], "core": ["epilepsy"],
    },
    "asthma": {
        "cat": "condition", "label": "Asma",
        "es": ["asma", "asmaticos"], "mesh": ["Asthma"], "terms": ["asthma*"], "core": ["asthma"],
    },
    "copd": {
        "cat": "condition", "label": "EPOC",
        "es": ["epoc", "enfermedad pulmonar obstructiva cronica"],
        "mesh": ["Pulmonary Disease, Chronic Obstructive"], "terms": ["COPD", "chronic obstructive pulmonary disease"],
        "core": ["COPD"],
    },
    "cancer_any": {
        "cat": "condition", "label": "Cáncer (cualquiera)",
        "es": ["cancer", "tumor", "tumores", "neoplasia", "neoplasias", "oncologico", "oncologicos"],
        "mesh": ["Neoplasms"], "terms": ["cancer*", "neoplas*", "tumor*", "tumour*"], "core": ["cancer"],
        "ambiguous": {
            "text": "Mencionaste cáncer. ¿De qué localización?",
            "options": [
                {"value": "breast_cancer", "label": "Mama"},
                {"value": "cervical_cancer", "label": "Cervicouterino"},
                {"value": "lung_cancer", "label": "Pulmón"},
                {"value": "colorectal_cancer", "label": "Colorrectal"},
                {"value": "prostate_cancer", "label": "Próstata"},
                {"value": "cancer_any", "label": "Cualquiera"},
            ],
        },
    },
    "breast_cancer": {
        "cat": "condition", "label": "Cáncer de mama",
        "es": ["cancer de mama", "cancer mamario", "carcinoma de mama", "tumor de mama"],
        "mesh": ["Breast Neoplasms"], "terms": ["breast cancer*", "breast neoplasm*", "breast carcinoma*"],
        "core": ["breast cancer"],
    },
    "cervical_cancer": {
        "cat": "condition", "label": "Cáncer cervicouterino",
        "es": ["cancer cervicouterino", "cancer de cuello uterino", "cancer cervical", "cancer de cervix"],
        "mesh": ["Uterine Cervical Neoplasms"], "terms": ["cervical cancer*", "cervical neoplasm*"],
        "core": ["cervical cancer"],
    },
    "lung_cancer": {
        "cat": "condition", "label": "Cáncer de pulmón",
        "es": ["cancer de pulmon", "cancer pulmonar", "carcinoma pulmonar"],
        "mesh": ["Lung Neoplasms"], "terms": ["lung cancer*", "lung neoplasm*", "lung carcinoma*"],
        "core": ["lung cancer"],
    },
    "colorectal_cancer": {
        "cat": "condition", "label": "Cáncer colorrectal",
        "es": ["cancer colorrectal", "cancer de colon", "cancer de recto"],
        "mesh": ["Colorectal Neoplasms"], "terms": ["colorectal cancer*", "colon cancer*", "rectal cancer*"],
        "core": ["colorectal cancer"],
    },
    "prostate_cancer": {
        "cat": "condition", "label": "Cáncer de próstata",
        "es": ["cancer de prostata", "carcinoma de prostata"],
        "mesh": ["Prostatic Neoplasms"], "terms": ["prostate cancer*", "prostatic neoplasm*"],
        "core": ["prostate cancer"],
    },
    "covid19": {
        "cat": "condition", "label": "COVID-19",
        "es": ["covid", "covid 19", "sars cov 2", "coronavirus"],
        "mesh": ["COVID-19", "SARS-CoV-2"], "terms": ["COVID-19", "SARS-CoV-2", "coronavirus disease 2019"],
        "core": ["COVID-19"],
    },
    "dengue": {
        "cat": "condition", "label": "Dengue",
        "es": ["dengue"], "mesh": ["Dengue"], "terms": ["dengue"],
    },
    "tuberculosis": {
        "cat": "condition", "label": "Tuberculosis",
        "es": ["tuberculosis", "tb"], "mesh": ["Tuberculosis"], "terms": ["tuberculosis"],
    },
    "uti": {
        "cat": "condition", "label": "Infección urinaria",
        "es": ["infeccion urinaria", "infecciones urinarias", "infeccion de vias urinarias", "ivu", "cistitis"],
        "mesh": ["Urinary Tract Infections"], "terms": ["urinary tract infection*", "cystitis"],
        "core": ["urinary tract infection"],
    },
    "stroke": {
        "cat": "condition", "label": "Ictus / EVC",
        "es": ["ictus", "accidente cerebrovascular", "acv", "derrame cerebral", "infarto cerebral",
               "evento vascular cerebral", "evc"],
        "mesh": ["Stroke"], "terms": ["stroke", "cerebrovascular accident*"], "core": ["stroke"],
    },
    "myocardial_infarction": {
        "cat": "condition", "label": "Infarto de miocardio",
        "es": ["infarto", "infarto de miocardio", "infarto agudo de miocardio", "ataque cardiaco", "iam"],
        "mesh": ["Myocardial Infarction"], "terms": ["myocardial infarction", "heart attack*"],
        "core": ["myocardial infarction"],
    },
    "heart_failure": {
        "cat": "condition", "label": "Insuficiencia cardiaca",
        "es": ["insuficiencia cardiaca", "falla cardiaca"],
        "mesh": ["Heart Failure"], "terms": ["heart failure", "cardiac failure"], "core": ["heart failure"],
    },
    "ckd": {
        "cat": "condition", "label": "Enfermedad renal crónica",
        "es": ["enfermedad renal cronica", "insuficiencia renal cronica", "erc", "enfermedad renal"],
        "mesh": ["Renal Insufficiency, Chronic"], "terms": ["chronic kidney disease", "CKD", "chronic renal failure"],
        "core": ["chronic kidney disease"],
    },
    "nafld": {
        "cat": "condition", "label": "Hígado graso",
        "es": ["higado graso", "esteatosis hepatica", "higado graso no alcoholico", "masld", "nafld"],
        "mesh": ["Non-alcoholic Fatty Liver Disease"],
        "terms": ["fatty liver", "NAFLD", "MASLD", "hepatic steatosis"], "core": ["fatty liver"],
    },
    "hypothyroidism": {
        "cat": "condition", "label": "Hipotiroidismo",
        "es": ["hipotiroidismo"], "mesh": ["Hypothyroidism"], "terms": ["hypothyroid*"], "core": ["hypothyroidism"],
    },
    "dementia": {
        "cat": "condition", "label": "Demencia / Alzheimer",
        "es": ["demencia", "alzheimer", "enfermedad de alzheimer", "deterioro cognitivo"],
        "mesh": ["Dementia", "Alzheimer Disease", "Cognitive Dysfunction"],
        "terms": ["dementia", "alzheimer*", "cognitive impairment"], "core": ["dementia"],
    },
    "fibromyalgia": {
        "cat": "condition", "label": "Fibromialgia",
        "es": ["fibromialgia"], "mesh": ["Fibromyalgia"], "terms": ["fibromyalgia"],
    },
    "migraine": {
        "cat": "condition", "label": "Migraña",
        "es": ["migrana", "migranas", "jaqueca"], "mesh": ["Migraine Disorders"], "terms": ["migrain*"],
        "core": ["migraine"],
    },
    "low_back_pain": {
        "cat": "condition", "label": "Dolor lumbar",
        "es": ["dolor lumbar", "lumbalgia", "dolor de espalda baja", "dolor de espalda"],
        "mesh": ["Low Back Pain"], "terms": ["low back pain", "lumbago"], "core": ["low back pain"],
    },
    "chronic_pain": {
        "cat": "condition", "label": "Dolor crónico",
        "es": ["dolor cronico"], "mesh": ["Chronic Pain"], "terms": ["chronic pain"],
    },
    "pain": {
        "cat": "condition", "label": "Dolor",
        "es": ["dolor", "dolores"], "mesh": ["Pain"], "terms": ["pain"],
    },
    "osteoarthritis": {
        "cat": "condition", "label": "Artrosis / osteoartritis",
        "es": ["artrosis", "osteoartritis", "osteoartrosis"], "mesh": ["Osteoarthritis"], "terms": ["osteoarthr*"],
        "core": ["osteoarthritis"],
    },
    "rheumatoid_arthritis": {
        "cat": "condition", "label": "Artritis reumatoide",
        "es": ["artritis reumatoide"], "mesh": ["Arthritis, Rheumatoid"], "terms": ["rheumatoid arthritis"],
    },
    "insomnia": {
        "cat": "condition", "label": "Insomnio / sueño",
        "es": ["insomnio", "trastornos del sueno", "trastorno del sueno", "problemas de sueno"],
        "mesh": ["Sleep Initiation and Maintenance Disorders"], "terms": ["insomnia", "sleep disorder*"],
        "core": ["insomnia"],
    },
    "osteoporosis": {
        "cat": "condition", "label": "Osteoporosis",
        "es": ["osteoporosis"], "mesh": ["Osteoporosis"], "terms": ["osteoporo*"], "core": ["osteoporosis"],
    },
    "anemia": {
        "cat": "condition", "label": "Anemia",
        "es": ["anemia", "anemia ferropenica"], "mesh": ["Anemia"], "terms": ["anemi*", "anaemi*"], "core": ["anemia"],
    },
    "sepsis": {
        "cat": "condition", "label": "Sepsis",
        "es": ["sepsis", "choque septico", "shock septico"], "mesh": ["Sepsis", "Shock, Septic"],
        "terms": ["sepsis", "septic shock"],
    },
    "hiv": {
        "cat": "condition", "label": "VIH",
        "es": ["vih", "sida"], "mesh": ["HIV Infections"],
        # "AIDS" se omite a propósito: en inglés también significa "ayudas" (hearing aids) y mete ruido.
        "terms": ["HIV", "human immunodeficiency virus", "acquired immunodeficiency syndrome"], "core": ["HIV"],
    },
    "smoking": {
        "cat": "condition", "label": "Tabaquismo",
        "es": ["tabaquismo", "tabaco", "fumar", "fumadores", "cigarro", "cigarrillos", "vapeo"],
        "mesh": ["Tobacco Use", "Smoking"], "terms": ["smok*", "tobacco", "vaping"], "core": ["smoking"],
    },
    "alcohol": {
        "cat": "condition", "label": "Consumo de alcohol",
        "es": ["alcohol", "alcoholismo", "consumo de alcohol", "bebidas alcoholicas"],
        "mesh": ["Alcohol Drinking", "Alcoholism"], "terms": ["alcohol*"], "core": ["alcohol"],
    },

    # ------------------------------------------------------------------ POBLACIONES
    "pregnancy": {
        "cat": "population", "label": "Embarazadas",
        "es": ["embarazo", "embarazada", "embarazadas", "mujeres embarazadas", "gestantes", "gestacion", "gestante",
               "prenatal", "maternas"],
        "mesh": ["Pregnancy", "Pregnant People"], "terms": ["pregnan*", "gestation*", "prenatal"],
        "core": ["pregnancy"],
    },
    "newborn": {
        "cat": "population", "label": "Recién nacidos",
        "es": ["recien nacido", "recien nacidos", "neonato", "neonatos", "neonatal", "bebes", "lactantes"],
        "mesh": ["Infant, Newborn", "Infant"], "terms": ["newborn*", "neonat*", "infant*"], "core": ["newborn"],
    },
    "children": {
        "cat": "population", "label": "Niños",
        "es": ["nino", "ninos", "nina", "ninas", "infancia", "infantil", "infantiles", "pediatrico", "pediatrica",
               "pediatricos", "pediatria", "menores", "escolares", "preescolares"],
        "mesh": ["Child", "Child, Preschool"], "terms": ["child*", "pediatric*", "paediatric*"], "core": ["children"],
    },
    "adolescents": {
        "cat": "population", "label": "Adolescentes",
        "es": ["adolescente", "adolescentes", "adolescencia", "jovenes"],
        "mesh": ["Adolescent"], "terms": ["adolescen*", "teenager*", "youth"], "core": ["adolescents"],
    },
    "students": {
        "cat": "population", "label": "Estudiantes universitarios",
        "es": ["estudiantes", "estudiante", "universitarios", "universitarias", "estudiantes universitarios",
               "estudiantes de medicina", "alumnos"],
        "mesh": ["Students", "Universities"], "terms": ["student*", "undergraduate*"], "core": ["students"],
    },
    "adults": {
        "cat": "population", "label": "Adultos",
        "es": ["adulto", "adultos", "adulta", "adultas"], "mesh": ["Adult"], "terms": ["adult*"], "core": ["adults"],
    },
    "aged": {
        "cat": "population", "label": "Adultos mayores",
        "es": ["adulto mayor", "adultos mayores", "anciano", "ancianos", "tercera edad", "personas mayores",
               "geriatrico", "geriatrica", "vejez"],
        "mesh": ["Aged", "Aged, 80 and over"],
        # "aged" como palabra de texto se omite: aparece en "children aged 5" y mete ruido.
        "terms": ["elderly", "older adult*", "older people", "geriatric*"], "core": ["older adults"],
    },
    "women": {
        "cat": "population", "label": "Mujeres",
        "es": ["mujer", "mujeres"], "mesh": ["Women", "Female"], "terms": ["women", "woman"], "core": ["women"],
    },
    "men": {
        "cat": "population", "label": "Hombres",
        "es": ["hombre", "hombres", "varones"], "mesh": ["Men", "Male"], "terms": ["men", "man"], "core": ["men"],
    },
    "health_personnel": {
        "cat": "population", "label": "Personal de salud",
        "es": ["personal de salud", "personal sanitario", "trabajadores de la salud", "enfermeras", "enfermeros",
               "medicos residentes", "residentes"],
        "mesh": ["Health Personnel"], "terms": ["health personnel", "healthcare worker*", "nurse*", "physician*"],
        "core": ["healthcare workers"],
    },
    "animals": {
        "cat": "population", "label": "Estudios en animales",
        "es": ["animales", "ratones", "ratas", "modelo animal", "modelos animales"],
        "mesh": ["Animals", "Mice", "Rats"], "terms": ["mice", "rats", "murine", "animal model*"],
        "core": ["animal model"],
    },

    # ------------------------------------------------------------------ INTERVENCIONES / EXPOSICIONES
    "non_pharmacological": {
        "cat": "intervention", "label": "Tratamiento no farmacológico",
        "es": ["sin farmacos", "sin medicamentos", "sin medicacion", "sin farmacologia", "no farmacologico",
               "no farmacologicos", "no farmacologica", "no farmacologicas", "terapia no farmacologica",
               "tratamiento no farmacologico", "tratamientos no farmacologicos", "natural", "naturales",
               "estilo de vida", "cambios en el estilo de vida"],
        "mesh": ["Complementary Therapies", "Exercise Therapy", "Diet Therapy", "Life Style"],
        "terms": ["non-pharmacologic*", "nonpharmacologic*", "non-drug", "lifestyle intervention*",
                  "lifestyle modification*"],
        "core": ["non-pharmacological"],
    },
    "drug_therapy": {
        "cat": "intervention", "label": "Tratamiento farmacológico",
        "es": ["farmaco", "farmacos", "medicamento", "medicamentos", "farmacologico", "farmacologica",
               "tratamiento farmacologico", "medicacion", "farmacoterapia"],
        "mesh": ["Drug Therapy"], "sh": ["drug therapy"],
        "terms": ["drug therap*", "pharmacotherap*", "pharmacologic* treatment*", "medication*"],
        "core": ["drug therapy"],
    },
    "exercise": {
        "cat": "intervention", "label": "Ejercicio / actividad física",
        "es": ["ejercicio", "ejercicios", "ejercicio fisico", "actividad fisica", "entrenamiento fisico", "deporte",
               "caminar", "caminata"],
        "mesh": ["Exercise", "Exercise Therapy"], "terms": ["exercis*", "physical activit*", "physical training"],
        "core": ["exercise"],
    },
    "diet": {
        "cat": "intervention", "label": "Dieta / nutrición",
        "es": ["dieta", "dietas", "alimentacion", "nutricion", "intervencion nutricional", "dieta mediterranea"],
        "mesh": ["Diet", "Diet Therapy"], "terms": ["diet*", "nutrition*"], "core": ["diet"],
    },
    "breastfeeding": {
        "cat": "intervention", "label": "Lactancia materna",
        "es": ["lactancia", "lactancia materna", "amamantamiento", "leche materna"],
        "mesh": ["Breast Feeding", "Milk, Human"], "terms": ["breastfeed*", "breast-feed*", "breast milk"],
        "core": ["breastfeeding"],
    },
    "psychotherapy": {
        "cat": "intervention", "label": "Psicoterapia",
        "es": ["psicoterapia", "terapia psicologica", "intervencion psicologica", "apoyo psicologico"],
        "mesh": ["Psychotherapy"], "terms": ["psychotherap*", "psychological intervention*"], "core": ["psychotherapy"],
    },
    "cbt": {
        "cat": "intervention", "label": "Terapia cognitivo-conductual",
        "es": ["terapia cognitivo conductual", "terapia cognitiva conductual", "tcc"],
        "mesh": ["Cognitive Behavioral Therapy"], "terms": ["cognitive behavio* therap*", "CBT"],
        "core": ["cognitive behavioral therapy"],
    },
    "mindfulness": {
        "cat": "intervention", "label": "Mindfulness / meditación",
        "es": ["mindfulness", "atencion plena", "meditacion"],
        "mesh": ["Mindfulness", "Meditation"], "terms": ["mindfulness", "meditat*"], "core": ["mindfulness"],
    },
    "yoga": {
        "cat": "intervention", "label": "Yoga", "es": ["yoga"], "mesh": ["Yoga"], "terms": ["yoga"],
    },
    "acupuncture": {
        "cat": "intervention", "label": "Acupuntura",
        "es": ["acupuntura"], "mesh": ["Acupuncture Therapy"], "terms": ["acupunct*"], "core": ["acupuncture"],
    },
    "physiotherapy": {
        "cat": "intervention", "label": "Fisioterapia / rehabilitación",
        "es": ["fisioterapia", "terapia fisica", "rehabilitacion"],
        "mesh": ["Physical Therapy Modalities", "Rehabilitation"], "terms": ["physiotherap*", "physical therap*",
                                                                             "rehabilitation"],
        "core": ["physiotherapy"],
    },
    "surgery": {
        "cat": "intervention", "label": "Cirugía",
        "es": ["cirugia", "cirugias", "quirurgico", "quirurgica", "intervencion quirurgica", "operacion"],
        "mesh": ["Surgical Procedures, Operative"], "sh": ["surgery"], "terms": ["surg*"], "core": ["surgery"],
    },
    "vaccination": {
        "cat": "intervention", "label": "Vacunación",
        "es": ["vacuna", "vacunas", "vacunacion", "inmunizacion"],
        "mesh": ["Vaccination", "Vaccines"], "terms": ["vaccin*", "immunization*", "immunisation*"],
        "core": ["vaccination"],
    },
    "telemedicine": {
        "cat": "intervention", "label": "Telemedicina / salud digital",
        "es": ["telemedicina", "telesalud", "salud digital", "aplicaciones moviles", "aplicacion movil",
               "teleconsulta"],
        "mesh": ["Telemedicine", "Mobile Applications"],
        "terms": ["telemedicine", "telehealth", "mHealth", "mobile health app*", "digital health"],
        "core": ["telemedicine"],
    },
    "health_education": {
        "cat": "intervention", "label": "Educación para la salud",
        "es": ["educacion para la salud", "educacion sanitaria", "educacion del paciente", "promocion de la salud",
               "intervencion educativa", "programa educativo"],
        "mesh": ["Health Education", "Patient Education as Topic", "Health Promotion"],
        "terms": ["health education", "patient education", "health promotion"], "core": ["health education"],
    },
    "supplements": {
        "cat": "intervention", "label": "Suplementos",
        "es": ["suplementos", "suplemento", "suplementacion"],
        "mesh": ["Dietary Supplements"], "terms": ["supplement*"], "core": ["dietary supplements"],
    },
    "vitamin_d": {
        "cat": "intervention", "label": "Vitamina D",
        "es": ["vitamina d"], "mesh": ["Vitamin D"], "terms": ["vitamin D", "cholecalciferol"], "core": ["vitamin D"],
    },
    "probiotics": {
        "cat": "intervention", "label": "Probióticos",
        "es": ["probioticos", "probiotico"], "mesh": ["Probiotics"], "terms": ["probiotic*"], "core": ["probiotics"],
    },
    "metformin": {
        "cat": "intervention", "label": "Metformina",
        "es": ["metformina"], "mesh": ["Metformin"], "terms": ["metformin"],
    },
    "insulin": {
        "cat": "intervention", "label": "Insulina",
        "es": ["insulina", "insulinoterapia"], "mesh": ["Insulin"], "terms": ["insulin*"], "core": ["insulin"],
    },
    "aspirin": {
        "cat": "intervention", "label": "Aspirina",
        "es": ["aspirina", "acido acetilsalicilico"], "mesh": ["Aspirin"], "terms": ["aspirin", "acetylsalicylic acid"],
    },
    "antihypertensives": {
        "cat": "intervention", "label": "Antihipertensivos",
        "es": ["antihipertensivo", "antihipertensivos"], "mesh": ["Antihypertensive Agents"],
        "terms": ["antihypertensive*"], "core": ["antihypertensive agents"],
    },
    "antibiotics": {
        "cat": "intervention", "label": "Antibióticos",
        "es": ["antibiotico", "antibioticos", "antibioticoterapia"], "mesh": ["Anti-Bacterial Agents"],
        "terms": ["antibiotic*", "antibacterial*"], "core": ["antibiotics"],
    },
    "antidepressants": {
        "cat": "intervention", "label": "Antidepresivos",
        "es": ["antidepresivo", "antidepresivos"], "mesh": ["Antidepressive Agents"], "terms": ["antidepressant*"],
        "core": ["antidepressants"],
    },

    # ------------------------------------------------------------------ ENFOQUE (qué aspecto se busca)
    "therapy": {
        "cat": "focus", "label": "Tratamiento (general)",
        "es": ["tratamiento", "tratamientos", "terapia", "terapias", "manejo", "abordaje", "intervencion",
               "intervenciones", "tratar"],
        "sh": ["therapy"], "terms": ["treat*", "therap*", "management", "intervention*"], "core": ["treatment"],
    },
    "diagnosis": {
        "cat": "focus", "label": "Diagnóstico",
        "es": ["diagnostico", "diagnosticos", "deteccion", "cribado", "tamizaje", "tamizajes", "screening"],
        "mesh": ["Mass Screening"], "sh": ["diagnosis"], "terms": ["diagnos*", "screening", "detection"],
        "core": ["diagnosis"],
    },
    "prevention": {
        "cat": "focus", "label": "Prevención",
        "es": ["prevencion", "prevenir", "profilaxis", "evitar"],
        "mesh": ["Primary Prevention"], "sh": ["prevention and control"], "terms": ["prevent*", "prophyla*"],
        "core": ["prevention"],
    },
    "risk_factors": {
        "cat": "focus", "label": "Factores de riesgo / causas",
        "es": ["factores de riesgo", "factor de riesgo", "causas", "causa", "etiologia", "determinantes"],
        "mesh": ["Risk Factors"], "sh": ["etiology"], "terms": ["risk factor*", "etiolog*", "determinant*"],
        "core": ["risk factors"],
    },
    "prevalence": {
        "cat": "focus", "label": "Prevalencia / epidemiología",
        "es": ["prevalencia", "incidencia", "epidemiologia", "frecuencia"],
        "mesh": ["Prevalence", "Incidence"], "sh": ["epidemiology"], "terms": ["prevalence", "incidence",
                                                                             "epidemiolog*"],
        "core": ["prevalence"],
    },
    "mortality": {
        "cat": "focus", "label": "Mortalidad / supervivencia",
        "es": ["mortalidad", "muerte", "muertes", "supervivencia", "sobrevida"],
        "mesh": ["Mortality", "Survival Rate"], "sh": ["mortality"], "terms": ["mortality", "death*", "surviv*"],
        "core": ["mortality"],
    },
    "quality_of_life": {
        "cat": "focus", "label": "Calidad de vida",
        "es": ["calidad de vida"], "mesh": ["Quality of Life"], "terms": ["quality of life", "QoL"],
        "core": ["quality of life"],
    },
    "adverse_effects": {
        "cat": "focus", "label": "Efectos adversos",
        "es": ["efectos adversos", "efectos secundarios", "seguridad", "toxicidad", "riesgos"],
        "mesh": ["Drug-Related Side Effects and Adverse Reactions"], "sh": ["adverse effects"],
        "terms": ["adverse effect*", "adverse event*", "side effect*", "adverse reaction*"],
        "core": ["adverse effects"],
    },
    "knowledge": {
        "cat": "focus", "label": "Conocimientos y actitudes",
        "es": ["conocimiento", "conocimientos", "actitudes", "percepcion", "percepciones", "creencias"],
        "mesh": ["Health Knowledge, Attitudes, Practice"], "terms": ["knowledge", "attitude*", "perception*"],
        "core": ["knowledge"],
    },

    # ------------------------------------------------------------------ TIPOS DE ESTUDIO
    "rct": {
        "cat": "study_type", "label": "Ensayo clínico aleatorizado",
        "es": ["ensayo clinico aleatorizado", "ensayos clinicos aleatorizados", "ensayo aleatorizado",
               "ensayos aleatorizados", "eca", "ecas", "ensayo controlado aleatorizado",
               "ensayos controlados aleatorizados"],
        "pt": ["Randomized Controlled Trial"], "terms": ["randomized controlled trial*",
                                                         "randomised controlled trial*", "RCT"],
        "core": ["randomized controlled trial"],
    },
    "clinical_trial": {
        "cat": "study_type", "label": "Ensayo clínico",
        "es": ["ensayo clinico", "ensayos clinicos", "estudio clinico", "estudios clinicos"],
        "pt": ["Clinical Trial"], "terms": ["clinical trial*"], "core": ["clinical trial"],
    },
    "systematic_review": {
        "cat": "study_type", "label": "Revisión sistemática",
        "es": ["revision sistematica", "revisiones sistematicas"],
        "pt": ["Systematic Review"], "terms": ["systematic review*"], "core": ["systematic review"],
    },
    "meta_analysis": {
        "cat": "study_type", "label": "Metaanálisis",
        "es": ["metaanalisis", "meta analisis", "metanalisis"],
        "pt": ["Meta-Analysis"], "terms": ["meta-analys*", "metaanalys*"], "core": ["meta-analysis"],
    },
    "review": {
        "cat": "study_type", "label": "Revisión",
        "es": ["revision", "revisiones", "revision narrativa", "revision bibliografica", "revision de literatura"],
        # "review" suelto se omite: aparece en casi todos los resúmenes ("we review...").
        "pt": ["Review"], "terms": ["narrative review*", "literature review*"], "core": ["review"],
    },
    "cohort": {
        "cat": "study_type", "label": "Estudio de cohortes",
        "es": ["cohorte", "cohortes", "estudio de cohorte", "estudios de cohorte", "longitudinal", "longitudinales"],
        "mesh": ["Cohort Studies"], "terms": ["cohort*", "longitudinal"], "core": ["cohort study"],
    },
    "case_control": {
        "cat": "study_type", "label": "Casos y controles",
        "es": ["casos y controles", "caso control"],
        "mesh": ["Case-Control Studies"], "terms": ["case-control*"], "core": ["case-control study"],
    },
    "cross_sectional": {
        "cat": "study_type", "label": "Estudio transversal",
        "es": ["transversal", "transversales", "estudio transversal", "encuesta", "encuestas"],
        "mesh": ["Cross-Sectional Studies"], "terms": ["cross-sectional", "survey*"], "core": ["cross-sectional"],
    },
    "guideline": {
        "cat": "study_type", "label": "Guía de práctica clínica",
        "es": ["guia de practica clinica", "guias de practica clinica", "guia clinica", "guias clinicas", "guias",
               "guia", "recomendaciones"],
        "pt": ["Practice Guideline", "Guideline"], "terms": ["guideline*", "recommendation*"],
        "core": ["guideline"],
    },
    "case_report": {
        "cat": "study_type", "label": "Reporte de caso",
        "es": ["reporte de caso", "reportes de caso", "caso clinico", "casos clinicos"],
        "pt": ["Case Reports"], "terms": ["case report*"], "core": ["case report"],
    },
}

CATEGORY_LABELS = {
    "condition": "Condición", "population": "Población", "intervention": "Intervención",
    "focus": "Enfoque", "study_type": "Tipo de estudio", "free": "Término libre",
}

# Palabras que niegan el concepto siguiente ("sin X", "excepto X", "no X")
NEGATORS = {"sin", "excepto", "excluyendo", "excluir", "salvo", "no", "evitando", "descartando"}

STOPWORDS = {
    "a", "al", "ante", "bajo", "con", "contra", "de", "del", "desde", "durante", "en", "entre", "hacia",
    "hasta", "mediante", "para", "por", "segun", "sobre", "tras", "el", "la", "los", "las", "un", "una",
    "unos", "unas", "lo", "y", "e", "o", "u", "ni", "que", "cual", "cuales", "quien", "como", "cuando",
    "donde", "se", "su", "sus", "mi", "mis", "tu", "tus", "este", "esta", "estos", "estas", "ese", "esa",
    "esos", "esas", "es", "son", "ser", "hay", "muy", "mas", "tambien", "ya", "le", "les", "me", "nos",
    "quiero", "busco", "buscar", "necesito", "informacion", "acerca", "tema", "temas", "existen", "existe",
    "actual", "actuales", "reciente", "recientes", "nuevo", "nuevos", "nueva", "nuevas", "ano", "anos",
    "sirve", "sirven", "funciona", "funcionan", "ayuda", "ayudan", "mejor", "mejores", "puede", "pueden",
    "afecta", "afectan", "influye", "influyen", "usar", "utilizar", "hacer", "tiene", "tienen", "padecen",
    "padece", "con", "sus", "otros", "otras", "algun", "alguna", "algunos", "algunas", "todo", "todos",
    "cada", "si", "hoy", "dia", "dias", "actualmente", "mayor", "menor", "principal", "principales",
    "relacionados", "relacionadas", "relacionado", "asociados", "asociadas", "vs", "versus", "frente",
    "comparado", "comparada", "comparados", "comparar", "articulos", "cientificos", "cientificas",
}

GENERIC_WORDS = {
    "estudio", "estudios", "articulo", "paper", "papers", "evidencia", "evidencias", "efecto", "efectos",
    "uso", "papel", "rol", "relacion", "asociacion", "pacientes", "paciente", "personas", "persona",
    "casos", "caso", "poblacion", "resultado", "resultados", "eficacia", "efectividad", "impacto",
    "comparacion", "tipo", "tipos", "forma", "formas", "metodo", "metodos", "medicos", "problema", "problemas", "salud", "beneficios", "beneficio", "niveles", "nivel",
    "factores", "sintomas", "sintoma", "grupo", "grupos", "mexico", "mexicanos", "mexicanas", "latinoamerica",
}

POPULATION_OPTIONS = [
    {"value": "any", "label": "Cualquier población", "maps": []},
    {"value": "children", "label": "Niños", "maps": [("children", False)]},
    {"value": "adolescents", "label": "Adolescentes", "maps": [("adolescents", False)]},
    {"value": "adults", "label": "Adultos", "maps": [("adults", False)]},
    {"value": "aged", "label": "Adultos mayores", "maps": [("aged", False)]},
    {"value": "pregnancy", "label": "Embarazadas", "maps": [("pregnancy", False)]},
    {"value": "newborn", "label": "Recién nacidos", "maps": [("newborn", False)]},
    {"value": "students", "label": "Estudiantes", "maps": [("students", False)]},
]

STUDY_OPTIONS = [
    {"value": "any", "label": "Cualquier tipo de estudio", "maps": []},
    {"value": "rct", "label": "Solo ensayos clínicos aleatorizados", "maps": [("rct", False)]},
    {"value": "sr", "label": "Revisiones sistemáticas y metaanálisis",
     "maps": [("systematic_review", False), ("meta_analysis", False)]},
    {"value": "obs", "label": "Observacionales (cohortes, casos y controles, transversales)",
     "maps": [("cohort", False), ("case_control", False), ("cross_sectional", False)]},
    {"value": "guide", "label": "Guías de práctica clínica", "maps": [("guideline", False)]},
    {"value": "no_trials", "label": "Excluir ensayos clínicos", "maps": [("clinical_trial", True)]},
]

# Glosario mínimo para sugerir traducciones de palabras que no están en el diccionario
WORD_GLOSSARY = {
    "enfermedad": "disease", "sindrome": "syndrome", "trastorno": "disorder", "infeccion": "infection",
    "cronica": "chronic", "cronico": "chronic", "aguda": "acute", "agudo": "acute", "grave": "severe",
    "leve": "mild", "dolor": "pain", "piel": "skin", "sangre": "blood", "corazon": "heart", "higado": "liver",
    "rinon": "kidney", "hueso": "bone", "huesos": "bone", "estomago": "stomach", "cerebro": "brain",
    "ojo": "eye", "ojos": "eye", "oido": "ear", "boca": "mouth", "dientes": "teeth", "dental": "dental",
    "pie": "foot", "mano": "hand", "rodilla": "knee", "cadera": "hip", "hombro": "shoulder",
    "embarazo": "pregnancy", "parto": "childbirth", "cesarea": "cesarean section", "leche": "milk",
    "sueno": "sleep", "peso": "weight", "azucar": "sugar", "sal": "salt", "agua": "water",
    "musica": "music", "juego": "play", "juegos": "games", "escuela": "school", "trabajo": "work",
    "violencia": "violence", "suicidio": "suicide", "estres": "stress", "apego": "adherence",
    "adherencia": "adherence", "cuidado": "care", "cuidados": "care", "paliativos": "palliative",
    "enfermeria": "nursing", "hospital": "hospital", "urgencias": "emergency", "virus": "virus",
    "vacuna": "vaccine", "bacteria": "bacteria", "hongos": "fungi", "cirrosis": "cirrhosis",
    "catarata": "cataract", "cataratas": "cataract", "glaucoma": "glaucoma", "psoriasis": "psoriasis",
    "acne": "acne", "lupus": "lupus", "gota": "gout", "parkinson": "Parkinson", "down": "Down",
    "celiaca": "celiac", "caries": "dental caries", "periodontitis": "periodontitis", "zika": "Zika",
    "influenza": "influenza", "gripe": "influenza", "neumonia": "pneumonia", "bronquiolitis": "bronchiolitis",
    "desnutricion": "malnutrition", "hierro": "iron", "calcio": "calcium", "cafe": "coffee",
}
LONE_HEAD_WORDS = {"enfermedad", "sindrome", "trastorno", "padecimiento", "patologia"}
HEAD_NOUNS = {"enfermedad": "disease", "sindrome": "syndrome", "trastorno": "disorder", "infeccion": "infection",
              "virus": "virus", "cancer": "cancer"}

COGNATE_RULES = [
    ("ciones", "tions"), ("cion", "tion"), ("siones", "sions"), ("sion", "sion"),
    ("idades", "ities"), ("idad", "ity"), ("ismos", "isms"), ("ismo", "ism"),
    ("icos", "ic"), ("icas", "ic"), ("ico", "ic"), ("ica", "ic"),
    ("osos", "ous"), ("osas", "ous"), ("oso", "ous"), ("osa", "ous"),
    ("itis", "itis"), ("emia", "emia"), ("patia", "pathy"), ("logia", "logy"),
    ("grafia", "graphy"), ("terapia", "therapy"), ("mente", "ly"),
    ("algia", "algia"), ("ias", "ies"), ("ia", "y"), ("ivos", "ive"), ("ivo", "ive"), ("iva", "ive"),
    ("ales", "al"), ("al", "al"), ("ares", "ar"), ("antes", "ants"), ("ante", "ant"),
]
SUBSTRING_RULES = [
    ("mialg", "myalg"), ("hiper", "hyper"), ("hipo", "hypo"), ("psic", "psych"), ("fisi", "physi"),
    ("quist", "cyst"), ("ftalm", "phthalm"), ("nefr", "nephr"), ("mielo", "myelo"), ("tiroid", "thyroid"),
    ("rino", "rhino"), ("cefal", "cephal"), ("ortop", "orthop"), ("pediat", "pediat"),
]


# ============================================================================
# PARTE 2. MOTOR DE TRADUCCIÓN (reglas locales, sin IA externa)
# ============================================================================
def strip_accents(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", text) if unicodedata.category(c) != "Mn")


def normalize(text: str) -> list[str]:
    text = strip_accents(text.lower())
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return [t for t in text.split() if t]


def singular(tok: str) -> str:
    """Singularizador español mínimo (suficiente para emparejar el diccionario)."""
    if len(tok) > 4 and tok.endswith("ces"):
        return tok[:-3] + "z"
    if len(tok) > 4 and tok.endswith("es") and tok[-3] not in "aeiou":
        return tok[:-2]
    if len(tok) > 3 and tok.endswith("s"):
        return tok[:-1]
    return tok


def tok_eq(a: str, b: str) -> bool:
    return a == b or singular(a) == singular(b)


# Índice: primer token (singular) -> [(tokens, concept_id)], de la frase más larga a la más corta
_PATTERNS: dict[str, list[tuple[tuple[str, ...], str]]] = {}
_ALL_PHRASES: dict[str, str] = {}
for _cid, _c in CONCEPTS.items():
    for _p in _c["es"]:
        _toks = tuple(normalize(_p))
        _PATTERNS.setdefault(singular(_toks[0]), []).append((_toks, _cid))
        _ALL_PHRASES.setdefault(" ".join(_toks), _cid)
for _k in _PATTERNS:
    _PATTERNS[_k].sort(key=lambda x: -len(x[0]))


# --------------------------------------------------------------------------- años en la pregunta
NUM_WORDS = {"un": 1, "uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7,
             "ocho": 8, "nueve": 9, "diez": 10, "quince": 15, "veinte": 20}
_Y = r"(19[5-9]\d|20\d\d)"
_YEAR_RULES = [
    ("range", re.compile(rf"\bentre (?:el )?(?:ano )?{_Y} y (?:el )?{_Y}\b")),
    ("range", re.compile(rf"\b(?:de|del) (?:ano )?{_Y} (?:a|al|hasta) (?:el )?{_Y}\b")),
    ("range", re.compile(rf"\b{_Y} {_Y}\b")),
    ("last", re.compile(r"\b(?:(?:en|de|durante|publicados en) )?(?:(?:los|las|el|la) )?ultim[oa]s? "
                        r"(?:(\d{1,2}|" + "|".join(NUM_WORDS) + r") )?(anos|ano|decadas|decada)\b")),
    ("from", re.compile(rf"\b(?:desde|a partir de|despues de|posteriores? a) (?:el |del )?(?:ano )?{_Y}\b")),
    ("to", re.compile(rf"\b(?:hasta|antes de|anteriores? a|previos? a) (?:el |del )?(?:ano )?{_Y}\b")),
    ("single", re.compile(rf"\b(?:en|del|de|durante) (?:el )?(?:ano )?{_Y}\b")),
]


def parse_years(norm: str) -> tuple[int | None, int | None, list[str], str]:
    """Detecta 'últimos 5 años', 'desde 2015', 'entre 2010 y 2020'... Devuelve (desde, hasta, frases, texto_sin_años)."""
    y0 = y1 = None
    phrases: list[str] = []
    for kind, rx in _YEAR_RULES:
        m = rx.search(norm)
        if not m:
            continue
        if kind == "range" and y0 is None and y1 is None:
            a, b = sorted((int(m.group(1)), int(m.group(2))))
            y0, y1 = a, b
        elif kind == "last" and y0 is None:
            n = m.group(1)
            n = int(n) if n and n.isdigit() else NUM_WORDS.get(n or "", 1)
            if m.group(2).startswith("decada"):
                n *= 10
            y0 = CURRENT_YEAR - n
        elif kind == "from" and y0 is None:
            y0 = int(m.group(1)) + (1 if re.match(r"(despues|posterior)", m.group(0)) else 0)
        elif kind == "to" and y1 is None:
            y1 = int(m.group(1)) - (1 if re.match(r"(antes|anterior|previo)", m.group(0)) else 0)
        elif kind == "single" and y0 is None and y1 is None:
            y0 = y1 = int(m.group(1))
        else:
            continue
        phrases.append(m.group(0))
        norm = norm[:m.start()] + " " + norm[m.end():]
    if y1 is not None and y1 > CURRENT_YEAR:
        y1 = None
    return y0, y1, phrases, norm


# --------------------------------------------------------------------------- traducción de términos desconocidos
def _cognate_word(word: str) -> str:
    if word in WORD_GLOSSARY or singular(word) in WORD_GLOSSARY:
        return WORD_GLOSSARY.get(word) or WORD_GLOSSARY[singular(word)]
    for es_part, en_part in SUBSTRING_RULES:
        word = word.replace(es_part, en_part)
    for es_suffix, en_suffix in COGNATE_RULES:
        if word.endswith(es_suffix) and len(word) > len(es_suffix) + 2:
            return word[: -len(es_suffix)] + en_suffix
    return word


def cognate_suggestion(phrase: str) -> str:
    """Sugerencia de traducción: glosario + reglas de cognados (ej. 'fibrosis quistica' -> 'cystic fibrosis')."""
    words = phrase.split()
    # "enfermedad de parkinson" -> "Parkinson disease"; "sindrome de down" -> "Down syndrome"
    if len(words) >= 3 and words[0] in HEAD_NOUNS and words[1] in ("de", "del"):
        rest = " ".join(_cognate_word(w) for w in words[2:] if w not in STOPWORDS)
        return f"{rest} {HEAD_NOUNS[words[0]]}"
    out = [_cognate_word(w) for w in words if w not in ("de", "del")]
    # Español: sustantivo + adjetivo  ->  inglés: adjetivo + sustantivo
    if len(out) == 2 and out[1].endswith(("ic", "al", "ar", "ous", "ive", "ary", "chronic", "acute", "severe", "mild")):
        out.reverse()
    return " ".join(out)


def did_you_mean(phrase: str) -> str | None:
    """Corrector ortográfico contra el diccionario (ej. 'hipertencion' -> hypertension)."""
    close = difflib.get_close_matches(phrase, list(_ALL_PHRASES), n=1, cutoff=0.84)
    return _ALL_PHRASES[close[0]] if close else None


# --------------------------------------------------------------------------- estructuras
@dataclass
class Hit:
    concept: str | None          # id del diccionario o None si es término libre
    negated: bool = False
    text: str = ""               # texto que disparó el concepto
    free_terms: list[str] = field(default_factory=list)
    source: str = "lexicon"      # lexicon | answer | free
    grp: int = 0                 # conceptos con el mismo grp se unen con OR ("niños o adolescentes")

    @property
    def cat(self) -> str:
        return CONCEPTS[self.concept]["cat"] if self.concept else "free"

    @property
    def key(self) -> str:
        return self.concept or "free:" + self.free_terms[0].lower()

    @property
    def label(self) -> str:
        return CONCEPTS[self.concept]["label"] if self.concept else self.free_terms[0]


_grp_counter = itertools.count(1)


def extract(text: str) -> tuple[list[Hit], list[tuple[str, bool]]]:
    """Devuelve conceptos reconocidos y frases desconocidas [(frase, negada)]."""
    toks = normalize(text)
    hits: list[Hit] = []
    unknown: list[tuple[str, bool]] = []
    neg_window = 0
    last_was_negated = False
    unk_buffer: list[str] = []
    unk_neg = False
    gap: list[str] = []          # palabras entre el concepto anterior y el actual

    def flush_unknown():
        nonlocal unk_buffer, unk_neg
        while unk_buffer and unk_buffer[-1] in ("de", "del"):
            unk_buffer.pop()
        if len(unk_buffer) == 1 and singular(unk_buffer[0]) in LONE_HEAD_WORDS:
            unk_buffer = []          # "enfermedad" sola no aporta nada a la búsqueda
        if unk_buffer:
            unknown.append((" ".join(unk_buffer), unk_neg))
            gap.append("<desconocido>")
        unk_buffer, unk_neg = [], False

    def is_content(j: int) -> bool:
        return j < len(toks) and toks[j] not in STOPWORDS and toks[j] not in NEGATORS and len(toks[j]) > 2 \
            and not _PATTERNS.get(singular(toks[j]))

    i = 0
    while i < len(toks):
        tok = toks[i]
        match = None
        for pat, cid in _PATTERNS.get(singular(tok), []):
            n = len(pat)
            if i + n <= len(toks) and all(tok_eq(toks[i + k], pat[k]) for k in range(n)):
                match = (pat, cid)
                break

        if match:
            flush_unknown()
            pat, cid = match
            negated = neg_window > 0
            prev = hits[-1] if hits else None
            linked = (prev is not None and ("o" in gap or "u" in gap)
                      and all(g in STOPWORDS for g in gap)
                      and prev.cat == CONCEPTS[cid]["cat"] and prev.negated == negated)
            grp = prev.grp if linked else next(_grp_counter)
            hits.append(Hit(concept=cid, negated=negated, text=" ".join(toks[i:i + len(pat)]), grp=grp))
            last_was_negated = negated
            neg_window = 0
            gap = []
            i += len(pat)
            continue

        if tok in NEGATORS or (tok in ("ni", "o", "u") and last_was_negated):
            flush_unknown()
            neg_window = 4
            gap.append(tok)
            i += 1
            continue

        # "enfermedad de parkinson": el "de" se queda dentro de la frase desconocida
        if tok in ("de", "del") and unk_buffer and is_content(i + 1):
            unk_buffer.append(tok)
            i += 1
            continue

        if tok in STOPWORDS or tok in GENERIC_WORDS or len(tok) <= 2 or tok.isdigit():
            flush_unknown()
            if neg_window:
                neg_window -= 1
            gap.append(tok if tok in STOPWORDS else "<generico>")
            i += 1
            continue

        if not unk_buffer:
            unk_neg = neg_window > 0
        unk_buffer.append(tok)
        neg_window = 0
        i += 1

    flush_unknown()
    return hits, unknown


# --------------------------------------------------------------------------- formateo de términos
def _needs_quotes(term: str) -> bool:
    return bool(re.search(r"[\s\-,/]", term))


def _q(term: str) -> str:
    return f'"{term}"' if _needs_quotes(term) else term


_UNTRUNC = [("activit", "activity"), ("ologic", "ological"), ("therap", "therapy"), ("analys", "analysis"),
            ("behavio", "behavior"), ("pharmacologic", "pharmacological"), ("adolescen", "adolescents")]


def untruncate(term: str) -> str:
    """Quita el * para bases que no lo aceptan: 'physical activit*' -> 'physical activity'."""
    words = []
    for w in term.split(" "):
        if w.endswith("*"):
            w = w[:-1]
            for stem, full in _UNTRUNC:
                if w.endswith(stem):
                    w = w[: -len(stem)] + full
                    break
        words.append(w)
    return " ".join(words)


def _dedup(parts: list[str]) -> list[str]:
    seen, out = set(), []
    for p in parts:
        k = p.lower()
        if k not in seen:
            seen.add(k)
            out.append(p)
    return out


def core_terms(h: Hit) -> list[str]:
    if not h.concept:
        return h.free_terms[:1]
    c = CONCEPTS[h.concept]
    if c.get("core"):
        return c["core"]
    first = (c.get("mesh") or c.get("pt") or c.get("terms"))[0]
    return [first.rstrip("*")]


def term_parts(h: Hit, syntax: str) -> list[str]:
    """Sinónimos de un concepto en la sintaxis pedida.

    pubmed: MeSH [Mesh] + subencabezado [sh] + tipo [pt] + palabras de texto [tw] (guía Lane/Stanford).
            Al EXCLUIR se usa [Majr] (tema principal) y [ti] (título) para no borrar artículos útiles
            que solo mencionan el concepto de pasada.
    generic: Europe PMC, SciELO, BVS. Acepta * pero no dentro de comillas.
    plain:   OpenAlex. Sin truncamiento.
    """
    if not h.concept:
        t = h.free_terms[0]
        if syntax == "pubmed":
            last = re.split(r"[\s\-]", t)[-1]
            # singular y plural: "cardiovascular disease*" (solo si hay 4+ letras antes del *)
            tt = t + "*" if (len(last) >= 4 and last.isalpha() and not t.endswith("*")) else t
            return [f"{_q(t)}[ti]" if h.negated else f"{_q(tt)}[tw]"]
        return [_q(t)]
    c = CONCEPTS[h.concept]
    if syntax == "pubmed":
        if h.negated:
            parts = [f'"{m}"[Majr]' for m in c.get("mesh", [])]
            parts += [f'"{p}"[pt]' for p in c.get("pt", [])]
            parts += [f"{_q(t)}[ti]" for t in c.get("terms", [])]
            return parts
        parts = [f'"{m}"[Mesh]' for m in c.get("mesh", [])]
        parts += [f'"{s}"[sh]' for s in c.get("sh", [])]
        parts += [f'"{p}"[pt]' for p in c.get("pt", [])]
        parts += [f"{_q(t)}[tw]" for t in c.get("terms", [])]
        return parts
    if h.negated:
        return [_q(t) for t in core_terms(h)]
    if syntax == "generic":
        terms = [(untruncate(t) if _needs_quotes(t) else t) for t in c.get("terms", [])]
        return _dedup([_q(t) for t in terms + c.get("mesh", []) + c.get("pt", [])])
    # plain
    terms = [untruncate(t) for t in c.get("terms", []) if "*" not in t or " " in t or "-" in t]
    return _dedup([_q(t) for t in core_terms(h) + c.get("mesh", []) + c.get("pt", []) + terms])


def or_group(parts: list[str]) -> str:
    return parts[0] if len(parts) == 1 else "(" + " OR ".join(parts) + ")"


# --------------------------------------------------------------------------- filas de la ecuación
CATEGORY_ORDER = ["condition", "free", "population", "intervention", "focus", "study_type"]
OR_WITHIN = {"population", "study_type"}   # "niños o adolescentes", "ECA o revisión sistemática"


def build_rows(hits: list[Hit]) -> list[list[Hit]]:
    """Agrupa: cada fila son conceptos unidos por OR; las filas se unen por AND (las negadas por NOT)."""
    rows: list[list[Hit]] = []
    for cat in CATEGORY_ORDER:
        pos = [h for h in hits if h.cat == cat and not h.negated]
        if not pos:
            continue
        if cat in OR_WITHIN:
            rows.append(pos)
            continue
        by_grp: dict[int, list[Hit]] = {}
        for h in pos:
            by_grp.setdefault(h.grp, []).append(h)
        rows.extend(by_grp.values())
    return rows


def render_query(rows: list[list[Hit]], neg: list[Hit], syntax: str, humans_only: bool) -> str:
    pos_blocks = []
    for row in rows:
        parts = []
        for h in row:
            parts += term_parts(h, syntax)
        pos_blocks.append(or_group(_dedup(parts)))
    neg_parts = []
    for h in neg:
        neg_parts += term_parts(h, syntax)
    if humans_only:
        neg_parts.append('("Animals"[Mesh] NOT "Humans"[Mesh])' if syntax == "pubmed"
                         else '(mice OR rats OR "animal model")')
    query = " AND ".join(pos_blocks)
    if query and neg_parts:
        head = f"({query})" if len(pos_blocks) > 1 else query
        query = f"{head} NOT {or_group(_dedup(neg_parts))}"
    return query


def render_simple(rows: list[list[Hit]], neg: list[Hit], scholar: bool) -> tuple[str, bool]:
    """Versión corta para Google Académico y ScienceDirect (sin truncamiento, máx. 8 operadores)."""
    priority = {"condition": 0, "free": 0, "intervention": 1, "population": 2, "focus": 3, "study_type": 4}
    kept = sorted(rows, key=lambda r: priority[r[0].cat])
    trimmed = False
    blocks: list[list[str]] = []
    ops = 0
    for row in kept:
        terms = _dedup([_q(core_terms(h)[0]) for h in row])
        cost = (len(terms) - 1) + (1 if blocks else 0)
        if ops + cost > 7:
            trimmed = True
            continue
        ops += cost
        blocks.append(terms)
    negs = _dedup([_q(core_terms(h)[0]) for h in neg])
    if scholar:
        q = " ".join(" OR ".join(b) for b in blocks)
        q += "".join(f" -{t}" for t in negs)
        return q.strip(), trimmed
    q = " AND ".join(or_group(b) for b in blocks)
    if negs and ops + len(negs) <= 8 and q:
        q = f"({q}) NOT {or_group(negs)}" if len(blocks) > 1 else f"{q} NOT {or_group(negs)}"
    elif negs:
        trimmed = True
    return q, trimmed


# --------------------------------------------------------------------------- API principal
DOI_RX = re.compile(r"\b(10\.\d{4,9}/[^\s\"<>]+)", re.I)


def translate(text: str, answers: dict | None = None, humans_only: bool = False) -> dict:
    answers = dict(answers or {})
    notes: list[str] = []
    doi = DOI_RX.search(text or "")

    if answers.get("topic"):
        text = f"{text} {answers['topic']}"

    y0, y1, year_phrases, norm = parse_years(" ".join(normalize(text)))
    hits, unknown = extract(norm)
    questions: list[dict] = []

    # --- 1. Conceptos ambiguos (diabetes, cáncer...)
    resolved: list[Hit] = []
    for h in hits:
        amb = CONCEPTS[h.concept].get("ambiguous")
        if amb and not h.negated:
            qid = f"amb:{h.concept}"
            value = answers.get(qid)
            questions.append({"id": qid, "type": "single", "text": amb["text"], "options": amb["options"],
                              "answered": value is not None, "value": value})
            if value and value in CONCEPTS:
                h = Hit(concept=value, text=h.text, source="answer", grp=h.grp)
        resolved.append(h)
    hits = resolved

    # --- 2. Términos desconocidos: corrector ortográfico + traducción sugerida
    for phrase, neg in unknown:
        qid = f"term:{phrase}"
        value = answers.get(qid)
        guess = did_you_mean(phrase)
        suggestion = cognate_suggestion(phrase)
        q = {"id": qid, "type": "text", "phrase": phrase,
             "text": f"No reconozco «{phrase}». ¿Cómo se dice en inglés?",
             "suggestion": suggestion, "answered": value is not None, "value": value}
        if guess:
            q["text"] = f"No reconozco «{phrase}». ¿Quisiste decir «{CONCEPTS[guess]['label']}»?"
            q["did_you_mean"] = {"value": f"concept:{guess}", "label": CONCEPTS[guess]["label"]}
        questions.append(q)
        if value is None and guess:
            value_concept = guess            # mientras no conteste, se usa la corrección más probable
        elif value and value.startswith("concept:") and value[8:] in CONCEPTS:
            value_concept = value[8:]
        else:
            value_concept = None
        if value_concept:
            hits.append(Hit(concept=value_concept, negated=neg, text=phrase, source="answer",
                            grp=next(_grp_counter)))
            continue
        english = (suggestion if value is None else value).strip()
        if english:
            hits.append(Hit(concept=None, negated=neg, text=phrase, free_terms=[english], source="free",
                            grp=next(_grp_counter)))

    # --- 3. Respuestas de plantilla
    for key, options in (("population", POPULATION_OPTIONS), ("study_type", STUDY_OPTIONS)):
        opt = next((o for o in options if o["value"] == answers.get(key)), None)
        if opt:
            for cid, neg in opt["maps"]:
                hits.append(Hit(concept=cid, negated=neg, source="answer", grp=next(_grp_counter)))
    if answers.get("aspect") in CONCEPTS:
        hits.append(Hit(concept=answers["aspect"], source="answer", grp=next(_grp_counter)))

    # --- 4. Reglas de coherencia
    # "sin fármacos" -> se busca "tratamiento no farmacológico" en lugar de NOT: un NOT borraría
    # los estudios que comparan ambos tratamientos (la guía de Stanford recomienda usar NOT con cuidado).
    if any(h.concept == "drug_therapy" and h.negated for h in hits):
        hits = [h for h in hits if not (h.concept == "drug_therapy" and h.negated)]
        if not any(h.concept == "non_pharmacological" for h in hits):
            hits.append(Hit(concept="non_pharmacological", source="answer", grp=next(_grp_counter)))
        notes.append("Cambié «sin fármacos» por «tratamiento no farmacológico»: excluir con NOT quitaría "
                     "también los estudios que comparan ambos tratamientos.")

    seen, dedup = set(), []
    for h in hits:
        k = (h.key, h.negated)
        if k not in seen:
            seen.add(k)
            dedup.append(h)
    hits = dedup

    positive_cats = {h.cat for h in hits if not h.negated}
    if "intervention" in positive_cats:
        hits = [h for h in hits if h.concept != "therapy"]   # "tratamiento" sobra si ya hay uno concreto

    # Conceptos que la persona quitó a mano desde la ecuación visual
    removed = set(answers.get("removed") or [])
    removed_hits = [h for h in hits if h.key in removed]
    hits = [h for h in hits if h.key not in removed]

    def cats(negated=False):
        return {h.cat for h in hits if h.negated == negated}

    positive = cats()
    has_topic = bool({"condition", "intervention", "free"} & positive)

    # --- 5. Preguntas por elementos PICO faltantes
    if not has_topic or answers.get("topic"):
        questions.insert(0, {
            "id": "topic", "type": "text",
            "text": "No identifiqué la enfermedad o el tema principal. ¿Sobre qué quieres buscar?",
            "placeholder": "ej. diabetes tipo 2, asma, cáncer de mama",
            "answered": bool(answers.get("topic")), "value": answers.get("topic"),
        })
    if ("population" not in positive and "population" not in cats(True)) or "population" in answers:
        questions.append({
            "id": "population", "type": "single", "text": "¿En qué población?",
            "options": [{"value": o["value"], "label": o["label"]} for o in POPULATION_OPTIONS],
            "answered": "population" in answers, "value": answers.get("population"),
        })
    if not ({"intervention", "focus"} & positive) or "aspect" in answers:
        opts = [{"value": "", "label": "Cualquier aspecto"}] + [
            {"value": v, "label": CONCEPTS[v]["label"]}
            for v in ("therapy", "diagnosis", "prevention", "risk_factors", "prevalence", "mortality")]
        questions.append({"id": "aspect", "type": "single", "text": "¿Qué aspecto te interesa?",
                          "options": opts, "answered": "aspect" in answers, "value": answers.get("aspect")})
    if ("study_type" not in positive and "study_type" not in cats(True)) or "study_type" in answers:
        questions.append({
            "id": "study_type", "type": "single", "text": "¿Quieres limitar o excluir algún tipo de estudio?",
            "options": [{"value": o["value"], "label": o["label"]} for o in STUDY_OPTIONS],
            "answered": "study_type" in answers, "value": answers.get("study_type"),
        })

    # --- 6. Ecuaciones
    rows = build_rows(hits)
    neg = [h for h in hits if h.negated]
    if any(len({h.grp for h in r}) == 1 and len(r) > 1 and r[0].cat not in OR_WITHIN for r in rows):
        notes.append("Uní con OR los conceptos que escribiste con «o».")
    if neg:
        notes.append("Las exclusiones (NOT) solo quitan artículos cuyo tema principal o título es lo excluido.")
    simple, trimmed = render_simple(rows, neg, scholar=False)
    scholar, _ = render_simple(rows, neg, scholar=True)
    if trimmed:
        notes.append("Para Google Académico y ScienceDirect uso una versión corta de la ecuación "
                     "(esas páginas aceptan pocas palabras y no admiten *).")

    pending = [q for q in questions if not q["answered"]]
    pico = [
        {"id": "topic", "label": "Tema o condición", "ok": has_topic},
        {"id": "population", "label": "Población", "ok": "population" in positive or answers.get("population") == "any"},
        {"id": "aspect", "label": "Intervención o aspecto",
         "ok": bool({"intervention", "focus"} & positive) or answers.get("aspect") == ""},
        {"id": "study_type", "label": "Tipo de estudio",
         "ok": bool("study_type" in positive or "study_type" in cats(True) or answers.get("study_type") == "any")},
    ]

    def concept_json(h: Hit) -> dict:
        return {"key": h.key, "label": h.label, "category": h.cat, "category_label": CATEGORY_LABELS[h.cat],
                "negated": h.negated, "matched_text": h.text, "source": h.source,
                "terms": term_parts(h, "pubmed")}

    return {
        "input": text,
        "years": {"from": y0, "to": y1, "phrases": year_phrases},
        "rows": [[concept_json(h) for h in r] for r in rows],
        "excluded": [concept_json(h) for h in neg],
        "removed": [{"key": h.key, "label": h.label} for h in removed_hits],
        "query_pubmed": render_query(rows, neg, "pubmed", humans_only),
        "query_generic": render_query(rows, neg, "generic", humans_only),
        "query_plain": render_query(rows, neg, "plain", humans_only),
        "query_simple": simple,
        "query_scholar": scholar,
        "questions": questions,
        "needs_clarification": bool(pending),
        "pico": pico,
        "notes": notes,
        "doi": doi.group(1).rstrip(".,;)") if doi else None,
    }


# ============================================================================
# PARTE 3. REVISOR DE SINTAXIS (reglas de la guía Lane Library, pasos 4 y 5)
# ============================================================================
PUBMED_TAGS = {
    "mesh", "mh", "mesh terms", "mesh:noexp", "mh:noexp", "majr", "mesh major topic", "majr:noexp", "sh",
    "subheading", "tiab", "title/abstract", "ti", "title", "ab", "abstract", "tw", "text word", "pt",
    "publication type", "la", "language", "au", "author", "1au", "lastau", "dp", "pdat", "edat",
    "publication date", "sb", "subset", "filter", "all fields", "all", "nm", "ot", "ta", "journal", "ad",
    "affiliation", "pmid", "uid", "doi", "lid", "aid", "si", "gr", "ps", "rn", "tt", "vi", "ip", "pg", "cois",
}
SMART_QUOTES = {"“": '"', "”": '"', "„": '"', "«": '"', "»": '"', "‘": "'", "’": "'"}


def _lex(q: str) -> list[tuple[str, str, int]]:
    """Separa la ecuación en (tipo, texto, posición): '(' ')' 'phrase' 'word'."""
    out, i, n = [], 0, len(q)
    while i < n:
        ch = q[i]
        if ch.isspace():
            i += 1
        elif ch in "()":
            out.append((ch, ch, i))
            i += 1
        elif ch == '"':
            j = q.find('"', i + 1)
            j = n - 1 if j == -1 else j
            k = j + 1
            while k < n and not q[k].isspace() and q[k] not in "()":
                k += 1          # incluye la etiqueta pegada: "x"[tw]
            out.append(("phrase", q[i:k], i))
            i = k
        else:
            j = i
            depth = 0
            while j < n and (depth or (not q[j].isspace() and q[j] not in "()")):
                depth += q[j] == "["
                depth -= q[j] == "]"
                j += 1
            out.append(("word", q[i:j], i))
            i = j
    return out


def lint_query(query: str, mode: str = "pubmed") -> dict:
    issues: list[dict] = []

    def add(level: str, msg: str):
        if not any(x["msg"] == msg for x in issues):
            issues.append({"level": level, "msg": msg})

    q = query or ""
    if not q.strip():
        return {"issues": [{"level": "error", "msg": "La ecuación está vacía."}], "fixed": None}

    if any(c in q for c in SMART_QUOTES):
        add("error", "Hay comillas tipográficas (“ ” « »). Las bases solo entienden comillas rectas (\").")
    if q.count('"') % 2:
        add("error", "Hay unas comillas abiertas sin cerrar.")

    toks = _lex(q)
    depth = 0
    ops_stack: list[set] = [set()]
    prev = None
    for kind, text, _pos in toks:
        upper = text.upper()
        is_op = kind == "word" and upper in ("AND", "OR", "NOT")
        if kind == "word" and text in ("and", "or", "not", "And", "Or", "Not"):
            add("warn", f"Escribe los operadores en MAYÚSCULAS («{text}» → «{upper}»); en minúsculas "
                        "se buscan como palabras.")
        if kind == "(":
            if prev and prev[0] in (")", "phrase", "word") and not prev[2]:
                add("warn", "Falta un operador (AND, OR o NOT) antes de un paréntesis.")
            depth += 1
            ops_stack.append(set())
        elif kind == ")":
            if prev and prev[0] == "(":
                add("error", "Hay paréntesis vacíos «()».")
            if prev and prev[2]:
                add("error", f"La ecuación no puede terminar un paréntesis con «{prev[1]}».")
            depth -= 1
            if depth < 0:
                add("error", "Hay un paréntesis de cierre «)» que sobra.")
                depth = 0
            else:
                inner = ops_stack.pop()
                if "OR" in inner and ({"AND", "NOT"} & inner):
                    add("warn", "Mezclaste OR con AND/NOT dentro del mismo paréntesis. PubMed lee de izquierda "
                                "a derecha: encierra los sinónimos unidos por OR entre paréntesis.")
        elif is_op:
            if prev is None or prev[0] == "(" or prev[2]:
                add("error", f"«{upper}» necesita un término antes.")
            ops_stack[-1].add(upper)
        if kind in ("word", "phrase") and not is_op:
            core = re.sub(r"\[[^\]]*\]", "", text).strip('"')
            for m in re.finditer(r"\*", core):
                word = re.split(r"[\s\-]", core[:m.start()])[-1]
                if m.end() < len(core) and core[m.end()].isalnum():
                    add("warn", f"En «{text}» el * está en medio de la palabra; solo funciona al final.")
                elif len(word) < 4:
                    add("error", f"«{word}*» es demasiado corto: el truncamiento necesita al menos 4 letras "
                                 "antes del *.")
            if kind == "phrase" and "*" in text and mode != "pubmed":
                add("warn", f"Muchas bases no aceptan * dentro de comillas ({text}).")
            for tag in re.findall(r"\[([^\]]*)\]", text):
                if mode != "pubmed":
                    add("warn", "Las etiquetas entre corchetes como [tw] o [Mesh] solo funcionan en PubMed.")
                elif tag.strip().lower() not in PUBMED_TAGS:
                    add("warn", f"PubMed no reconoce la etiqueta [{tag}].")
        prev = (kind, text, is_op)
    if prev and prev[2]:
        add("error", f"La ecuación no puede terminar con «{prev[1]}».")
    if depth > 0:
        add("error", f"Falta cerrar {depth} paréntesis «)».")
    if "OR" in ops_stack[0] and ({"AND", "NOT"} & ops_stack[0]):
        add("warn", "Mezclaste OR con AND/NOT sin paréntesis. Ejemplo correcto según la guía: "
                    "diabetes AND (\"mobile health\" OR telemedicine).")
    if len(q) > 4000:
        add("warn", "La ecuación es muy larga; algunas bases la pueden recortar.")

    fixed = q
    for a, b in SMART_QUOTES.items():
        fixed = fixed.replace(a, b)
    parts, out, inq = re.split(r'(")', fixed), [], False
    for p in parts:
        if p == '"':
            inq = not inq
            out.append(p)
        elif inq:
            out.append(p)
        else:
            out.append(re.sub(r"(?<![\w\[])(and|or|not)(?![\w\]])", lambda m: m.group(1).upper(), p,
                              flags=re.I))
    fixed = re.sub(r"\(\s*\)", "", "".join(out))
    return {"issues": issues, "fixed": fixed if fixed != q else None}


# ============================================================================
# PARTE 4. BÚSQUEDA (PubMed, Europe PMC, OpenAlex y Crossref: gratuitas y sin clave)
# ============================================================================
EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
OPENALEX = "https://api.openalex.org/works"
CROSSREF = "https://api.crossref.org/works/"
USER_AGENT = f"BuscadorAcademico/{APP_VERSION} (uso academico)"
NCBI_API_KEY = os.getenv("NCBI_API_KEY", "")      # opcional y gratuita: más búsquedas por segundo
CONTACT_EMAIL = os.getenv("BUSCADOR_EMAIL", "")   # opcional: OpenAlex y Crossref dan prioridad si lo pones
PAGE_SIZE = 20

LANGS = {  # valor -> (PubMed, Europe PMC, OpenAlex)
    "en": ("english[la]", 'LANG:"eng"', "en"),
    "es": ("spanish[la]", 'LANG:"spa"', "es"),
    "pt": ("portuguese[la]", 'LANG:"por"', "pt"),
}


class ErrorBusqueda(Exception):
    """Error con un mensaje ya redactado para personas sin experiencia técnica."""


def _ssl_context():
    try:
        import certifi  # si está instalado, trae certificados actualizados
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _fetch(url: str, params: dict | None = None, data: dict | None = None, accept="application/json") -> bytes:
    full = f"{url}?{urlencode(params)}" if params else url
    body = urlencode(data).encode() if data else None
    req = Request(full, data=body, headers={"User-Agent": USER_AGENT, "Accept": accept})
    try:
        try:
            with urlopen(req, timeout=25, context=_ssl_context()) as r:
                return r.read()
        except URLError as e:
            # El Python de python.org en macOS a veces no trae certificados instalados.
            # Estas fuentes son públicas y de solo lectura, así que se reintenta sin verificación.
            if isinstance(getattr(e, "reason", None), ssl.SSLError):
                with urlopen(req, timeout=25, context=ssl._create_unverified_context()) as r:
                    return r.read()
            raise
    except HTTPError as e:
        if e.code == 404:
            raise ErrorBusqueda("No se encontró ese registro.")
        if e.code == 429:
            raise ErrorBusqueda("Se hicieron demasiadas búsquedas seguidas. Espera 10 segundos y vuelve a intentar.")
        if e.code in (400, 414):
            raise ErrorBusqueda("La base no entendió la ecuación. Revisa los avisos debajo de la ecuación "
                                "o pulsa «Restaurar la automática».")
        raise ErrorBusqueda(f"El servidor respondió con un error ({e.code}). Intenta de nuevo en unos minutos.")
    except URLError:
        raise ErrorBusqueda("No hay conexión a internet o el servidor no responde. Revisa tu conexión.")
    except (TimeoutError, OSError):
        raise ErrorBusqueda("La búsqueda tardó demasiado. Revisa tu conexión y vuelve a intentar.")


def _get_json(url: str, params: dict | None = None, data: dict | None = None) -> dict:
    raw = _fetch(url, params, data)
    try:
        return json.loads(raw.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise ErrorBusqueda("El servidor devolvió una respuesta inesperada. Intenta de nuevo en unos minutos.")


def _clean_title(title: str) -> str:
    title = re.sub(r"<[^>]+>", "", title or "")
    title = re.sub(r"\s+", " ", title).strip()
    if title.startswith("[") and title.endswith("].") or title.startswith("[") and title.endswith("]"):
        title = title.strip("[].")          # PubMed pone entre corchetes los títulos traducidos
    return title[:-1] if title.endswith(".") else title


def _clean_journal(name: str) -> str:
    return re.sub(r"\s*\([^)]*\)\s*$", "", name or "").strip()   # "Hypertension (Dallas, Tex.)" -> "Hypertension"


def _nlm_author(name: str) -> dict:
    m = re.match(r"^(.+?)\s+([A-Z]{1,4})$", name.strip())
    if m:
        return {"family": m.group(1), "initials": m.group(2)}
    return {"family": name.strip(), "initials": "", "collective": True}


def initials_from_given(given: str) -> str:
    """'María José' -> 'M. J.';  'Jean-Paul' -> 'J.-P.'"""
    out = []
    for part in re.sub(r"[.]", " ", given or "").split():
        if "-" in part:
            out.append("-".join(s[0].upper() + "." for s in part.split("-") if s))
        elif part[:1].isalpha():
            out.append(part[0].upper() + ".")
    return " ".join(out)


def _split_display_name(name: str) -> dict:
    """OpenAlex solo da el nombre completo: se estima el apellido (se corrige con Crossref al guardar)."""
    words = name.split()
    if len(words) < 2:
        return {"family": name, "initials": ""}
    particles = {"de", "del", "da", "dos", "van", "von", "der", "la", "le", "di"}
    k = len(words) - 1
    while k > 1 and words[k - 1].lower() in particles:
        k -= 1
    return {"family": " ".join(words[k:]), "initials": initials_from_given(" ".join(words[:k]))}


def _year_bounds(y0, y1):
    return (y0 or 1800), (y1 or CURRENT_YEAR)


def search_pubmed(query: str, y0, y1, page: int, langs: list[str], free_only: bool) -> dict:
    term = query
    if langs:
        term = f"({term}) AND ({' OR '.join(LANGS[l][0] for l in langs)})"
    if free_only:
        term = f"({term}) AND free full text[sb]"
    data = {"db": "pubmed", "term": term, "retmode": "json", "retmax": PAGE_SIZE,
            "retstart": (page - 1) * PAGE_SIZE, "sort": "relevance", "tool": "BuscadorAcademico"}
    if CONTACT_EMAIL:
        data["email"] = CONTACT_EMAIL
    if NCBI_API_KEY:
        data["api_key"] = NCBI_API_KEY
    if y0 or y1:
        a, b = _year_bounds(y0, y1)
        data.update({"datetype": "pdat", "mindate": a, "maxdate": b})
    # POST: las ecuaciones largas no caben en una URL
    res = _get_json(f"{EUTILS}/esearch.fcgi", data=data)["esearchresult"]
    if res.get("ERROR"):
        raise ErrorBusqueda("PubMed no pudo interpretar la ecuación. Revisa paréntesis y comillas.")
    ids, total = res.get("idlist", []), int(res.get("count", 0))
    if not ids:
        return {"total": total, "results": []}
    time.sleep(0.34)   # PubMed permite 3 consultas por segundo sin clave
    sp = {"db": "pubmed", "id": ",".join(ids), "retmode": "json", "tool": "BuscadorAcademico"}
    if NCBI_API_KEY:
        sp["api_key"] = NCBI_API_KEY
    summ = _get_json(f"{EUTILS}/esummary.fcgi", data=sp)["result"]
    abstracts = {}
    try:
        time.sleep(0.34)
        xml = _fetch(f"{EUTILS}/efetch.fcgi", data={**{k: v for k, v in sp.items() if k != "retmode"},
                                                     "rettype": "abstract", "retmode": "xml"}, accept="text/xml")
        for art in ET.fromstring(xml).iter("PubmedArticle"):
            pmid = art.findtext(".//PMID")
            parts = []
            for ab in art.iter("AbstractText"):
                txt = "".join(ab.itertext()).strip()
                if txt:
                    parts.append((ab.get("Label", "").capitalize() + ": " if ab.get("Label") else "") + txt)
            abstracts[pmid] = " ".join(parts)
    except Exception:  # noqa: BLE001  (el resumen es opcional)
        pass
    results = []
    for pmid in summ.get("uids", []):
        d = summ[pmid]
        ids_ = {a.get("idtype"): a.get("value") for a in d.get("articleids", [])}
        year = re.search(r"\d{4}", d.get("pubdate", "") or d.get("sortpubdate", ""))
        pmc = ids_.get("pmc", "")
        results.append({
            "source": "PubMed", "pmid": pmid, "doi": ids_.get("doi", ""),
            "title": _clean_title(d.get("title", "")),
            "authors": [_nlm_author(a["name"]) for a in d.get("authors", []) if a.get("authtype") == "Author"],
            "year": year.group(0) if year else "",
            "journal": _clean_journal(d.get("fulljournalname") or d.get("source", "")),
            "volume": d.get("volume", ""), "issue": d.get("issue", ""), "pages": d.get("pages", ""),
            "pub_types": d.get("pubtype", []), "url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
            "free_url": f"https://pmc.ncbi.nlm.nih.gov/articles/{pmc}/" if pmc.startswith("PMC") else "",
            "abstract": abstracts.get(pmid, ""), "language": ",".join(d.get("lang", [])),
        })
    return {"total": total, "results": results}


def search_europepmc(query: str, y0, y1, cursor: str, langs: list[str], free_only: bool) -> dict:
    q = f"({query})"
    if y0 or y1:
        a, b = _year_bounds(y0, y1)
        q += f" AND (PUB_YEAR:[{a} TO {b}])"
    if langs:
        q += f" AND ({' OR '.join(LANGS[l][1] for l in langs)})"
    if free_only:
        q += " AND (HAS_FREE_FULLTEXT:y)"
    data = _get_json(EPMC, {"query": q, "format": "json", "resultType": "core", "pageSize": PAGE_SIZE,
                            "cursorMark": cursor or "*"})
    results = []
    for d in data.get("resultList", {}).get("result", []):
        authors = []
        for a in (d.get("authorList") or {}).get("author", []):
            if a.get("collectiveName"):
                authors.append({"family": a["collectiveName"], "initials": "", "collective": True})
            elif a.get("lastName"):
                authors.append({"family": a["lastName"], "initials": (a.get("initials") or "").replace(" ", "")})
        ji = d.get("journalInfo") or {}
        doi = d.get("doi", "")
        pmcid = d.get("pmcid", "")
        results.append({
            "source": "Europe PMC", "pmid": d.get("pmid", ""), "doi": doi,
            "title": _clean_title(d.get("title", "")), "authors": authors,
            "year": str(d.get("pubYear") or ji.get("yearOfPublication") or ""),
            "journal": _clean_journal((ji.get("journal") or {}).get("title", "")),
            "volume": ji.get("volume", ""), "issue": ji.get("issue", ""), "pages": d.get("pageInfo", ""),
            "pub_types": (d.get("pubTypeList") or {}).get("pubType", []),
            "url": f"https://doi.org/{doi}" if doi else f"https://europepmc.org/article/{d.get('source', 'MED')}/{d.get('id', '')}",
            "free_url": f"https://europepmc.org/article/PMC/{pmcid}" if pmcid else "",
            "abstract": re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", d.get("abstractText", ""))).strip(),
            "language": d.get("language", ""),
        })
    return {"total": int(data.get("hitCount", 0)), "results": results, "cursor": data.get("nextCursorMark", "")}


def _openalex_abstract(inv: dict | None) -> str:
    if not inv:
        return ""
    pos = {}
    for word, idxs in inv.items():
        for i in idxs:
            pos[i] = word
    return " ".join(pos[i] for i in sorted(pos))


def search_openalex(query: str, y0, y1, page: int, langs: list[str], free_only: bool) -> dict:
    filters = []
    if y0:
        filters.append(f"from_publication_date:{y0}-01-01")
    if y1:
        filters.append(f"to_publication_date:{y1}-12-31")
    if langs:
        filters.append("language:" + "|".join(LANGS[l][2] for l in langs))
    if free_only:
        filters.append("is_oa:true")
    params = {"search": query, "per-page": PAGE_SIZE, "page": page}
    if filters:
        params["filter"] = ",".join(filters)
    if CONTACT_EMAIL:
        params["mailto"] = CONTACT_EMAIL
    data = _get_json(OPENALEX, params)
    results = []
    for d in data.get("results", []):
        doi = re.sub(r"^https?://doi\.org/", "", d.get("doi") or "")
        loc = d.get("primary_location") or {}
        src = loc.get("source") or {}
        bib = d.get("biblio") or {}
        pages = "-".join(p for p in (bib.get("first_page"), bib.get("last_page")) if p)
        pmid = re.sub(r"\D", "", (d.get("ids") or {}).get("pmid", "") or "")
        results.append({
            "source": "OpenAlex", "pmid": pmid, "doi": doi,
            "title": _clean_title(d.get("display_name") or d.get("title") or ""),
            "authors": [_split_display_name((a.get("author") or {}).get("display_name", ""))
                        for a in d.get("authorships", []) if (a.get("author") or {}).get("display_name")],
            "authors_approx": True,
            "year": str(d.get("publication_year") or ""),
            "journal": src.get("display_name", ""),
            "volume": bib.get("volume") or "", "issue": bib.get("issue") or "", "pages": pages,
            "pub_types": [d.get("type", "")] if d.get("type") not in (None, "article") else [],
            "url": f"https://doi.org/{doi}" if doi else (loc.get("landing_page_url") or d.get("id", "")),
            "free_url": (d.get("open_access") or {}).get("oa_url") or "",
            "abstract": _openalex_abstract(d.get("abstract_inverted_index")),
            "language": d.get("language") or "",
        })
    return {"total": int((data.get("meta") or {}).get("count", 0)), "results": results}


def crossref_lookup(doi: str) -> dict:
    """Metadatos completos de un DOI (Crossref, gratis). Sirve para 'Agregar por DOI' y para corregir autores."""
    doi = re.sub(r"^(https?://(dx\.)?doi\.org/|doi:\s*)", "", (doi or "").strip(), flags=re.I).strip()
    if not DOI_RX.match(doi):
        raise ErrorBusqueda("Eso no parece un DOI. Un DOI empieza con «10.», por ejemplo 10.1056/NEJMoa2034577.")
    params = {"mailto": CONTACT_EMAIL} if CONTACT_EMAIL else None
    m = _get_json(CROSSREF + quote(doi, safe="/:;()._-"), params).get("message", {})
    authors = []
    for a in m.get("author", []):
        if a.get("family"):
            authors.append({"family": a["family"], "initials": initials_from_given(a.get("given", ""))})
        elif a.get("name"):
            authors.append({"family": a["name"], "initials": "", "collective": True})
    parts = ((m.get("issued") or m.get("published-print") or m.get("published-online") or {})
             .get("date-parts") or [[None]])[0]
    title = (m.get("title") or [""])[0]
    return {
        "source": "DOI (Crossref)", "pmid": "", "doi": m.get("DOI", doi),
        "title": _clean_title(title), "authors": authors,
        "year": str(parts[0]) if parts and parts[0] else "",
        "journal": _clean_journal((m.get("container-title") or [""])[0]),
        "volume": m.get("volume", ""), "issue": m.get("issue", ""),
        "pages": m.get("page", "") or m.get("article-number", ""),
        "pub_types": [m.get("type", "")], "url": f"https://doi.org/{m.get('DOI', doi)}", "free_url": "",
        "abstract": re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", m.get("abstract", ""))).strip(),
    }


def enrich_record(r: dict) -> dict:
    """Si el registro viene de OpenAlex (apellidos estimados) o le faltan datos, se completa con Crossref."""
    needs = r.get("authors_approx") or not r.get("volume") or not r.get("authors")
    if not (needs and r.get("doi")):
        return r
    try:
        cr = crossref_lookup(r["doi"])
    except Exception:  # noqa: BLE001
        return r
    out = dict(r)
    for k in ("authors", "volume", "issue", "pages", "journal", "year"):
        if cr.get(k):
            out[k] = cr[k]
    out.pop("authors_approx", None)
    return out


def run_search(p: dict) -> dict:
    """Consulta las fuentes en paralelo e intercala los resultados."""
    y0, y1 = p.get("y0"), p.get("y1")
    page = int(p.get("page") or 1)
    langs = [l for l in p.get("langs") or [] if l in LANGS]
    free_only = bool(p.get("free_only"))
    sources = p.get("sources") or []
    q_pm, q_gen = p.get("q_pubmed", ""), p.get("q_generic", "")
    q_plain = p.get("q_plain") or q_gen.replace("*", "")
    jobs = {}
    with ThreadPoolExecutor(max_workers=3) as pool:
        if "pubmed" in sources and q_pm.strip():
            jobs["PubMed"] = pool.submit(search_pubmed, q_pm, y0, y1, page, langs, free_only)
        if "europepmc" in sources and q_gen.strip() and p.get("epmc_cursor", "*"):
            jobs["Europe PMC"] = pool.submit(search_europepmc, q_gen, y0, y1, p.get("epmc_cursor", "*"), langs,
                                             free_only)
        if "openalex" in sources and q_plain.strip():
            jobs["OpenAlex"] = pool.submit(search_openalex, q_plain, y0, y1, page, langs, free_only)
        out = {"totals": {}, "errors": {}, "results": [], "epmc_cursor": ""}
        lists = []
        for name, fut in jobs.items():
            try:
                res = fut.result()
                out["totals"][name] = res["total"]
                lists.append(res["results"])
                if name == "Europe PMC":
                    out["epmc_cursor"] = res.get("cursor", "")
            except ErrorBusqueda as e:
                out["errors"][name] = str(e)
            except Exception as e:  # noqa: BLE001
                out["errors"][name] = f"Error inesperado ({type(e).__name__})."
                log_error(traceback.format_exc())
    out["results"] = [r for grp in zip_longest(*lists) for r in grp if r]
    for r in out["results"]:
        r["rid"] = record_id(r)
    return out


def external_links(q: dict, y0, y1) -> list[dict]:
    """Método 2: la misma búsqueda como enlace, para fuentes sin API abierta (no se hace scraping)."""
    a, b = _year_bounds(y0, y1)
    gen, simple, scholar = q.get("generic", ""), q.get("simple", ""), q.get("scholar", "")
    scielo = [("q", gen), ("lang", "es")]
    if y0 and 0 <= b - y0 <= 40:
        scielo += [("filter[year_cluster][]", str(y)) for y in range(y0, b + 1)]
    links = [
        ("PubMed", "La base médica de referencia (EE. UU.).",
         "https://pubmed.ncbi.nlm.nih.gov/?" + urlencode({"term": q.get("pubmed", ""), "filter": f"years.{a}-{b}"})),
        ("SciELO", "Revistas de Latinoamérica, España y Portugal.", "https://search.scielo.org/?" + urlencode(scielo)),
        ("BVS / LILACS", "Biblioteca Virtual en Salud de la OPS. Ajusta los años en la página.",
         "https://pesquisa.bvsalud.org/portal/?" + urlencode({"lang": "es", "q": gen})),
        ("Europe PMC", "Artículos biomédicos europeos y de PubMed Central.",
         "https://europepmc.org/search?query=" + quote_plus(f"({gen}) AND (PUB_YEAR:[{a} TO {b}])")),
        ("Google Académico", "Versión corta de la ecuación.",
         "https://scholar.google.com/scholar?" + urlencode({"q": scholar or simple, "as_ylo": y0 or "",
                                                              "as_yhi": y1 or ""})),
        ("ScienceDirect", "Revistas de Elsevier. Versión corta de la ecuación.",
         "https://www.sciencedirect.com/search?" + urlencode({"qs": simple, "date": f"{max(a, 1823)}-{b}"})),
    ]
    return [{"name": n, "hint": h, "url": u} for n, h, u in links]


# ============================================================================
# PARTE 5. CITAS APA 7.ª edición (en español o en inglés)
# ============================================================================
APA_WORDS = {"es": {"and": "y", "nd": "s. f.", "untitled": "Sin título"},
             "en": {"and": "&", "nd": "n.d.", "untitled": "Untitled"}}
_MINOR = {"a", "an", "and", "as", "at", "but", "by", "for", "in", "nor", "of", "on", "or", "the", "to", "with",
          "de", "del", "la", "las", "los", "el", "y", "e", "en", "para", "por", "und", "der", "die", "das"}


def _initials(ini: str) -> str:
    ini = (ini or "").strip()
    if not ini or "." in ini:
        return ini                        # ya viene como "J. A."
    if "-" in ini:
        return "-".join(". ".join(p) + "." for p in ini.split("-"))
    return " ".join(c.upper() + "." for c in re.sub(r"[^A-Za-zÁÉÍÓÚÑÜáéíóúñü]", "", ini))


def _author(a: dict) -> str:
    return a["family"] if a.get("collective") or not a.get("initials") else f"{a['family']}, {_initials(a['initials'])}"


def apa_authors(authors: list[dict], lang: str = "es") -> str:
    names = [_author(a) for a in authors or [] if a.get("family")]
    conj = APA_WORDS[lang]["and"]
    if not names:
        return ""
    if len(names) == 1:
        return names[0]
    if len(names) <= 20:
        return ", ".join(names[:-1]) + f", {conj} {names[-1]}"
    return ", ".join(names[:19]) + f", . . . {names[-1]}"     # APA 7: 19 autores, puntos suspensivos y el último


def _title_case(name: str) -> str:
    out = []
    for i, w in enumerate((name or "").split()):
        if re.search(r"[A-Z].*[A-Z]", w):
            out.append(w)                 # siglas: BMJ, JAMA
        elif i > 0 and w.lower() in _MINOR:
            out.append(w.lower())
        else:
            out.append(w[:1].upper() + w[1:])
    return " ".join(out)


def _pages(p: str) -> str:
    m = re.match(r"^([A-Za-z]?)(\d+)\s*[-–]\s*([A-Za-z]?)(\d+)$", str(p or ""))
    if not m:
        return str(p or "")
    p1, start, p2, end = m.groups()
    if len(end) < len(start):
        end = start[: len(start) - len(end)] + end      # PubMed abrevia: 123-9 -> 123–129
    return f"{p1}{start}–{p2 or p1}{end}"


def _end(s: str) -> str:
    s = (s or "").strip()
    return s if s[-1:] in ".?!" else s + "."


MONTHS = {
    "es": ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
           "noviembre", "diciembre"],
    "en": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
           "November", "December"],
}


def _apa_date(r: dict, lang: str) -> str:
    """(2023, 16 de marzo) · (2023, marzo) · (2023) · (s. f.)"""
    y, m, d = r.get("year"), _int_or_zero(r.get("month")), _int_or_zero(r.get("day"))
    if not y:
        return f"({APA_WORDS[lang]['nd']})"
    if 1 <= m <= 12:
        mon = MONTHS[lang][m - 1]
        if 1 <= d <= 31:
            return f"({y}, {d} de {mon})" if lang == "es" else f"({y}, {mon} {d})"
        return f"({y}, {mon})"
    return f"({y})"


def _long_date(iso: str, lang: str) -> str:
    try:
        y, m, d = (int(x) for x in iso.split("-"))
    except (ValueError, AttributeError):
        t = date.today()
        y, m, d = t.year, t.month, t.day
    mon = MONTHS[lang][m - 1]
    return f"{d} de {mon} de {y}" if lang == "es" else f"{mon} {d}, {y}"


def _int_or_zero(v) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _norm_name(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", strip_accents((s or "").lower()))


def web_site_omitted(r: dict) -> bool:
    """APA 7: si el autor y el sitio son el mismo, el nombre del sitio se omite."""
    site = _norm_name(r.get("site", ""))
    if not site:
        return False
    names = [_norm_name(a.get("family", "")) for a in r.get("authors") or []]
    abbr = _norm_name(r.get("abbr", ""))
    return any(n and (n == site or site in n or n in site) for n in names) or (abbr and abbr == site)


def _web_segments(r: dict, lang: str) -> list[tuple[str, bool]]:
    """Página web: Autor. (fecha). *Título*. Sitio. URL"""
    words = APA_WORDS[lang]
    authors = apa_authors(r.get("authors"), lang)
    when = _apa_date(r, lang) + "."
    title = (r.get("title") or words["untitled"]).strip()
    t_end = "" if title[-1:] in ".?!" else "."
    if authors:
        seg = [(f"{_end(authors)} {when} ", False), (title, True), (t_end, False)]
    else:
        seg = [(title, True), (f"{t_end} {when}", False)]
    site = (r.get("site") or "").strip()
    if site and not web_site_omitted(r):
        seg.append((f" {_end(site)}", False))
    url = (r.get("url") or "").strip()
    if url:
        if r.get("changes"):
            when_read = _long_date(r.get("retrieved", ""), lang)
            seg.append((f" Recuperado el {when_read}, de {url}" if lang == "es" else f" Retrieved {when_read}, from {url}",
                        False))
        else:
            seg.append((f" {url}", False))
    return seg


def apa_segments(r: dict, lang: str = "es") -> list[tuple[str, bool]]:
    """Cita APA como lista de (texto, cursiva)."""
    if r.get("kind") == "web":
        return _web_segments(r, lang)
    words = APA_WORDS[lang]
    authors = apa_authors(r.get("authors"), lang)
    year = f"({r['year']})." if r.get("year") else f"({words['nd']})."
    title = _end(r.get("title") or words["untitled"])
    seg: list[tuple[str, bool]] = [(f"{_end(authors)} {year} {title}" if authors else f"{title} {year}", False)]
    journal = _title_case(r.get("journal", ""))
    if journal:
        seg.append((" ", False))
        seg.append((journal, True))
        if r.get("volume"):
            seg += [(", ", False), (str(r["volume"]), True)]
        if r.get("issue"):
            seg.append((f"({r['issue']})", False))
        if r.get("pages"):
            seg.append((f", {_pages(r['pages'])}", False))
        seg.append((".", False))
    doi = re.sub(r"^https?://(dx\.)?doi\.org/", "", r.get("doi") or "")
    link = f"https://doi.org/{doi}" if doi else r.get("url", "")
    if link:
        seg.append((f" {link}", False))
    return seg


def apa_text(r: dict, lang: str = "es") -> str:
    return "".join(t for t, _ in apa_segments(r, lang))


def apa_html(r: dict, lang: str = "es") -> str:
    esc = lambda s: s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")   # noqa: E731
    return "".join(f"<i>{esc(t)}</i>" if it else esc(t) for t, it in apa_segments(r, lang))


def apa_intext(r: dict, lang: str = "es") -> str:
    """Cita dentro del texto: (García, 2021), (García y López, 2021), (García et al., 2021)."""
    words = APA_WORDS[lang]
    fam = [a["family"] for a in r.get("authors") or [] if a.get("family")]
    year = r.get("year") or words["nd"]
    if not fam:
        short = " ".join((r.get("title") or words["untitled"]).split()[:4])
        if r.get("kind") == "web":
            return f"({short}, {year})"
        return f"(«{short}», {year})" if lang == "es" else f'("{short}," {year})'
    if len(fam) == 1:
        who = fam[0] + (f" [{r['abbr']}]" if r.get("abbr") else "")
    elif len(fam) == 2:
        who = f"{fam[0]} {words['and']} {fam[1]}"
    else:
        who = f"{fam[0]} et al."
    return f"({who}, {year})"


def apa_sort_key(r: dict) -> str:
    first = r["authors"][0]["family"] if r.get("authors") else r.get("title", "")
    return strip_accents(first).lower()


def to_rtf(records: list[dict], lang: str = "es") -> str:
    """Documento RTF (se abre en Word, LibreOffice y Pages) con cursivas, doble espacio y sangría francesa."""
    def esc(s: str) -> str:
        out = []
        for ch in s:
            if ch in "\\{}":
                out.append("\\" + ch)
            elif ord(ch) > 127:
                code = ord(ch)
                out.append(f"\\u{code if code < 32768 else code - 65536}?")
            else:
                out.append(ch)
        return "".join(out)

    head = "Referencias" if lang == "es" else "References"
    body = [r"{\rtf1\ansi\deff0{\fonttbl{\f0 Times New Roman;}}\f0\fs24",
            r"\pard\qc\sl480\slmult1\b " + head + r"\b0\par"]
    for rec in records:
        parts = "".join((r"{\i " + esc(t) + "}") if it else esc(t) for t, it in apa_segments(rec, lang))
        body.append(r"\pard\sl480\slmult1\fi-720\li720 " + parts + r"\par")
    body.append("}")
    return "\n".join(body)


# ============================================================================
# PARTE 6. ALMACENAMIENTO LOCAL (lista de Citados y registro de errores)
# ============================================================================
_store_lock = threading.Lock()


def log_error(text: str) -> None:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] v{APP_VERSION} {platform.platform()}\n{text}\n")
    except Exception:
        pass


def record_id(r: dict) -> str:
    if r.get("doi"):
        return "doi:" + r["doi"].lower()
    if r.get("pmid"):
        return "pmid:" + str(r["pmid"])
    if r.get("kind") == "web" and r.get("url"):
        return "url:" + re.sub(r"^https?://(www\.)?", "", r["url"].strip().lower()).rstrip("/")
    return "t:" + re.sub(r"\W+", "", (r.get("title") or "").lower())[:80]


def load_cited() -> list[dict]:
    try:
        items = json.loads(CITED_FILE.read_text(encoding="utf-8"))
        return items if isinstance(items, list) else []
    except Exception:
        return []


def save_cited(items: list[dict]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = CITED_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(CITED_FILE)


def cited_view(lang: str) -> list[dict]:
    items = sorted(load_cited(), key=lambda c: apa_sort_key(c["meta"]))
    return [{"id": c["id"], "meta": c["meta"], "html": apa_html(c["meta"], lang), "text": apa_text(c["meta"], lang),
             "intext": apa_intext(c["meta"], lang), "saved": c.get("saved", 0), "search_id": c.get("search_id"),
             "kind": c["meta"].get("kind") or "article"} for c in items]


# ============================================================================
# PARTE 6b. CITAR ENLACES, REFERENCIAS MANUALES E HISTORIAL
# ============================================================================
from html.parser import HTMLParser  # noqa: E402  (biblioteca estándar)

WEB_UA = f"Mozilla/5.0 (compatible; BuscadorAcademico/{APP_VERSION}; uso academico)"
SITE_NAMES = {  # nombres correctos de sitios frecuentes cuando la página no los declara
    "who.int": "Organización Mundial de la Salud", "paho.org": "Organización Panamericana de la Salud",
    "cdc.gov": "Centers for Disease Control and Prevention", "nih.gov": "National Institutes of Health",
    "gob.mx": "Gobierno de México", "imss.gob.mx": "Instituto Mexicano del Seguro Social",
    "medlineplus.gov": "MedlinePlus", "mayoclinic.org": "Mayo Clinic", "unicef.org": "UNICEF",
    "wikipedia.org": "Wikipedia",
}
KNOWN_ABBR = {"organizacion mundial de la salud": "OMS", "world health organization": "WHO",
              "organizacion panamericana de la salud": "OPS", "instituto mexicano del seguro social": "IMSS",
              "centers for disease control and prevention": "CDC", "national institutes of health": "NIH"}


class _MetaParser(HTMLParser):
    """Lee <meta>, <title> y JSON-LD de una página sin bibliotecas externas."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.meta: dict[str, list[str]] = {}
        self.title = ""
        self.jsonld: list[str] = []
        self._in_title = False
        self._in_ld = False
        self._buf: list[str] = []
        self.lang = ""

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "html" and a.get("lang"):
            self.lang = a["lang"][:2].lower()
        if tag == "meta":
            key = (a.get("name") or a.get("property") or a.get("itemprop") or "").strip().lower()
            if key and a.get("content"):
                self.meta.setdefault(key, []).append(a["content"].strip())
        elif tag == "title" and not self.title:
            self._in_title, self._buf = True, []
        elif tag == "script" and "ld+json" in a.get("type", "").lower():
            self._in_ld, self._buf = True, []

    def handle_endtag(self, tag):
        if tag == "title" and self._in_title:
            self.title, self._in_title = re.sub(r"\s+", " ", "".join(self._buf)).strip(), False
        elif tag == "script" and self._in_ld:
            self.jsonld.append("".join(self._buf))
            self._in_ld = False

    def handle_data(self, data):
        if self._in_title or self._in_ld:
            self._buf.append(data)


def _first(meta: dict, *keys: str) -> str:
    for k in keys:
        for v in meta.get(k, []):
            if v.strip():
                return v.strip()
    return ""


def parse_date_str(s: str) -> tuple[str, int, int]:
    """'2023-03-16T10:00Z', '16/03/2023', '03/2023', '2023/03/16', '2023' -> ('2023', 3, 16)."""
    s = (s or "").strip()
    m = re.match(r"^(\d{4})[-/.](\d{1,2})(?:[-/.](\d{1,2}))?", s)
    if m:
        return m.group(1), int(m.group(2)), int(m.group(3) or 0)
    m = re.match(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})", s)
    if m:
        return m.group(3), int(m.group(2)), int(m.group(1))
    m = re.match(r"^(\d{1,2})[-/.](\d{4})$", s)
    if m:
        return m.group(2), int(m.group(1)), 0
    m = re.search(r"\b(1[89]\d\d|20\d\d)\b", s)
    if m:
        low = strip_accents(s.lower())
        month = next((i + 1 for lang in ("es", "en") for i, n in enumerate(MONTHS[lang])
                      if strip_accents(n.lower()) in low), 0)
        day = re.search(r"\b(\d{1,2})\b", re.sub(m.group(1), "", s))
        return m.group(1), month, int(day.group(1)) if (day and month) else 0
    return "", 0, 0


def date_to_str(r: dict) -> str:
    y, m, d = r.get("year") or "", _int_or_zero(r.get("month")), _int_or_zero(r.get("day"))
    if y and m and d:
        return f"{d:02d}/{m:02d}/{y}"
    if y and m:
        return f"{m:02d}/{y}"
    return str(y)


def parse_person(name: str) -> dict:
    """'Pérez, Juan A.' o 'Juan A. Pérez' -> {'family': 'Pérez', 'initials': 'J. A.'}."""
    name = re.sub(r"\s+", " ", (name or "").strip())
    if "," in name:
        fam, given = name.split(",", 1)
        return {"family": fam.strip(), "initials": initials_from_given(given)}
    parts = name.split(" ")
    if len(parts) == 1:
        return {"family": name, "initials": "", "collective": True}
    return {"family": parts[-1], "initials": initials_from_given(" ".join(parts[:-1]))}


def parse_authors_str(s: str) -> list[dict]:
    """'Pérez, J. A.; García, M.'  o  'Organización Mundial de la Salud'."""
    out = []
    for chunk in re.split(r"\s*;\s*", (s or "").strip()):
        if not chunk:
            continue
        if "," in chunk:
            fam, ini = chunk.split(",", 1)
            ini = ini.strip()
            if ini and not re.search(r"[a-záéíóúñ]{2}", ini):          # ya son iniciales: "J. A."
                out.append({"family": fam.strip(), "initials": ini})
            else:
                out.append({"family": fam.strip(), "initials": initials_from_given(ini)})
        else:
            out.append({"family": chunk, "initials": "", "collective": True})
    return out


def authors_to_str(authors: list[dict]) -> str:
    out = []
    for a in authors or []:
        if a.get("collective") or not a.get("initials"):
            out.append(a.get("family", ""))
        else:
            out.append(f"{a['family']}, {_initials(a['initials'])}")
    return "; ".join(x for x in out if x)


def normalize_manual(r: dict) -> dict:
    """Convierte lo que se escribe en el formulario (texto) en un registro listo para APA."""
    r = dict(r or {})
    if "authors_str" in r:
        r["authors"] = parse_authors_str(r.pop("authors_str"))
    if "date_str" in r:
        y, m, d = parse_date_str(r.pop("date_str"))
        r.update({"year": y, "month": m, "day": d})
    for k in ("title", "site", "journal", "volume", "issue", "pages", "doi", "url", "abbr", "year"):
        if isinstance(r.get(k), str):
            r[k] = r[k].strip()
    if r.get("doi"):
        r["doi"] = re.sub(r"^(https?://(dx\.)?doi\.org/|doi:\s*)", "", r["doi"], flags=re.I)
    if r.get("url") and not re.match(r"^https?://", r["url"], re.I):
        r["url"] = "https://" + r["url"]
    if r.get("kind") == "web":
        if r.get("changes") and not r.get("retrieved"):
            r["retrieved"] = date.today().isoformat()
        if not r.get("abbr") and len(r.get("authors") or []) == 1 and r["authors"][0].get("collective"):
            r["abbr"] = KNOWN_ABBR.get(strip_accents(r["authors"][0]["family"].lower()), "")
    r.setdefault("source", "Agregado a mano")
    return r


def form_fields(r: dict) -> dict:
    """Registro -> campos del formulario (para «Editar» y para lo leído de un enlace)."""
    out = dict(r)
    out["authors_str"] = authors_to_str(r.get("authors") or [])
    out["date_str"] = date_to_str(r)
    return out


def _walk_ld(node, found: list):
    if isinstance(node, list):
        for n in node:
            _walk_ld(n, found)
    elif isinstance(node, dict):
        if "@graph" in node:
            _walk_ld(node["@graph"], found)
        found.append(node)


def _ld_names(v) -> list[tuple[str, bool]]:
    """Autores de JSON-LD como (nombre, es_organización)."""
    out = []
    for a in v if isinstance(v, list) else [v]:
        if isinstance(a, dict) and a.get("name"):
            out.append((str(a["name"]), "organization" in str(a.get("@type", "")).lower()))
        elif isinstance(a, str) and not a.startswith("http"):
            out.append((a, False))
    return out


def _clean_page_title(title: str, site: str) -> str:
    parts = re.split(r"\s+[|–—-]\s+", title)
    if len(parts) > 1:
        tail = _norm_name(parts[-1])
        if not site or tail in _norm_name(site) or _norm_name(site) in tail or len(parts[-1]) < 45:
            return " – ".join(parts[:-1]).strip()
    return title.strip()


def link_lookup(url: str) -> dict:
    """Lee una página y devuelve los datos para citarla. Si la página es un artículo con DOI, usa Crossref."""
    url = (url or "").strip()
    if not url:
        raise ErrorBusqueda("Pega primero el enlace de la página que quieres citar.")
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    host = (urlparse(url).hostname or "").lower()
    if not host or "." not in host:
        raise ErrorBusqueda("Eso no parece un enlace. Cópialo completo desde la barra del navegador.")
    doi_in_url = DOI_RX.search(url)
    if doi_in_url and "doi.org" in host:
        rec = crossref_lookup(doi_in_url.group(1))
        return {"kind": "article", "record": form_fields(rec),
                "note": "El enlace es un DOI: lo cito como artículo de revista."}

    req = Request(url, headers={"User-Agent": WEB_UA, "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
                                "Accept-Language": "es,en;q=0.8"})
    try:
        try:
            resp = urlopen(req, timeout=20, context=_ssl_context())
        except URLError as e:
            if isinstance(getattr(e, "reason", None), ssl.SSLError):
                resp = urlopen(req, timeout=20, context=ssl._create_unverified_context())
            else:
                raise
        with resp:
            ctype = resp.headers.get("Content-Type", "")
            final_url = resp.geturl() or url
            raw = resp.read(3_000_000)
    except HTTPError as e:
        if e.code in (401, 403):
            raise ErrorBusqueda("Esa página no deja leer sus datos automáticamente. Usa la pestaña «Manual» "
                                "y escribe los datos tú.")
        if e.code == 404:
            raise ErrorBusqueda("La página no existe (error 404). Revisa que el enlace esté completo.")
        raise ErrorBusqueda(f"La página respondió con un error ({e.code}). Puedes citarla desde «Manual».")
    except (URLError, TimeoutError, OSError):
        raise ErrorBusqueda("No pude abrir la página. Revisa tu conexión y que el enlace sea correcto.")

    today = date.today().isoformat()
    site_default = next((v for k, v in SITE_NAMES.items() if host == k or host.endswith("." + k)), "")
    domain = re.sub(r"^www\.", "", host)
    if "pdf" in ctype.lower():
        name = re.sub(r"[-_]+", " ", Path(urlparse(final_url).path).stem).strip()
        rec = {"kind": "web", "title": name[:1].upper() + name[1:], "site": site_default or domain, "url": url,
               "authors": [{"family": site_default, "initials": "", "collective": True}] if site_default else [],
               "year": "", "month": 0, "day": 0, "retrieved": today}
        return {"kind": "web", "record": form_fields(rec),
                "note": "Es un documento PDF: no trae datos que yo pueda leer. Completa el autor y la fecha."}

    charset = re.search(r"charset=([\w-]+)", ctype or "", re.I)
    enc = charset.group(1) if charset else None
    if not enc:
        m = re.search(rb"<meta[^>]+charset=[\"']?([\w-]+)", raw[:4000], re.I)
        enc = m.group(1).decode("ascii", "ignore") if m else "utf-8"
    try:
        text = raw.decode(enc, errors="replace")
    except LookupError:
        text = raw.decode("utf-8", errors="replace")
    p = _MetaParser()
    try:
        p.feed(text)
    except Exception:  # noqa: BLE001  (HTML muy roto: se usa lo que se alcanzó a leer)
        pass
    meta = p.meta
    ld: list[dict] = []
    for block in p.jsonld:
        try:
            _walk_ld(json.loads(block), ld)
        except (json.JSONDecodeError, ValueError):
            continue
    ld_main = next((n for n in ld if re.search(r"Article|WebPage|Report|Posting|Guideline|CreativeWork",
                                                str(n.get("@type", "")))), ld[0] if ld else {})

    # ¿Es un artículo científico? (etiquetas Highwire que usan las revistas, o un DOI declarado)
    doi = _first(meta, "citation_doi", "prism.doi", "dc.identifier", "bepress_citation_doi")
    dm = DOI_RX.search(doi or "")
    if dm:
        try:
            rec = crossref_lookup(dm.group(1))
            rec["url"] = rec.get("url") or url
            return {"kind": "article", "record": form_fields(rec),
                    "note": "Esta página es un artículo con DOI: lo cito como artículo de revista."}
        except ErrorBusqueda:
            pass
    if _first(meta, "citation_journal_title"):
        y, mo, d = parse_date_str(_first(meta, "citation_publication_date", "citation_date",
                                         "citation_online_date"))
        first, last = _first(meta, "citation_firstpage"), _first(meta, "citation_lastpage")
        rec = {"kind": "article", "source": "Enlace", "title": _clean_title(_first(meta, "citation_title")),
               "authors": [parse_person(a) for a in meta.get("citation_author", [])],
               "year": y, "journal": _first(meta, "citation_journal_title"),
               "volume": _first(meta, "citation_volume"), "issue": _first(meta, "citation_issue"),
               "pages": f"{first}-{last}" if first and last else first, "doi": "", "url": url}
        return {"kind": "article", "record": form_fields(rec),
                "note": "Esta página es un artículo de revista: revisa los datos antes de guardar."}

    pub = ld_main.get("publisher")
    pub_name = str(pub.get("name", "")) if isinstance(pub, dict) else ""
    site = _first(meta, "og:site_name", "application-name", "dc.publisher")
    looks_like_domain = bool(site) and "." in site and " " not in site
    if not site or looks_like_domain or (site_default and len(site) <= 5):
        site = site_default or pub_name or site or domain
    raw_title = (_first(meta, "citation_title", "og:title", "twitter:title", "dc.title")
                 or str(ld_main.get("headline") or ld_main.get("name") or "") or p.title)
    title = _clean_page_title(re.sub(r"\s+", " ", raw_title), site)

    authors: list[dict] = []
    names = meta.get("citation_author", []) or meta.get("author", []) or meta.get("dc.creator", [])
    names += [a for a in meta.get("article:author", []) if not a.startswith("http")]
    for n in names:
        for piece in re.split(r"\s*(?:;|\by\b|\band\b|&)\s*", n):
            if piece.strip():
                authors.append(parse_person(piece))
    if not authors and ld_main.get("author"):
        for n, is_org in _ld_names(ld_main["author"]):
            authors.append({"family": n, "initials": "", "collective": True} if is_org else parse_person(n))
    # Sin autor persona: APA usa a la organización responsable (y entonces se omite el sitio).
    if not authors and site and site != domain:
        authors = [{"family": site, "initials": "", "collective": True}]
    authors = [a for a in authors if len(a.get("family", "")) < 120][:25]

    y, mo, d = parse_date_str(_first(meta, "citation_publication_date", "article:published_time",
                                     "datepublished", "dc.date", "dc.date.issued", "date", "pubdate")
                              or str(ld_main.get("datePublished") or "")
                              or _first(meta, "article:modified_time", "og:updated_time", "last-modified",
                                        "datemodified") or str(ld_main.get("dateModified") or ""))
    rec = {"kind": "web", "title": title, "site": site, "url": url, "authors": authors,
           "year": y, "month": mo, "day": d, "retrieved": today, "source": "Enlace"}
    missing = [n for n, ok in (("el autor", authors), ("la fecha", y), ("el título", title)) if not ok]
    note = ("Datos leídos de la página. Revísalos antes de guardar." if not missing else
            "No encontré " + " ni ".join(missing) + " en la página. Complétalo si lo ves en ella; "
            "si no hay fecha, la cita dirá «s. f.».")
    return {"kind": "web", "record": form_fields(rec), "note": note}


def apa_preview(r: dict, lang: str) -> dict:
    rec = normalize_manual(r)
    notes = []
    if rec.get("kind") == "web" and web_site_omitted(rec):
        notes.append("El nombre del sitio se omite porque coincide con el autor, como indica APA 7.")
    if rec.get("kind") == "web" and not rec.get("year"):
        notes.append("Sin fecha de publicación: APA 7 usa «s. f.» (sin fecha).")
    if not rec.get("authors"):
        notes.append("Sin autor: APA 7 pone el título en el lugar del autor.")
    return {"html": apa_html(rec, lang), "text": apa_text(rec, lang), "intext": apa_intext(rec, lang),
            "notes": notes, "id": record_id(rec)}


# ---------------------------------------------------------------- historial
def load_hist() -> list[dict]:
    try:
        items = json.loads(HIST_FILE.read_text(encoding="utf-8"))
        return items if isinstance(items, list) else []
    except Exception:
        return []


def save_hist(items: list[dict]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = HIST_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(items[:200], ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(HIST_FILE)


def hist_add(entry: dict) -> str:
    keep = ("text", "answers", "humans", "y0", "y1", "sources", "langs", "free_only", "concepts", "totals",
            "query_pubmed", "query_generic", "edited")
    e = {k: entry.get(k) for k in keep}
    with _store_lock:
        items = load_hist()
        if items and items[0].get("text") == e["text"] and items[0].get("query_pubmed") == e["query_pubmed"] \
                and time.time() - items[0].get("at", 0) < 3600:
            items[0].update(e)                        # la misma búsqueda repetida: se actualiza, no se duplica
            items[0]["at"] = time.time()
            hid = items[0]["id"]
        else:
            hid = f"h{int(time.time() * 1000)}"
            items.insert(0, {"id": hid, "at": time.time(), **e})
        save_hist(items)
    return hid


def hist_view(lang: str = "es") -> list[dict]:
    cited = load_cited()
    out = []
    for h in load_hist():
        saved = [c for c in cited if c.get("search_id") == h["id"]]
        out.append({**h, "saved": [{"id": c["id"], "intext": apa_intext(c["meta"], lang),
                                    "title": c["meta"].get("title", "")} for c in saved]})
    return out


# ============================================================================
# PARTE 7. SERVIDOR LOCAL (solo escucha en 127.0.0.1: nadie más puede entrar)
# ============================================================================
EXAMPLES = [
    "tratamientos de hipertensión en embarazadas sin fármacos",
    "diabetes en niños o adolescentes de los últimos 5 años",
    "ejercicio para la depresión en adultos mayores, revisiones sistemáticas",
    "fibromialgia sin cirugía",
]
_state = {"last_ping": time.time(), "pinged": False, "window": None}
HELP_FILE_NAMES = ("Instrucciones_de_uso.html", "Instrucciones_de_uso.pdf")


def app_folder() -> Path:
    return Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent


def _help_folders() -> list[Path]:
    """Carpeta del programa y, si es una app empaquetada, la carpeta interna donde viaja la guía."""
    out = [app_folder()]
    if getattr(sys, "_MEIPASS", None):
        out.append(Path(sys._MEIPASS))
    exe = Path(sys.executable).resolve()
    if exe.parent.name == "MacOS":            # dentro de «Buscador Academico.app/Contents/MacOS»
        out += [exe.parent.parent / "Resources", exe.parent.parent.parent.parent]
    return out


def say(msg: str) -> None:
    """print() que no falla cuando no hay consola (pythonw en Windows)."""
    try:
        if sys.stdout:
            print(msg, flush=True)
    except Exception:
        pass


def _int_or_none(v):
    try:
        return int(v) if v not in (None, "", "null") else None
    except (TypeError, ValueError):
        return None


class Handler(BaseHTTPRequestHandler):
    server_version = "BuscadorAcademico/" + APP_VERSION

    def log_message(self, *_args):      # silencio en la consola
        pass

    # ------------------------------------------------------------------ utilidades
    def _host_ok(self) -> bool:
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0]
        return host in ("127.0.0.1", "localhost")

    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def _body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n > 2_000_000:
            raise ValueError("demasiado grande")
        raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw.decode("utf-8") or "{}")

    def _touch(self):
        _state["last_ping"] = time.time()
        _state["pinged"] = True

    # ------------------------------------------------------------------ GET
    def do_GET(self):
        if not self._host_ok():
            return self._send(403, b"Forbidden", "text/plain")
        url = urlparse(self.path)
        qs = {k: v[0] for k, v in parse_qs(url.query).items()}
        try:
            if url.path in ("/", "/index.html"):
                return self._send(200, APP_HTML.encode("utf-8"), "text/html; charset=utf-8")
            if url.path == "/ayuda":
                for name, folder in itertools.product(HELP_FILE_NAMES, _help_folders()):
                    p = folder / name
                    if p.exists():
                        ctype = "text/html; charset=utf-8" if name.endswith(".html") else "application/pdf"
                        return self._send(200, p.read_bytes(), ctype)
                return self._send(200, HELP_FALLBACK.encode("utf-8"), "text/html; charset=utf-8")
            if url.path == "/api/config":
                self._touch()
                return self._json({"year": CURRENT_YEAR, "version": APP_VERSION, "examples": EXAMPLES,
                                   "data_file": str(CITED_FILE), "app": _state["window"] is not None})
            if url.path == "/api/cited":
                return self._json({"items": cited_view(qs.get("style", "es"))})
            if url.path == "/api/history":
                return self._json({"items": hist_view(qs.get("style", "es"))})
            if url.path == "/api/export":
                lang = qs.get("style", "es")
                items = [c["meta"] for c in sorted(load_cited(), key=lambda c: apa_sort_key(c["meta"]))]
                if qs.get("fmt") == "txt":
                    body = ("\ufeff" + "\r\n\r\n".join(apa_text(m, lang) for m in items)).encode("utf-8")
                    return self._send(200, body, "text/plain; charset=utf-8",
                                      {"Content-Disposition": 'attachment; filename="Referencias_APA.txt"'})
                return self._send(200, to_rtf(items, lang).encode("ascii", "replace"), "application/rtf",
                                  {"Content-Disposition": 'attachment; filename="Referencias_APA.rtf"'})
            return self._send(404, b"No encontrado", "text/plain; charset=utf-8")
        except Exception:  # noqa: BLE001
            log_error(traceback.format_exc())
            return self._json({"error": "Error inesperado. Se guardó un informe en " + str(LOG_FILE)}, 500)

    # ------------------------------------------------------------------ POST
    def do_POST(self):
        # La cabecera personalizada impide que otra página web haga peticiones a este programa.
        if not self._host_ok() or self.headers.get("X-Buscador") != "1":
            return self._send(403, b"Forbidden", "text/plain")
        self._touch()
        path = urlparse(self.path).path
        try:
            b = self._body()
            if path == "/api/ping":
                return self._json({"ok": True})
            if path == "/api/translate":
                return self._json(translate(b.get("text", ""), b.get("answers") or {}, bool(b.get("humans"))))
            if path == "/api/lint":
                return self._json(lint_query(b.get("query", ""), b.get("mode", "pubmed")))
            if path == "/api/search":
                y0, y1 = _int_or_none(b.get("y0")), _int_or_none(b.get("y1"))
                b.update({"y0": y0, "y1": y1})
                res = run_search(b)
                res["links"] = external_links(b.get("links_queries") or {}, y0, y1)
                return self._json(res)
            if path == "/api/links":
                return self._json({"links": external_links(b.get("queries") or {}, _int_or_none(b.get("y0")),
                                                           _int_or_none(b.get("y1")))})
            if path == "/api/doi":
                try:
                    rec = crossref_lookup(b.get("doi", ""))
                    return self._json({"record": rec, "fields": form_fields(rec)})
                except ErrorBusqueda as e:
                    return self._json({"error": str(e)})
            if path == "/api/cited/toggle":
                r = b.get("record") or {}
                rid = record_id(r)
                with _store_lock:
                    items = load_cited()
                    if any(c["id"] == rid for c in items):
                        items = [c for c in items if c["id"] != rid]
                        saved = False
                    else:
                        items.append({"id": rid, "saved": time.time(), "meta": enrich_record(r),
                                      "search_id": b.get("search_id")})
                        saved = True
                    save_cited(items)
                return self._json({"saved": saved, "id": rid, "count": len(items)})
            if path == "/api/cited/add":
                rec = normalize_manual(b.get("record") or {})
                if not (rec.get("title") or rec.get("url") or rec.get("doi")):
                    return self._json({"error": "Falta el título o el enlace de la referencia."})
                rid = record_id(rec)
                with _store_lock:
                    items = load_cited()
                    old = next((c for c in items if c["id"] in (b.get("replace_id"), rid)), None)
                    items = [c for c in items if c["id"] not in (b.get("replace_id"), rid)]
                    items.append({"id": rid, "saved": old["saved"] if old else time.time(), "meta": rec,
                                  "search_id": old.get("search_id") if old else None})
                    save_cited(items)
                return self._json({"id": rid, "count": len(items), "replaced": bool(old)})
            if path == "/api/apa/preview":
                return self._json(apa_preview(b.get("record") or {}, b.get("style", "es")))
            if path == "/api/link":
                try:
                    return self._json(link_lookup(b.get("url", "")))
                except ErrorBusqueda as e:
                    return self._json({"error": str(e)})
            if path == "/api/history/add":
                return self._json({"id": hist_add(b.get("entry") or {})})
            if path == "/api/history/remove":
                with _store_lock:
                    save_hist([h for h in load_hist() if h.get("id") != b.get("id")])
                return self._json({"ok": True})
            if path == "/api/history/clear":
                with _store_lock:
                    save_hist([])
                return self._json({"ok": True})
            if path == "/api/cited/remove":
                with _store_lock:
                    items = [c for c in load_cited() if c["id"] != b.get("id")]
                    save_cited(items)
                return self._json({"count": len(items)})
            if path == "/api/cited/clear":
                with _store_lock:
                    save_cited([])
                return self._json({"count": 0})
            if path == "/api/cited/ids":
                return self._json({"ids": [c["id"] for c in load_cited()]})
            if path == "/api/record_id":
                return self._json({"ids": [record_id(r) for r in b.get("records", [])]})
            if path == "/api/shutdown":
                self._json({"ok": True})
                win = _state.get("window")
                if win is not None:          # modo aplicación: cerrar la ventana cierra todo
                    threading.Timer(0.3, win.destroy).start()
                else:
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                return None
            return self._json({"error": "Ruta desconocida"}, 404)
        except OSError:
            log_error(traceback.format_exc())
            return self._json({"error": f"No se pudo guardar en {CITED_FILE}. Revisa los permisos de la carpeta."},
                              500)
        except Exception:  # noqa: BLE001
            log_error(traceback.format_exc())
            return self._json({"error": "Error inesperado. Se guardó un informe en " + str(LOG_FILE)}, 500)


def _watchdog(httpd: ThreadingHTTPServer, auto_exit: bool):
    """Cierra el programa si la pestaña del navegador lleva un rato cerrada."""
    started = time.time()
    while True:
        time.sleep(15)
        idle = time.time() - _state["last_ping"]
        if not auto_exit:
            continue
        if (_state["pinged"] and idle > 180) or (not _state["pinged"] and time.time() - started > 900):
            say("La pestaña se cerró. Cerrando el programa.")
            httpd.shutdown()
            return


def _already_running(port: int) -> bool:
    try:
        with urlopen(f"http://127.0.0.1:{port}/api/config", timeout=1.5) as r:
            return "examples" in json.loads(r.read().decode("utf-8"))
    except Exception:
        return False


def run_self_test() -> None:
    """python3 BuscadorAcademico.py --prueba  (no necesita internet)"""
    casos = [
        ("tratamientos de hipertensión en embarazadas sin fármacos", {}),
        ("diabetes en niños o adolescentes de los últimos 5 años", {"amb:diabetes_any": "diabetes_t1"}),
        ("ejercicio para la depresión en adultos mayores, revisiones sistemáticas", {}),
        ("fibromialgia sin cirugía ni fármacos", {}),
        ("hipertencion en mujeres desde 2018", {}),
        ("enfermedad de parkinson y musica", {}),
    ]
    for texto, resp in casos:
        t = translate(texto, resp)
        say(f"\n» {texto}")
        say(f"  Años: {t['years']['from']}–{t['years']['to']}   Preguntas pendientes: "
            f"{sum(not q['answered'] for q in t['questions'])}")
        say(f"  PubMed:  {t['query_pubmed']}")
        say(f"  Otras:   {t['query_generic']}")
        say(f"  Corta:   {t['query_simple']}")
        issues = lint_query(t["query_pubmed"])["issues"]
        say(f"  Revisor: {'sin avisos' if not issues else issues}")
        for n in t["notes"]:
            say(f"  Nota: {n}")
    demo = {"authors": [{"family": "García", "initials": "MJ"}, {"family": "López", "initials": "A"},
                        {"family": "Smith", "initials": "JA"}], "year": "2021",
            "title": "Exercise for depression in older adults", "journal": "the journal of aging",
            "volume": "12", "issue": "3", "pages": "123-9", "doi": "10.1000/xyz123"}
    say("\nAPA (es): " + apa_text(demo) + "   " + apa_intext(demo))
    say("APA (en): " + apa_text(demo, "en") + "   " + apa_intext(demo, "en"))


def _startup_error(msg: str) -> None:
    log_error(msg)
    say(msg)
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, msg)
        root.destroy()
    except Exception:
        pass


class AppBridge:
    """Funciones que la ventana de la aplicación puede pedirle a Python (guardar archivos, abrir enlaces)."""

    def export(self, fmt: str, style: str = "es"):
        import webview
        lang = style if style in APA_WORDS else "es"
        items = [c["meta"] for c in sorted(load_cited(), key=lambda c: apa_sort_key(c["meta"]))]
        name = "Referencias_APA." + ("txt" if fmt == "txt" else "rtf")
        docs = Path.home() / "Documents"
        win = _state["window"]
        kinds = ("Texto (*.txt)",) if fmt == "txt" else ("Documento para Word (*.rtf)",)
        save = getattr(getattr(webview, "FileDialog", None), "SAVE", None) or webview.SAVE_DIALOG
        path = win.create_file_dialog(save, directory=str(docs if docs.exists() else Path.home()),
                                      save_filename=name, file_types=kinds)
        if not path:
            return None
        path = path[0] if isinstance(path, (list, tuple)) else path
        if fmt == "txt":
            Path(path).write_text("\ufeff" + "\r\n\r\n".join(apa_text(m, lang) for m in items), encoding="utf-8")
        else:
            Path(path).write_bytes(to_rtf(items, lang).encode("ascii", "replace"))
        return str(path)

    def open_url(self, url: str):
        if re.match(r"^https?://", url or "", re.I):
            webbrowser.open(url)
        return True


def _run_window(url: str, owner: bool) -> bool:
    """Abre la interfaz en una ventana propia (pywebview). Devuelve False si no se puede."""
    try:
        import webview
    except ImportError:
        return False
    try:
        try:
            webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
            webview.settings["ALLOW_DOWNLOADS"] = True
        except Exception:  # noqa: BLE001  (versiones antiguas de pywebview)
            pass
        win = webview.create_window(APP_NAME, url, js_api=AppBridge(), width=1360, height=880,
                                    min_size=(980, 660), background_color="#141312", text_select=True)
        if owner:
            _state["window"] = win
        kwargs = {"gui": "edgechromium"} if platform.system() == "Windows" else {}
        webview.start(**kwargs)
        return True
    except Exception:  # noqa: BLE001
        log_error("No se pudo abrir la ventana propia; se usa el navegador.\n" + traceback.format_exc())
        _state["window"] = None
        return False


def write_icon(folder: Path) -> Path:
    """Escribe icono.png (lo usan los scripts que crean la aplicación)."""
    import base64
    path = folder / "icono.png"
    path.write_bytes(base64.b64decode(ICON_PNG_B64))
    return path


def main():
    args = sys.argv[1:]
    if "--prueba" in args:
        run_self_test()
        return
    if "--crear-icono" in args:
        say(f"Icono creado: {write_icon(Path.cwd())}")
        return
    use_window = "--navegador" not in args
    open_browser = "--sin-navegador" not in args
    port = int(os.getenv("BUSCADOR_PORT", "8765"))
    if _already_running(port):
        url = f"http://127.0.0.1:{port}/"
        say(f"El buscador ya estaba abierto: {url}")
        if not (use_window and _run_window(url, owner=False)):
            webbrowser.open(url)
        return
    try:
        httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    except OSError:
        try:
            httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        except OSError as e:
            _startup_error(f"No se pudo iniciar el buscador ({e}).")
            return
    httpd.daemon_threads = True
    url = f"http://127.0.0.1:{httpd.server_address[1]}/"

    # El servidor local corre en segundo plano; la interfaz se muestra en una ventana propia o en el navegador.
    server = threading.Thread(target=httpd.serve_forever, kwargs={"poll_interval": 0.5}, daemon=True)
    server.start()

    # 1) Aplicación con ventana propia (pywebview: viene incluido en el .exe de Windows y en la .app de Mac)
    if use_window:
        say(f"  {APP_NAME} {APP_VERSION}: abriendo la ventana del programa…")
        if _run_window(url, owner=True):
            httpd.shutdown()
            httpd.server_close()
            return

    # 2) Sin ventana propia: se abre en el navegador, como antes
    say("=" * 64)
    say(f"  {APP_NAME} {APP_VERSION}")
    say(f"  Abierto en tu navegador: {url}")
    say("  Si no se abrió solo, copia esa dirección en Chrome, Edge, Firefox o Safari.")
    say("  Para salir, pulsa «Cerrar» en la barra de la izquierda o cierra esta ventana.")
    say("=" * 64)
    threading.Thread(target=_watchdog, args=(httpd, open_browser), daemon=True).start()
    if open_browser:
        threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try:
        while server.is_alive():
            server.join(timeout=0.5)
    except KeyboardInterrupt:
        httpd.shutdown()
    finally:
        httpd.server_close()


# Icono de la aplicación (PNG 512×512): así el programa no depende de archivos de icono aparte.
ICON_PNG_B64 = "iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AABKNElEQVR42u3deZwcV3ku/uc9p6q6e3ZJM6PVlrzbkrEdbAO2A5Ix4OR3wZaXHhavJLmQkISwJhBIWhMgyYUkl+RCEpxgvMgOTNt4IwQwIAkw2OAFsCWMV9mStc9Is3Z3VZ3z/v7oGXnBqzTT09PzfD/hY8eWZ6mqrvc5b506ByAiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiCA/B7DjPOvF3yoNBRC9dEYR3CwYAqm+qE5/TNYLiJlnftUsAYNXubsXG5Yo1vSrCDzIRvfJ7y5o1BVmz4jn3lfxyXbMGWMN7CwMA1f7DiK5dgt3dKj1F93L+23WFlUHXim7z5PZhWdbR1cKjSUTP1dYKJINm9Gebx/zeRY/pe997T/Jy/ru+vrzNj9+TOOhgAKDJGtkX82Z91y5ZtX6Vl95e/3zn74Ev5Js7F7R0R5l48Vgsi9WjW6ELAmu6AiNzAWlx6uepIgtVm3h0qirPOxH9RjEIrAyImIpAU2tkNyBj3uueSuz2GoOnwijYbaHb1OtTj436Hf/zyHUjvb3wz3f/Wr9+pa12DIqegYABgF5mwT/zzA3pc//93V96a9OyxXOWOofj0kSPsdYeBeCIJHXLvKIrtJKNQivWCEQEqgrvFV4VzgOq1c+fc/wcEtHz3IMAWCsQACLAxL3EGIERQFXgVREnKZJUKyLYE4bmCQgeTWL3WMbaTUEWD24bKT12fE9x5Llff926lQEDAQMATXzgCgWzftV6s2rVeiciz/pA7L75HYuA6JTYuVdHYXhCJU5PALAkE9lMGBh4D6SpR+IUqfPw3kMBDxUVURUIdP/5Vdl/plV4zonoBSrC+EhBq//PeJFQ3R8S1AAw1ggCaxBYg9BWQ0LqFJU4TbzKtlzGPlBO0vshcm+Tdz/95/uv3/LMTsH+DkG1u6nghEMGgNlU9J87yt/2zXd3hc6dVon9aaE1r4sTf1ImtB1RaJA6RZx6JImDU/UC+GqBVwNAIALhuSSiGt7KxruKWg0KqgoYI2KiwCIMDMJAkKQe5dgNR4F9IHH+Thvan4TG/7jzbdc89azuQGFlsAov+KiTGABm8icFsn7NSrtqzQb3zNbX7lsvOzZNcJa1eHPs3OlRYLuiwCBOPCqJQ5x6NQIHiCjUmOrgneeMiOo8GMjEg0cTGGMykUUUWjjnUaqk+3KZ4M5y7L4fZs3tG8bG7u95xoTmdYWVwXqs8r0MAwwAM1lfX97m88tV5OkLec/N714e+/S80Mib41Rf05QNcs4rSnGKOJko+DCAiAjPDxHN8EQAaDULiFeoCa0x2ajaJRgppUlgcZ96uV2t3vyl+669d+JRgRYKBis2CXqKnmsSMADMnNH++pX2mS3+Pbddutileq4Ve34ldWc054JsnHiUKg7OeyfVkb1hwSeiWXCPVAAeUBWRIBtZZCOL0VKaRqH5aerdLcZkvj7/3C8/sr8rsG5l8HxzpYgBoC4UCgWzZsUmmXg3f11hZbD8hGVvgtGLnerv5qJgbpIqxioJVDWtFnwRngMimt2BQD0ALyJBLgoQRQZj5XQkNOZ2E+i1lW0D31783m+MAYD25S02LlfOFWAAqI+Lt1AwxRWbZOIZ1s5vXLZAUvRAcIl6nBIEBqPlBGmqDqJiWPSJiF4wDKhCrRXbkg3hATjnfwWV6zI2vH7Ouf/5+MR9F2uAZz5eJQaAmhZ+AJhIonu+fslxzsjve4+Lshm7oBI7jJVTFYiHsL1PRPSy76+AQuEVKtkwME3ZAGPlZJ81UjQSXNG1+sq7xwODAGuEQYABYHpG/DdddpIC73fq39EUBbmRUookdU4EIiKGR4yI6GDCgHoovDUStDRFKFVSZ43cIlb/7/xzrv3R8w3IiAFgci/C8ZX65NmF/+PO6+pcZKOhsXj82b5YjvaJiCb9Hqyq8CKwbc0RSpVUM6H5H/Xy993nXfXD6p8pGGCNcrIgA8DkXXh9eTtR+HfcdPmroP5DqvqOKAyyQ6UYUE1FxPJ4EhHV4J7s4VRgW5tCxLFTa+Um5+SfFl949R0T92wuOcwAMGmFf/ONFy1sCYIPJV7/MBPalqGRGF7hjIHhcSQimpaugAPUtDVnpBynPgrtV0rl9O8P7Vn7yHPv4cQA8HIvqv3t/nWFlcHyk5e9Fx4fjwKzeHC02urniJ+IqD54r05EbHtzhDh1ewNr/mlgMPmXoy+5bkgLBbMGAFcWZAB4RaP+3TdfeqaK/F1ozWtHywmS1KcQsVx3n4ioHgdvmlojQVtzBqn3G43gE3PfetUt7AYwALz0qB8FEen1m6+9aGFze7AmTfU9RgSj5cSJCF/lIyKq/3u5qqrPZQIbBAL1emNZ/McOPXftI3xbgAHgRUf9/bdd9g7n9e9Ca5ftHYkVUDV8nY+IaKZ1A7wCaG/OGOf9LgP9VOe513yB3QAGgP2/v/ZVn/U/2Xfp4lwknzPWvLMcp6jEzhkjlh8jIqIZHQRSa03QmguRpP7bo2n8gcMu/K8Hq68M9upsflNAZu9FUTATq0dtv+nyt4VWP2+NOXzfcOxgVAQc9RMRNcb9HupVfUdzZL1ilxf/sfnnXPOV2d4NmJUBYOKEf/OffydzymHdn4HKh9PUo8xRPxFRw/JeXRAY25IL4Zy/Zvc+/6Hll13bv66wMjiz9+kdXBkAGrz4b735omMCNV/ORuEZA8NlLwC4dC8RUYOHAFWFws9pzdjE+Qec099feP41P52NiwfNmoJXKBSMasFIT9FtufGiC3Mm2BBYc0b/YNkZEcPiT0Q0C4qeiBgjdmC44rzX4wMr39950yXvk56iE4FOvCnADkCD6OvL2579s/zf/Snn/ScriUOaqBMDtvyJiGYhVTgxsG25CF71irHy6AcO7SmWZsu8gIYPABMn8onr3jUnkwv+oykTXDAwXHEqnOhHRMQQUN1kaF5bxo7F6Y9KLr348Auvf0I1b0UaOwQ0dAHUdSsD6Sm6LTdcflS2KfxeJrIX7B4sOwgsiz8REYlAjIHtHyqnoTW/3RqG39928yWniFSXgmcAmIHWFVYGcuaGdPvNF782F+K7YuS3BoYrzlrO8icioucUQyPB0GjsnNfDQ7G3P1G85Nwzezek2pdv2JrRkI8AJtr+W4rvOj+XCa9MUt9eqvAVPyIieon64eGCQGwUWZfE7s+W5Nd+8ZnrxrADMAOK/9a+i98dhkFxrOLay7Fn8SciopceFRvY1Hs/VkpNLhd8YedNl/6FSK/XvrzVBhs0N9QvM1H8t9106UeiwHxueDRWCJTP+4mI6BXVE4UC8HPbIltJ9HPd517156oFA+lVQWOsFdAwhXH/yP/rl3w0E5rPDY/FvppwWPyJiOgVjo6ru7/agaHYZULz0V23XP5ZkV4PLUijdAIa4pd4ZvHPRfazQyOxB0S4fS8RER10jfFwc9sztpL4huoEzPjRMYs/ERFN6UjZwA4MVhquEzCjA8D+4n/jpR/JRQGLPxERTWkIyIbmo7tuubQaAvryM7qGztgffl2husjPtuIll2Uj87mh0QqLPxERTWkI6B+suEwYfHTrDZd8Qnpm9mJBM7JY6rpCIGf2po//17vOb24K+0pxCufUGBEWfyIimrr6AygUvq05suUk+dPF56/9ghZWBjIDtxOecQVzou2/48bLXmcDfLsUu9Y09TCGxZ+IiGpQhxRqLHwuE2B0NOk57J3Xf31iYMoAMGUHvboa05N9Fx+Zjew653VJKU694Va+RERUQ15VQ2uQDe2wczh7wQVX3znTdhGcMYWzUCgYYI0+2pdvDwMpQmRJqeIciz8REdW8eIpI4rymXtsg2rf1prcfIj1Fp4XCjKlJM+IHVUDWrFghgCAbZq7MRMFJo6U4NQZc3peIiKYrBJhSJXXWmkMsMl/b2fe+FqwBVGdGd31mJJW+vJGeHrfj5kv+pjUTnb9vJE5FJODlR0RE01pEjdjhsThtioLT1I58QaTXozgzXg+s+5TS15e3PT1Ft6V4yfnZyN44Vk5SBSzA1/2IiKg+qGra0ZIJxirJny2+YO2/qOatSH3PB6jrlFIoFExPT9E9csM7j4pCuaIcp+qhhsWfiIjqbDxth0qJC6z93Obi208XKbq+vnxdP6au20KqCkExbx7ePhw0L+5eF4Vy2shY6oTP/YmIqA55Vd8UBUaBRxz0dYvPu2YAAESkLvcMqN8OQDFvpKfompd0/m1LLjhteCxJWfyJiKheGREzVkldNrJHise/iYii2FO3Xeu6DAB9E2v8Fy95axTYD+4drjhjhMWfiIjqOwQYsXuHK64pG+a3fv2SP5SeotM63TOg7lKJqgog2FzMz8+FTXd57w+ppE4FfN+fiIjqn6qqtUajwIyUE3fasp7rNmmhYKS317MD8GKKPUYEGtnM5zOhObQcO8/iT0REM4WIiEtVrTVtgZUv3f2lk0Os2CT1tj5AXRXW/a3/Gy9+RzYK3s7WPxERzcgQYGBHRuO0JRv99sJ5x31Qeoqu3tYHqJsfRlVl48aiPtT37q5A5LPl2KkxfN2PiIhmbCvADo1VvFjzV1tvvuiYelsquH7SSLHH9PbCt4bppzNRcEicOAe2/omIaMbWf0iaQiNrWuDN5wFIccWmutm6ti5+jold/nbddPnrIfr9UtmJChf8ISKimU89XFtLaMsVd9HiC6+9fmKF21kfAKqTIgry8P/cFbaWuu4wVk4eK6deuMsfERE1SAQIAytGZIuDvnrxedcOADrtCwRNe5EtFvNGpNc3jXb+QTYbnDxaSh2LPxERNQ4xldj7XMYeahR/LoKJBYJmbwegUCiYNWt69dFrL+5qapFfeK/zU6eKmbJLIRER0ctsA4hAM4GpqEtOXXDhVzcBBRGZvrUBprXQrlixSUSgzS3y0VwmWBAn3rP4ExFRI7YBnIOGoc15CQsiUKyZpR0A1YIBenX7TZccKyI/TVLX5D0EnPhHRESN2gZQ+OZsqE6TNy0877r10zkhcNpG28VidfSvwEezoW1JUyiLPxERNXoGMAbWO/kkAMlvXD5tEwGnpeCqFgykV3fcculyTfXuJPWRgqN/IiJqfF7VN2dDUfi3LFh97XenqwswPR2ANYAAqg5/lY1s1nuO/omIaHYQVBcJSlLf29eXtxunqQtQ86I7sejPE8VLV0QWd1dil4Gw+BMR0eyh1S6AiVP/5iUXXvtdHd8Lp6E7AMXiJgGAUPTDmdBmvcLzUiAiolnWB1ARgYj+RaFQMJiGLkBNR95aKBj09urWG955pJHgF0nqs9PxcxAREU0371WbsgG8YNWi1df8oNZdgNp2AKqbIGhg7HubMkHOe/Us/kRENCt7ABAfWiOa+j8FgFp3AWpWfBUQAfTRW94xP5OEv1TV7tSrCgMAERHNXhoFppJCTz30grUPTMyTa6wOgOYNAERp8PbmXNidpN6x+BMR0WzmvfpcNsiGMJcDAMbnyTVWB0AhuOc9wdbNYz8NrTmpVOGOf0RENMuH/woNAyNQ3eY186pDe748MNExb4gOgPblrQh02xNjq6LAnlSKWfyJiIhEIHHifFMuXGQkXl0tmvma1MeafJPixDcz9tIgMABf/SMiIhoPAaKp8wrRSwsFGKCvJjVyyh8BqEJEoE9c/45FNgoeUMUc55Ur/xEREU3UyupkQKcer1mSv/a+WkwGnPIOwPr1Ky0A2Fy4uikbzklSdSz+REREzxotu+ZsEBijPQBqMhmwVh0AbPv6Jd8LrTlzpJQ6EViebSIiov3V0kdhYJz3Dz0ybE88891Xl6f6O05pB0ALMCLQ3TdfdLR6PW2s7MDiT0RE9BvjcVOOUw2sOerYNnc6UJ1AP2MDwHqsNACQeHNhcy7KOu8dTzIREdHzRADAZUMrEOkBnp5AP4Xfbwo7AOMTALffeMkPbGBeP8r2PxER0QtVTR8FgfHqH33SV151ek+xNF6np2RNgCnrAEy0/7fe/HvHpN6fWio7CFj8iYiIXmBMbspJqtaaww6xmdMAQPumbk2AKfvC61dV2/8+jd/c0pTJOq+Oc/+JiIheJAIALhcFRkTeAgDru3ZNWeWcsgCwav0GDwChNW9yzrP2ExERvQQFTDlJYRVv6uvL21VnbpiyuXNTEgBUIdIL/9St7+xMUn9GKU4BAy79S0RE9GJFWUTKFQen+qqzMrljBVAtFKakfk5NUS5Wn1loEp6ei4LOOPHc9peIiOilifdwzdkoKlXcSgDAqvUzKABsnHhmoa8LAwMjwtf/iIiIXk4CEKiqwobmtGoAWDUlSwJPTQDo3eAUEAs5PU48OPonIiJ6uQlATTl2cA6ve/wrl2XH9wSY9Do66QFAtbqP8RM3XrQgdu6kSpJCwef/REREL6v+Q0ycOqjisI45/rhqbS3UfwAojj//zxg5JZcJ2+PUqwg7AERERC+X9+pamkI7HPvqY4D1kz8PYNK/YNf4O4tpKidHfP5PRET0yrsAIgqvCALzagDA7u5JXw1w0gPA+lXV9/+jwJzknAf4/J+IiOgVJgA1ldRBBCf15fNWeopusotpMJlfTAERgf/xP+ZzifMrnAIKNXwCQERE9MoiQJJ6eI+jXnuenY8itvnx/XXqsgOwplCdpLDssOwyVT0kTjyMsPgTERG9ouoPkSRVzUSmNZMJVgBAsWdy9wWY3ACwYtNEtT8uGwUZrzolry4QERE1fAgQdZkokNjpsQCQf9/k7gswqQFgYtOCJPXHhYFAAM9TSEREdEBdgGqhNrICALBqcicCTmoAWDU+SzEMzBFewcE/ERHRAVJA0tQhDMzh1URQnNRB9WQGAJG3F12hAGOsOSJNPQDlAkBEREQHFADUJKkiSfzhd3/prU0CqOrkjawnrUCrVuNKfkW+KY7dssQplC0AIiKiAyvQIki9hwfmz53X1jXpX3+yv2CrCbuh2pk6vgFARER0MJzzCKw0ZWx0KABgTaH+OgATP1TORouDwGS95/w/IiKigyCq8FFgDdQvAYD1mLwlgSftC038UM6nizOBNargK4BEREQHkwAEPrCCJHVLAGDVqsn72pMWACZ+ptSj2xgDEb4CSERENAkxAAJ0T/ZXnbxHAKv2p5X5HPcTERFNAhXx6hEFdn611q6atMH15AWA8TUArLWdUAXX/yciIjrowT+8A4yRzuo/6K3DvQA2LtfqF/RdzvMVQCIiooNvAKg4r/Ded2pf3pq63AxozZrq2n9imlWVZ42IiOjgGwDwqvCK5o2AHV9yZ1IG2JMWAERE1xVWBqn3nc5XcwtPHRER0cG0ACBOFc7pnObRuGn8n9VPB2AijexGt4FqRpUPAIiIiCalB+ABD82UTJudzK88qSsBdi1rMhhvURAREdFkDLIVIoJMmAT1FwDGK/5845sTp13eKaBcB5iIiOigxv8COK+wgpam5qj6JsAkLQc86XsBcPRPRERU/7hdLxEREQMAERERMQAQERERAwARERExABAREREDABERETEAEBEREQMAERERMQAQERERAwARERExABAREREDABERETEAEBEREQMAERERMQAQERERAwARERExABAREREDABEREQMAERERMQAQERERAwARERExABAREREDABERETEAEBEREQMAERERMQAQERERAwARERExABAREREDABERETEAEBEREQMAERERMQAQERERAwARERExABAREREDABEREQMAERERMQAQERERAwARERE1koCHgKaaqsIrjwNNDhFAIBDhsSBiAKA6Lv5AFFrkIsuDQQdW8AGoAFDAqcI5RZp6JF7hx5OlABBhKCBiAKC64FXRlAlw14P9KP5gC5qyFt7zuNArK/7z2iM0ZQLMa4swtyXC/DlZdLVn0NESoSkXwBhBknqUE48krV5ghmGAiAGApnf0nwkNNu8YwdrbH0dHawYpEwC94gsJUFRb/4E1yIYG7S0hFszJ4oiFrTjmkFYcd2g7jlrUgq6ODIwISrFDJXZQhgEiBgCavhAQhQbtbRE6mkM4TgagA20FjAcB7xX7RhLs3lfBvQ/vg1dFNrJYODeLEw5rx2nLO/G6YzuxdH4zAisYLaeoJB7GVMMAETEAUA1DgHMK55UBgCbnxmUFoQ0g2YlrTLFrXwXfuGs7br1zGzrbMjjpiA68+eQFWHlCFxbPa0I59hirpBAAxjAIEDEAENGMDJU60RIYFwaCTBgCAMqJw7pf7MJ379uJJZ05vOXkhTjvjCV41bJ2OFWMlFKIsCNADABERA0RCpxWE4EVQVtTNQwMDCe48tuPoe8HT2LVid24/M2H45Sj5yBJFaPlFNZwjgAxABARNUYYAPY/bgoDwdwognOK/75rG753706c9VsL8EdvPRInHN6O4VKKOPEILFMAzS5cCZCIGr4zkDqFAuhojhCFFv/9021459/9GJ+6biPGyg5zWiM4r1BOUSEGACKixlMt8oqOlurjgX//70dx4afvwK0/eQrtTSECK5yoSgwAREQNGwRctch3tkXYubeEP/3iPfjIFT/HWOzQ2hQidVyvghgAiIgaVuoUmcBibmuEG360BW//zB2456EBzGvL8JEAMQAQETUyr4rUKea2RtiyawyXfu5OfPlbj6GjJYRI9d8TMQAQETVwNyCXCRBZg8I1D+CTX7kf2dAitIbzAogBgIioobsBXgEB5rVFuPr2x/G+L9xdfUwQWoYAYgAgImpkE68NdnVk8K27t+OP/uVupM4zBBADABHRbJCkiq72DH60cTf+8J+fDgGeIYAYAIiIGj8EzGuL9oeAJPUIrAEzADEAEBHNkhDwwwd24QP/fh/CQGAEfEWQGACIiGZDCOhsz+L2e3egcO0DaM0FUCYAYgAgIpoNIcBjXluEtd99Ald88zHMac0gdQwBxABARNTwvFd0tIb4hxsexA8f2IX25nD/ssJEDABERA1KFTAiEAH+8spfYve+CjKR4WqBxABARDQbugBNGYvNO0fxqes3IhNaTggkBgAiotkgdYo5rRFu/clTKP5gC+a0RHwUQAwARESzoxMAtGQD/PNNv8bWPWOIIsM3A4gBgIio0akqMpHB1j0lfPHWh9GcCeA9jwvNHAEPATUaEcAaAcdiM/w84unFdlSrBbfezmnqFB0tIb5+x1acf8YhOOmIDoyWUxgjPIHEAEBU66KRpB57y46rtTVImDMiCKwgDA1Ca/YHg3qZeW9EECeKL972MP7zg6dWL0IiBgCi2haLSuKxtLsJ55y2BEnqIMK78Uw2MBxjYLiCbXtK2LqnhP7hClKnyEYWuchCgWnfnMd5RWtTgB/cvws/fGAP3vCqLgyNJbDsAhADAFENR2Kpx6HdzfjY24/FcCnlTXgmU1QLvCpKFYfdgxU89NQw7nqwHz/45S488tQIRICWXAjI9AaBia7EVd95DL99fCeYO4kBgGgabsRJ6rFnKMZYOYXhnXjmn1AAxgjmd2RxSFcT3nLyAuw95yjc+as9+NqGLfjB/bshArRmAzg/PfMEnFe05kL8eFM/fvbrAbzmmLkY4fVHDABENa4ZAgRWYK3wBtxA4tSjnDioAqEVnH3KQrzptxbgjk178MVbHsZdD/ajrTmEMTIt3QAxQJw4FH+wBacv76zOP+HlR3WMrwES0YwJdtZUJwQqgMHRBKPlFK8/vgvX/sXr8PF3LkfqPcqxQ2BrX3m9UzTnAmz45S48um0EWa4QSAwARESTzxqBMYKhsQSVxONPzjkKV3/kdVgwJ4vBsaTmIUABhIHB7sEKbr93B3JZyz0CiAGAiGgqg4AIsGuwjFOPmYvrP34aTjisA0NjtZ8Eqh6IQoPb79uJUqX6KioRAwAR0RQKrcG+kRidbRlc+9HX4aQjOjBU406AV0UusvjVE4N4aMswcpmAjwGIAYCIaKoF1qBUcYhCgy/88clYNr+55ivzWSMYLqX44QO7kQnMtK9TQMQAQESzgrWCsYrDgrlZ/MN7TkIUGHinNXs3X1F9S+HOX+1BJfEQ3mWJAYCIqFadAMHe4RinHjMPH77wOAyVkpp1AbxXZDMWv9oyhK39Y8iEnAxIDABERDUTBgYDwxVcctZSrDyhC8NjtQsBoTXoH4qxcfMQMqHhPABiACAiqqnxxXjev/oYBNZAa1iJnSoeeGJfNXQwABADABFRDW9wRjBSSnHyUXPw5lfPx3ANXw0MjOChrcNIU84DIAYAIqJp4b3iXWcuq64iWIPRuFdFGBg8sXMU+0YTBIa3WmIAICKqKWsEo2WH3zqyAycc3oGxytRv0qNanYOwZ6iCXfsqCAPDiYDEAEBENB0dgOZsgDeeNL/6al4NngJYEYyWUmzvH6tZ54GIAYCI6BmqO/V5vPbYeWjKWNRibR4RIHGK7QPlmi9JTMQAQEQEwIignDgsm9+MRfNyiNMadAEEgAJ7Biv7/56IAYCIqMacU8xpCXHYgmbEiZvyeQATIaB/ON7/OiJRPQl4CIhemFfsf3dc8PRNnM9zp3bgPDFinjjMIjjogq0AgsDg0O5muFo8A9DqrzFWcRz8EwMA0YwZLXqFAMhGFtnIQESQOq1u7CLVpWaFQ7qpqJlwzkO1WvTDoLqKXiVxKMcOXnHgz9O1+r/O9kzNApwxgv6hClLna7YXAREDANEBjfirlaG9OYT3ike3jeC+R/fhoa1D2Npf2r/He2d7ZnxlOR6zSRv5S3W2/p7BClKvyAQGiztzOGJRK37ryDk4enELMqHF4GgCVX3ly/qO//HOtqimxZiv/xEDAFG9j/qdIpexsFbw3Xt34qsbnsTdDw1gcCTeP/KcKBzPfDRAkxgCIHjmmjkTrfrWXIgTD+/AhW84BL976gIExmK4lCKwMgN+JyIGAKK6lTpFR0uIx7aP4jP/tQnrfrELAkVTJkBHS8QDNN3hzCvufLAfP9q4G/+1bh4+/o7lePWRc7B3JOYrdkQMAEQHXvzntkb41s+24xNX/RJ7hmJ0NIf7C09NJozRS2rJBTAiuOfhAVz89z/BJ961Ahe9cSlDANEB4muANLuLv6++GnbzT57CH3/xHoxVUsxpCVn465D3itR5tOZCGBF87Ms/x39881F0tEQ8V0QMAEQvn3OK9qYQd2zag49ccR+ykUUUWKSOxaSuz5tXiAHmtEb4m+s24qY7tmBOS8TzRsQAQPTSVIEoNNgzWMEnvnI/jAisEY4kZ9D5gwpamwJ8au1GPPTU0PgSvzx/RAwARC/Ce0VTNsC/feMRPLp9GM0ZW33Hn2bOOVRFFBgMjMT4xxsfQhAYLrdLxABA9OKjx1zG4pGnhnHTHVvR3hwiYft4Rkqdor05wvfu24mfPdiPllzAIEfEAED0wiPHXMbitru2YWA4RmD4MZjRNzEBktThpju2cnEmIgYAohe56I1gtJzih/fvQhSyYMx0zityUYC7ft2P3fvKCAPe1ogYAIieQ7W6xOzW3SU8vmMU2YgTx2b+OQWiwGB7fxkPb6ueU07mJGIAIHoWr0AYCLb1lzBSSrmATIMQAcqJw5O7R2fE8sBEDABE03HRG4Od+8pInOc67Y3UCQCwc6BU3a+BDQAiBgCi3xgtovrcmJ3/xjqpooDzPBREDABELzJSzISG+7M3oCiU6uCf55aIAYDouZzzWDQ3hyiw4Fyxxkl1YoAlnU3s7BAxABA9zwUvgjhVLJqXq2764zxHi40Q6ryiORNg6fxmJKlnd4eIAYDo2USAOHFY1JnDsYe0oRw7GFaLGX9OK4nH0vlNOGJhC8qxg/CcEjEAED2XKhBYgze9egFSr/wQzPSbmBFUYodVJ85HW3N1K2eWfyIGAKLfvOhtdSXAs09egEO7mlFOHFvGM1jqFB0tEVafvgTlCjs6RAwARC9AAMSJx/y5Wbz77MMwXEphuR/AjBRag8GRGD0rD8ExS1pRihnmiBgAiF5EYAWDowkueuNSrDqhG/tGYq4gN8NYIxgqJVixtB3ve9uRGCmlHP0TMQAQvTQdf1/sb999AhbNy2GklCKw/EjMiOJvBZXEIRdZ/P0fnIjWprC6siPrPxEDANFLXvwiKMUOi+bl8J8feg262jPYNxIjDLhIUL0SVNv+o6UUQWDwpT87BScc3oHhMe7rQMQAQPRKRpJGMFxKcdTiVqz92Gk49Zi52LWvDOcVgRW2lOsorAW2usrf7sEyjljYgmv//DScdlwnBkcTPr4hOgABDwHN+g+BFYyMJVjSmcNVH3ktrvz2Y7j69s3YubeMTGiRjczTo0vWmdoZX9HPeUUpdijHDnNaIvzhW4/E+952FFqbAuxj8SdiACA6qE6AFZQqDsYI/nT10TjntMW47Sfb8J37duCxbSMYHE3gtbqBEDebm1r7j68AVgS5jMWRi1qw6sRurD59MY5d0obhUjo+Z4PFn4gBgOggmfFR/sBQjK72DP5k9VF499mH4bEdo9i8cxRbd4+hVOFrZjUZ/CsQhQaLO3NYNr8ZRyxsQXtziFLsMDASw4jwmT8RAwDRJH8orCBJFXuHYlgrOHpxC1YsbYMRqT4BYN2pQQIAVAD1isQpyrHDwHAMEbDwEzEAEE0dkepjAQAoxQ5jFce+/7SciOq54IifiAGAqOaMCEf9RNR49zYeAiIiIgYAIiIiYgAgIiIiBgAiIiJiACAiIiIGACIiImIAICIiIgYAIiIiYgAgIiIiBgAiIiJiACAiIiIGACIiImIAICIiIgYAIiIiYgAgIiIiBgAiIiJiACAiIiIg4CEgenFeFaoAlMdiPwEEgIhAhIeDiAGAqEGoAt4rrBXkIoswMDAikPHix+MDpF5RiR3i1AMArOGBIWIAIJrBUqfIRgZN2RCjpRQPPTWCzTtHsXX3GEoVxxEvgO72LA7pbsKRi1qwYG4OqoqRUgpVhWEQIGIAIJpJvK8Wr7ltEZ7YOYrbvvU4vnPfDjy2bQQjpXT/owABnwYYEYSBoHtOFq8+cg5Wn7EEr1/RCSOC4VKKwDIEEDEAEM0AzimashapU/y/mx/C1bdvxs69ZWRCi2xk0N4cVv8g61qVVh8D7B2Kcdud2/Dfd23D6cs78aELjsEpR8/F3uGY8wOIGACI6lvqFK1NIZ7cNYqPffkX+PGmPWhvDjGvLYL31UmAznMG4PPeQAJBR1gNRz/etAf3PrwXH77wWLz77MOqjwSYmYgYAIjqcuTvFa25AA8/NYzf/8e7sH2gjO6OLFLnkToW/ZdsBCjgtHqc2ppCeK/462vux859JXz87csxVEogbAMQ1SWuA0CzlldFLrLY1l/CH/zTT7F7sIKOlghJ6qGs/QcUpiBAd0cGX7z1Efzfm36NjpYIjkGKiAGAqJ5MjEz/8iu/xLb+ElpyAVLneWAOsiOQOkVnewZfuOVhfOfuHWhvDvkIhYgBgKg+pE7R3hziuu8/gfW/3IWOlogt/0kWBgZ/99VNGBiJEVrDdZSIGACIpnmUCiAKDXYOlPGVbz+O1lwA5znyn0zeK5oyFg9vG8HX1j+J1qYAngGLiAGAaFqLk1M0ZwN8+54deHL3KLKh5TP/KeDGQ8AtP9mKgeEYQSBcQIGIAYBo+ogAqfP47r07EBgBx/5TQxXIRhaPbBvFzx/Zi6ZMsP+NASJiACCqeVGKQotte0p4cMsQspGFZ1GaurAFIEk9fvrQQHWvAB5qIgYAoungVREFgm39JewdSWCtYVGaYtYIHts2Un0TgHccIgYAomkrSNZg20AJcerAfWumlqK6WuD2vWWUYwfLRYGIGACIposAqCRc7KdWCUAgSFKPlGsBEDEAEE33qNQablRT0+MtwpsNEQMA0fTy3mN+R5aL09SCAM55zOvIIJvhhEsiBgCi6brgBUhSxaJ5ObTkAi5RO/X1H84rlnY3IQwMH7sQMQAQTVNBEkEl9VjSlcNhC5pRjh0MnwVM+TF/9ZFzoVxwgYgBgGg6eV9dCfD1r+pGnHjOBZjC0X+ceiyam8UpR89FKU751gURAwDRNF70IihVHN722kWY2xoh5T4AU8JawUgpxZtPXoBDunIox37/DoxExABAVPuRqQClisORi1tx3hlLMDiaILQsTJN9jJPUY25bhIvPWoaxioPh8J+IAYBo2i98Ixgrp/ijtx6JIxa2YpQFanJH/8ZgcDTF+956JI5Z3Do+14LHhYgBgKgORqhx4tHZnsFn3v0qeFU4r9X16umghIHBnsEy/tdrFuL3fufw6pLLPK5EDABEdTNKtYLBsQRnLO/EP7znt1COHeLUIeDjgAMOVWEg2LWvjDec0I3P/u+TUIk5yZKIAYCoDgVGsHckwerTFuOLf3wymjLB/hErR60vt/ALAitInWL3YIzzTl+Cf/vTkxEGBqljACCq2/sfDwHN+g+BFQwMx3jLKQtw5OJWfOa/NmHdL3ZBoGjKBOwIvGDlB9QDlcRhtOKwcG4Wf/H243DxWctQilPECedVEDEAEM2AEDA4kmBJZw5XfOAUrPv5Lnx1w5O4+6EB7BuJ4fXZ+wd4BXSWLGsnqK7nb+TZv7/3ikxocOj8Zvx/py5Ez8pDcWhXE/aNxBARFn8iBgCi6ShZr5y1gnLigAR406vn440ndePRbSO479F9eGjrELb2l1CqVGezd7ZnENjZs7StEWDfSFx9W2L89186vxknHtaB45e1o7M9g9FyioHhmB0TIgYAotrS8VH64GgyvsLfKy9EE8sCD44mEABL5zfjmENaIVJ9xu29AlLtGAhmV6FLva8u5yvVuRPGCBKnKFUc+odiWCMs/kQMAERVzivmtWUQWKnBznvV1/gGx2KUKg6Z6MBH6BMTAMuJRyl2T/cV5OmwMdv8xu+v1Zn/wsJPxABA9JujckU2srBm6tvlHkBgDfYOx+gfrmBpdwvKSXpQm/0YAZ53Gvtsr3es90QzHl8DpKmrEVKdKNbRHCITmKmfNKfjk/lGEzy+YxRRKNx+loiIAYBqP0gUOA+0NoXIZS28ak0GjqlT/OKxfdVZ6AwAREQMAFT7DkDqFO3NIea0REidTn3rWIEoMLj7oYHqjH1e4UREDABUe857tOQCLJybRZLqQT2Pf1nfTxW5jMXGzYP49ZYh5KIA3O2XiIgBgGpMUd0cZun8ZjjvazJ5zBrBcCnFN3+6HZnIwHMiABERAwBNTwg4dklrzb6fV0VLLsA37tqGrXtKyISGUwGIiBgAqNbSVHHk4lbkIgvvahA4xucBPLl7FH0bnkRrUwjnGAGIiBgAqGasEcSJw6HdzejuyCKp0e5wzivamkJc+73NePipYTRlLB8FEBExAFAtJalHV3uE4w5tRTl2Uz4RcEJoDQaGYny271eIQsM1AYiIGACollQBaw1ee1wnnGrNVpFzvvoK4v/8dDu+/D+PobMtgyTlKwFERAwAVJuLbPwxwClHzUVbLqjp83ivirbmEP9ww4P47n07Mbc1QpKyFUBExABAU04EKFU8jl7cguMObUepho8BVKs7/Bkj+OC/34uNTwxiXlvETgARMQDwEFBNRuJe0ZQNsPKErvGtemv4vVURBQalisPv/ePP8ONNe9DdkUXqlPMCiIgBgGhKLzQjKMceq06cj7amEM7XtvI6X92VcHA0xv/+/M/w1fVPYF5bBtZIdYliIiIGAKLJJwKU4hTHHdKG1xw7F6PlFNbUdk9Z5xWZyAIKfPQ/fo5PfOUXiFOPOa0RVLXmoYSIiAGAZoXq2wCC1acvmbbWu/cKY4D25gjXfHczej59B277yVPIRBYdzRFEqh0B7/l4gIgaW8BDQLViRTA8lmDVCd049pBWPLZ9FJmMgdZ4Pp5qddOgua0Rntw9hvf/67049Zi5uOisZXj98V3obIuQOI9K4pGkClWtrmcsPIczmfPVLg8XhCJiAKBak+pNeG5rhAtffwh6125EU9YinaaV+lOnyIYWucji3of34mcPDuCIxS0488RunLGiE0cvacO8tgiZ0MCIjHcEmARmqtR7zGkN0ZwJ2N0hYgCgWjNGMDyWYvUZS3Dd95/Atv7StK7S58dH9825AAJg6+4xXPHNR/GVbz+G7jlZLJvfjGXzq8sYd7VnEAam2hGgGcd7oClrcdeDA9UNongeiQGAqKZNACTOo7M9g4vOWobeax9ALmOnfSa+H58AGIUG2chCFdg3kuCuvQO4Y+MeqKKmry7S1FCtnuPq3hA8HsQAQFRT1giGRxP0vOEQfP1HW/DwU8PIZYL9RXi6C4QbHxkGVhAG1c4ABOCewo0TAjgPgIgBgKZJ6hUdzSH++Jyj8L7/dw+aM0C9rc2nCraJiahh8TVAmrYuwOBogrNPWYjfOWUh9o0mNV8XgIiIAYBoOgiQOo+P5I9Be0uIxHk+ZyciYgCghr/4RFAqOxy9qBUfvuAYDI+lMOwCEBExAFDjs1YwMBLjorOW4ZzTFmPvcILA8rIkImIAoIYnApQrDmsuWYEjFzVjtMz5AEREDADU+BehCOLUY25LBv/n909EYA1Sr5wPQETEAECNzhrB4FiCU4+dh7+59FUYKaUwTABERAwA1PgCKxgYitGz8hB85MJjsGewgsAyBBARMQDQrAgBe0di/PE5R+GP3nYU9gxVYBkCiIgYAKjxCaobBn3yXcvxh//rSPQPVTsBjAFERAwA1MgBYLzSD44m+OS7VuAP/9eR2D1YgTHCiYFERAwANFtCwCfeuQLvX3009o4kgIKLBRERMQDQrAgBYzE+9vbj8DeXHo9S7BAnnpMDiYgYAKjRQ4CIoH8oxrvPPgxXfOBUtDWFGBzlioFERAwA1NghANW3A/qHYqw6cT76Pnk6Tl/eiT1DZYiAqwYSETEAUCMLrGDfSIwFc7L48odfgw+efwzKscdIOa2+JcAcQETEAECNGwLKsUMl9vjIhcfimo++FscvbUf/UAznlHMDiIgYAKhhL9rx1wH7h2KceuxcXPfx0/CX71iO5lyAgeF4f1AgIiIGAGrQbsDwWArnFe8750gU/+oMXHzWMqgq9o7E0PE/w0cDREQMANRgrKmuENg/FGN+exafufwEfO2TZ+DtKw+FEcHAcIwk9bBG9v9ZIiICAh4CapRuQJx6lGKHoxa14v/8/kn4vbOH8PU7tuJbP9uOJ3aOwRggl7EIx18f9KpQ5bEjIgYAohlNpBoESnGKsQqwbH4zPvHO5fiD3zkc63+5C9++ezvue2Qf9gxVYESQjSyi0OzvCqgCqgpmAiJiACCagYwIIEA5cRirODRlA+TfcAjOP+MQPLFzFD/+1R7csXEP7n98H3bsLSNOqo8IosAgCASBMZw3QAdt4rGT4cVEDABEtQ8CxgLOKfaNJBAAizpzuORNy3DRmUuxc18Zv9oyhPsfH8RDW4bx6I4R7NpbxnApQZwqvNfxICDgooN0IAFgaDRBqZJy7gkxABBNBxHAjo/C4sSjHDsAQFtTiJWv6sZZJ81H6hUjYwn2DFWwrb+M7f0l7BqsYGA4xkgpwd7hBOXEgYsO0isJoGMVhxMO74DzyhBADABE9RIGUqcYGkue/jAYweJ5TVja3Vxt3RrZP0kwdb7697yL0yu53gCkXlFOPISPAogBgKj+wgAAKIBK4lGOf3MioIDFnw7AeGjkPABiACCaAaGAIzWa1BYAUZ3i1CYiIiIGACIiImIAICIiIgYAIiIiYgAgIiIiBgAiIiJiACAiIiIGACIiImIAICIiIgYAIiIiYgAgIiIiBgAiIiJiACAiIiIGACIiImIAICIiIgYAIiIiYgAgIiIiBgAiIiIGACIiImIAICIiIgYAIiIiYgAgIiIiBgAiIiJiACAiIiIGACIiImIAICIiIgYAIiIiYgAgIiIiBgAiIiJiACAiIiIGACIiImIAICIiIgYAIiIiYgAgIiIiBgAiIiIGACIiImIAICIiIgYAIiIiYgB4oS8WpAJAVHhgiYiIJpEgDSa1uppJ+rEAAE1hOhqK9FsjgKjyfBERER04VcAagfcYraDSDwBY0zsp9XVSOwC7Dp+TipUKGwBERESTNfQXeKgzLlupuw7A/oJ/zz0QIBURgON/IiKig+0BAAIYkXRocGhSv3IwWT+hqoqIJLtvOX7XeCxgBCAiIjq4EbZaIyKK/ifHhkefPequgw5A1RqpJgGURPgQgIiIaFIaACIwBqXcQMmN1/86mwNQ3CQA4OB3WyPgQwAiIqKDrv+wRmDF7Dmzd0OqikkbYU9eAOjaJQAQJ35ARKCs/0RERAdFIGoNoNDxNwAKdRgAJnjZoeM/NhERER1UD0DFGCSp2wkAWLV+0ur2pH2h9eurfw2N7vbew6tylUEiIqKD7gIALsGuyf66k1akV61Z5QFAQvtUJfEqwmWGiYiIDm78D+O8R5ixW5852K6rAABUVyZKU7PVeS1bMQAnAhIRER3M8N9UEq9i8BQArEJ1sF1nAaCqVEp2QnUgCAQKLgdMRER0oA0AKwaJ82VJ0ycATNoywJMbAKT6v+seOXIkDM0ToeUkQCIiogPlVREEAgPs2rMjqd85AAJo39fytre316vHo4G1UM/VAImIiA60roaBQRTZx47/k+IoBBBBHXYAAOTH1wJInXvMGJnUH5SIiGiWRQAfWAuXuMcBqH4tb+uyAwAA2N2tACBifpU6D+WrgERERAceAQRIoBsBABt3Teqz9Ukt0Gs2LlcACEL5VbmSJsYIAwAREdEBUFUbxw6hDR8EgOKK7kntqk9qmtBqWNHt11zcnOZkozWytJykarg7EBER0Supp2pFBIIRm5EVi8+59klVSN3OARBAVSELL107GgbYFAYCgXieSiIiolc2/g9Dg8DI49/YntsOAGaS59VNfot+/UoLAHHqfhEGdjzIEBER0cseUKv4TGBhRH7+3vdekagWzGQX00kPABPLFEoY3MOJgERERAcw/ofCGEEl8feNF9dJr6WTHwCwwQOATdOfjVaS0cAawy4AERHRK+oB2NFy4jOh3AkAxX/tnvQ6OukBoLcXXgH50v1HbQmtvT8TWahySWAiIqKXyUeBEae6VZv1lwCQLxYnfT7d1LTnCyttb2+vd4ofR6EFOBGQiIjoZQeAbMYitOauhWevHVUtGJmCTvqUBID1E7+Bd3c556HgPAAiIqKXQ1VhjUGcuDurRXX9lNTQKfmiq9ZscACA0P1orJIMhtYYPgYgIiJ6GUTsSDlxYRhsqAaAVVPSRTdT87NX1wNYuvqr20Jj7spGAdcDICIieqnRP9RnIysCffBHydj9ACC9vTMnAADA+vH1ABL13w0DA+WbAERERC+VAHw2slCV7/X0FGPtm9wNgGoSAFaNtyyc1dtHSnEiAsszS0RE9OJ1OU48VPx3pvwbTdUXlt5er4As+/lRvxQjP89lrEDgeG6JiIieZ/Cv0CiwJknc1hGb+QEAoKc4ZY/Pp3R2/vp1K6309nrxuD0TWqjnREAiIqIXiAAulwkgBuuOW33lcF9f3soUPj6f0gCwalX1MYBX3DBaThOI8DEAERHR85V/wKTOI1UUASA/xd9vSgOASK9XhSx+4PBfALi3KROIKh8DEBERPav4KzQTWlNJ3ZPDvrIOwJS2/6c8AADA+jXVxwBGcGMUWPAhABER0W9EANeUCWCNueX4nuKITnH7vyYBYNX45kCxdzeOlpNRa8WCrwQSERE9Xf4BW4pTjX36NQDVZwBTbMoDgPTCa6Fgll54/WNG/O0tuQDqwUWBiIiIAKiqb86G4r3e8/j9T92lCunpKU754/LarNG/YpNUf0m52ntARYWnnIiIaOL1PwMRuebM3g0pivma1OaafBMZTzLbo6bvlOP0oVwUGIWyC0BERLO+/oeBsSOlpD+EvwEAkC/WpD7WbJc+7cvbU865YswYc3UuE0A95wEQEdHs5r36llwIY+WG7guu2659eStSm/pYu216Ny5XAIhN5frRcrIvsIaTAYmIaFYTEVOOXeqdfqU6+l9es7pYswAgvb2+ry9vDzvva5sFUmzJhfCejwGIiGh2Ug/X0hSKU3zvkPzau7RQMCK9NauLppa/bH482XiX/mspTlMRMbwEiIhoVgYAqEAVxui/ANg/Yb4hA0B1ZcCCWdJz/c+919vamkNRz5UBiYholhV/Vd+cC00l8Xct3JW7XVVFavDq3zMF0/XLB8D/SRL/NjFgF4CIiGZZAACsETiDz8p7r0h0zl4L1HZAXPPiK9LrtVAwC/Nr73Jev9uSCw33ByAiotk0+m/KBqZUSe8fSMvfUEXNR//TEgAAAGuqf7Hie1PvExFwYSAiIpo1o//ACmyA3uN7inGtFv6piwAw0QVYcMF1d6aJ/0ZrU2Q85wIQEdEsGP235EJTjt1PF3ZsuUW1YKZj9D99HYDxLoAA8Nb8vXOuYgwEXBeAiIgamqgYQWDkb+XMDSmKm6atAz5tAUCk13+tL28PPf+an6ZO17Y3R4brAhARUeOO/uFac6GtpMntC8679lYtTN/of3o7AADyG5erKiR2+pmxSjoUWGNU2QUgIqLGq/8ikFR9ao38FQQ6MR9uVgYA6e31KObNsp61j4vI59qaI1HlVsFERNRYvFc/3um+auHqtXf19eVtLVf9q7sAUG0DFL0WYOyc0ufHysnD2Yy13CmQiIgaZuiv0DAwppy4fi/2b1Qh+Y3Lp73bPe0BQARaXJGX+WcWR1TcR0MrgAofAxARUYMEAPUtuVC8194l5121pVjMG+ntnfaBbt28f9/Xl7c9PUW39YaLb8xlgvMHRxJnDCwvHSIimqm8qm/Jhib1/s6Fu3NvwHsWOqBXa7Xlb113ACZMTAi01n44TvxAGIhRVXYCiIhoxg7+jREoECOw75f3XpEA1c53PfxwdRMAJiYELjzv6s1O/V+35EIBhIsDERHRjOQcfEdzxiTOf37ROVf9TOtg4t+z6m5dRSVA0Jc32Lhcn3rVY9/KRfbNg6OxM0b4KICIiGYMr+qbM6Fx6u+XET3th7dVyvm+oq+X0X9ddQDG04hi43KV3l7vQ31f6n1/FBrhowAiIpopVKHWGhVBxQPvXXjp2lHk66f1X5cdgP0Hry9vpafott7wrsubspmvDI7Eqcj0bV1MRET08gOApnNbs8FoKf2rRRde8+mJmlZvP2fd7sK3PwTcePG1zdnw4r2DFWcsHwUQEVH98h6urTm05ditf/j+J9+8akW3Il9frf/6DwCqAgCbb768Pev1x2LkuLFK4o2I4SVGRER1WLd8GBgJrdk1VpbXHfbOqzerqojU59o2dVtMqwdsjRx23tX71OqlIloKjIB7BRARUT3Wf4FoFAaSePeew9559ebqcr/1u7BdXY+mRXq99uXtotXX3l2O/YdbmiIDgK8GEhFRXfEKN6c1Y5M0/cySC667VccXt6vnn7nu2+nSU3Tal7dLe9b+W6Xi/mNuWybwXlNebkREVBfF36vraImCsTj5nyt+ufavtS9v0VOs+z1tZCYcXFUIinmDJUui7dv7vxOF5reHuD4AERFN+8hffVMmNEb0QS/xqvnn/NcuYOIxdn2bERPqRMbXBzj9/5ZGxtw7U+8357KB9cpdA4mIaJoGp1AfWitGdK9zPr/g3K/uRE+PmQnFf8Z0APYf7PFXA7fd/HunRMbfXqqkHYnzakSElyIREdWsHinUWPhcFGgpTS9YesF1t65btzI488wNM+YR9Yx6pU56ik7XFYJFq6+8ezRJLstGNrVWPN8MICKimtYjgWvJRrZcSf9s6QXX3aqFwowq/jOuA7A/eRVWBtK7IX2y76L3tTRFXxwciR0ERmbo70NERDNp9K/pvLZcMFpOPrXw/Gv+ul5X+mvIAAA8/Thgyw2XfKw1F/7d3uGKEwEnBRIR0ZTxXtPOjlxQKqf/PP+8qz8wU4v/jA4AzwwBu2669LPZTPDR/sGKE8MQQEREU1D8VdN5rdmgnLi1/3rfsstWbNok9bbD3ysxs5fV7Sl67cvb7vOu+fNy4j83tz1j1XOhICIimpriX0nc2g3XjV0O9GImF/8ZHwAEUPQUvWrBdJ971Z9XGAKIiGgKi//668Yuz/dVF/mZycV/vIbOfAoItCAivX7PLZd/NgzNRwcGKw4GlrMCiYjogIu/13ReWzYox+l1G64vXZbvK/o1ayC9vZjx69A0xM56AiikV1ULpvMZnQAoHF8RJCKiAxhYQlXTzo7xtn+DFf+G6QA8Xydgx02X/2UY4DPDpcSrKgTcRpiIiF5GLakOHP28toytxOnnu1Zf8yFVoJGKf8N0AJ7ZCRDpVe3L2wXnXfW35Tj9s2xoxRpjVDkvgIiIXqr4q4cA7c2RraT+U12rr/lgoVAQAGik4t9wHYBnn8S8FSm6bcVLzo8y5sok1fZSJeUGQkRE9Px1w8OFgdgwsi5J3Z8tuWDtF1ULBujVmT7hr+E7AM9KNlJ06worg0X5a7+eeHd2GJjNrc2R5VbCRET0XM6ra8oGNpMJ+pNUz19ywdovrlu3MhDp9Y1Y/Bu6AzBhYnOG7Tddtky9frUpG7x2YKjsRMSIcOlgIqLZzntNO1ozQer0Vx7+HQvOveaX6worgzN7NzT0gLHhJ8adeeaGVPvyduF5V28e3Lvvzc7plXNaM1YEwu2EiYhmL4V6r+rntmWCJPXfHEuTs2ZL8Z8VHYD9J7pQMNLb6wFgx02XfcAI/t57zYxxXgAR0Swc9cNFodgoDGCNfnre267+awDa15e3PTN0bX8GgBcLAQoBqq8J7rzlsjME+HJgzTH7hmMnAj4SICJq+FE/1Hv17c2RVeCpWN0fLz732lu0AAMUMDFQZABo1AtgfBOhR69/x/y25sw/B9a8fWgsgXfKzYSIiBp3EOggsHNaMijH6fcrivcsPf+aR8drgq/mg9lj1o54n7mF486bLn+fiH5aDOYMjyRODCcIEhE1EufUNedCK6JxaMyn5rztqs+IQGfydr4Ha9aujic9Raeqolow88+76l/LcbISHhvmtmesMRDPDYWIiBpi1K8KndeetYGV+yDyxrnnXPVpYHxu2Cwt/rO6A/AC3QCz+5bLPuJV/9Ia0z40GjsIjBHhcSIimlmFX1XVtzSF1ntNgtD+047NI58+/k+KI7N51M8A8LwXy9OrPT351YuPjzL2s2Egv1uOHSqxc8aI4fEiIpoJ93NNA2uCllwI5/yPUuf/fMH51/7kOQO+WY8F7YW7Adh96+XvUq+fDkNz2OBIDChSCAIeJSKiuhz1OwCmoyWSNPU7FfjbL9539Rd6e+G1L2/RU/QC7hDLAPBiF1GhYNYA6O3t9Y9cc3F3R5v9UOr1/WFocoMjsYqIF+HbAkRE9WBiUbfWXGSS1MNa/c9SrH+7rGft46qQYjFvejjqZwA40G7A1pvedZJV+wkRudAawdBYooZBgIhoGkf86hVAczY0xgCq+u0kdp9ZnL/uh8+9hxMDwAFcYBAU8/tniu645fI3B6Ifdh5nC4DhEoMAEdF0FP6mTGACawDBj1TNP3adc+XN1X9fMMAaFRG2+xkAJuGCKxQMgP2rRO277fKzK17/Eoo3GAGGx5KJRwOcLEhENDUDMudVTUsuFGsEHnq3MfJ3nW+96uv7B2zjq73yaDEATLq+vrzN54sT20PKvtsuf0vi9YPO69mhtRguxVDVFBDLxYSIiA666CsAByBoaQrHp/Dpj7zYz2+659FbJjbtYbufAaB2F+Vzlo7ce8vlb6w490de8bZcNsiMllLEiXMiEBExPGJERK+k8KtXhQaBsS25EOVK6q013zZG/q3znKu+MTGbn4WfAaBeOgLYedvFJ4qzFzuv78hEdknqPEZLKQBNITAChgEiohco+grAKRA0Z0JEoUWpEveLkRuNMdfMP/fqOyYKl5+l6/czANTlhVswWPP0HIEnv/X7c5vKybneyMVJom9oztpgrOJQrqQqIg6iDANExHunqgLiFGoyoTVNmQClSqqBlbtU5Hqj9sau1Vduq/7ZZ0/KJgaA+rqYCwWDFZvkmRfo7pt/7xSn6QUCnOsVx2Uji1IlRTlxECAFYKS63DDPBxE1fs2HKlS8qtpMaCWXCZA6j8T5zdbKbZE1xe+WRn888e6+9uUt8suVk/sYAGbKFS7r16y0b+zdkE70p/Qrl2X75/jfdsCFzuONAjkql7Eoxw7l2MF7dSIChRpT3X6A54eIGmWU7wFVEQkyoUU2YxEnHmnqtoShXedVb7QI1nWtvnJ44r9bt25lsGrVBjfxiJUYAGZkV2A91puJ2aoAcPeX3tq0tHveaRXv3xIYnOUcXtWUDSJVoJw4xImD93BGoAo1gAjfKiCiur/fVf9PoVL9KySIQoNsZGFFMFpJUxH82gi+Z8R8Zzge+9ERPcXB/f89R/sMAA36wZBiX97kUd2OeOKfFworg/efcsSxpVLyhjDEac7jtao4rCkbBAogTjzi1CFNfXX+wPi5U6gZTwU8j0RU+0JffUdPDcRrdaRvA2skDA2iYKLgx16BLaG1d8WJuzObsz/Y+bOx+4/vLcYTX6uvL2/zAPCMCdXEANDwYaCra5eceebTnQEA+HFfPndctvm40cS9LrTyalWcGCf+6Ci0bdnQQAVIU0XiPNLUw3kPBbxUW2wAJrYv1mrPQJ/ezpgbGxPRC96Xnll6ZfwNfOxfTU8n7i8KtdYYBNYgtILAGhgRVFKHSpKORIF9VCD3x0l6T1Ng7to1MPjAcX9w6/Czvldfvrp6Kos+A8BsPw9aKMj6VevN7t3d+txNKwqFlcFFRy5Z0D0nOnbfaGV5aM3yMDCHJ04Pc84vDAKTiwJrAmugANR7eA84r/DVpbPGP9jVvyciej7GCMx4T9EagYjAmvF/bqrjCeeBOEkROy0ZYFcuYx9NE92ceP9AUzb4daViNm7rD7ad8t4rkmeHi4LB+vUG61d59PYqd+VjAKAX6A5gPBCs2t2tL/TKy+PrLstm+pP5QSY6NEn8kiRJF4sxCzKh6RZIp6qfpx4tqdcOr5qFwlgrTTzCRPR81SB1viwqiYikoZV+GFMKrOz2XgeSNN2Zet0RBcG20OAp7/GkH9m+Y+Glt48+35fr68vbrq5dsmr9Ko81vcpRPgMAHWiHQBXAGlm/vhoKXk7brK8vb5cDNmqJsmnZhJlyEjQ1R508nET0m8N/L/FwOiCBK7uwyY8mY2O7N+7yz5y8/EJFxPflLbp2SXF3t+bzfR7VuUks+AwANGWdAp34jK0RFDcJunbJegC7xz+E3AmLiA7+PqOyf/ABALu7FfnlCqxRQMCRPQMA1WvnAHh2Dl9T4Dknoue3plefWR0mZhPzwBARERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERFRw/r/AUBPpPqEZefhAAAAAElFTkSuQmCC"

HELP_FALLBACK = """<!doctype html><meta charset="utf-8"><title>Cómo se usa</title>
<body style="font-family:system-ui;max-width:640px;margin:40px auto;line-height:1.6;padding:0 20px">
<h1>Cómo se usa</h1><ol>
<li>Escribe tu pregunta en español y pulsa «Convertir pregunta».</li>
<li>Si aparecen preguntas, respóndelas con un clic.</li>
<li>Revisa la ecuación y pulsa «Buscar artículos».</li>
<li>Pulsa «Guardar en Citados» en los artículos útiles.</li>
<li>En la pestaña «Citados», copia la cita APA o descárgala para Word.</li></ol>
<p>Coloca el archivo «Instrucciones_de_uso.html» junto al programa para ver la guía completa.</p></body>"""


# ============================================================================
# PARTE 8. INTERFAZ (HTML + CSS + JavaScript, se sirve desde este mismo archivo)
# ============================================================================
APP_HTML = r"""<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Buscador Académico</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;1,6..72,400&family=Public+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;600&display=swap">
<style>
:root{
  --bg:#141312; --rail:#1A1917; --panel:#1A1917; --field:#1E1C1A; --hover:#24211E;
  --line:#2A2724; --line2:#36322D; --ink:#EDE7DF; --hi:#F4EEE6; --soft:#CFC6BB; --muted:#A59D93; --faint:#8F877D;
  --accent:#E0A95B; --accent-hi:#F3CE96; --link:#E8B872; --on-accent:#1A1917;
  --ok:#9FC08A; --ok-bg:#232B1D; --ok-line:#40532F; --err:#E39A8C; --err-bg:#2A1C19; --err-line:#553229;
  --warn-bg:#221D16; --warn-line:#4A3C28; --warn-ink:#F3DDB8;
  --serif:"Newsreader",Georgia,"Times New Roman",serif;
  --sans:"Public Sans","Segoe UI",system-ui,-apple-system,Helvetica,Arial,sans-serif;
  --mono:"JetBrains Mono",Consolas,Menlo,monospace;
  --r:10px; --r-lg:14px;
}
.k-condition{--k:#F0B2A4;--kb:#221D1B;--kl:#3D2A25}
.k-population{--k:#9FD3C7;--kb:#1B2422;--kl:#2A3B37}
.k-intervention{--k:#BDB7EC;--kb:#1F1E2A;--kl:#33314A}
.k-focus{--k:#E8C38A;--kb:#231F17;--kl:#43382A}
.k-study_type{--k:#C5D99A;--kb:#1F231A;--kl:#36402B}
.k-free{--k:#CFC6BB;--kb:#1E1C1A;--kl:#36322D}
.k-not{--k:#E39A8C;--kb:#2A1C19;--kl:#553229}

*{box-sizing:border-box}
[hidden]{display:none!important}
html,body{margin:0;height:100%}
body{background:var(--bg);color:var(--ink);font:15px/1.5 var(--sans);-webkit-font-smoothing:antialiased}
button,input,select,textarea{font:inherit;color:inherit}
button{cursor:pointer}
button:disabled{cursor:not-allowed}
a{color:var(--link)} a:hover{color:var(--accent-hi)}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:6px}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
::selection{background:#5A4424}
::-webkit-scrollbar{width:12px;height:12px} ::-webkit-scrollbar-thumb{background:#34302B;border-radius:8px;border:3px solid var(--bg)}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}

/* ---------- estructura ---------- */
.app{display:flex;min-height:100vh}
.rail{position:fixed;inset:0 auto 0 0;width:88px;background:var(--rail);border-right:1px solid var(--line);display:flex;flex-direction:column;align-items:center;padding:22px 0 18px;gap:6px;z-index:20}
.logo{width:40px;height:40px;border-radius:10px;background:var(--accent);display:grid;place-items:center;margin-bottom:22px;border:0;padding:0}
.ritem{width:72px;padding:10px 0;border-radius:10px;border:0;background:transparent;color:var(--muted);text-decoration:none;display:flex;flex-direction:column;align-items:center;gap:5px;font-size:11.5px;position:relative}
.ritem:hover{background:var(--hover);color:var(--ink)}
.ritem[aria-current="page"]{background:#2A2622;color:var(--accent);font-weight:600}
.ritem .dot{position:absolute;top:4px;right:12px;min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:var(--accent);color:var(--on-accent);font-size:10.5px;font-weight:700;display:grid;place-items:center}
.ritem .dot:empty{display:none}
.rail .grow{flex:1}
.stage{flex:1;margin-left:88px;min-width:0}
.view{display:none;min-height:100vh}
.view.on{display:block}

/* ---------- controles comunes ---------- */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;height:44px;padding:0 18px;border-radius:var(--r);border:1px solid var(--line2);background:transparent;color:var(--ink);font-size:14px;font-weight:500;text-decoration:none;white-space:nowrap;transition:background .15s,border-color .15s}
.btn:hover{background:var(--hover);color:var(--ink)}
.btn.primary{background:var(--accent);border-color:var(--accent);color:var(--on-accent);font-weight:600}
.btn.primary:hover{background:var(--accent-hi);border-color:var(--accent-hi)}
.btn.primary:disabled{background:#5B4A33;border-color:#5B4A33;color:#A8998A}
.btn.sm{height:36px;padding:0 13px;font-size:13px}
.btn.soft{background:#2A2622;border-color:transparent;color:var(--warn-ink)}
.btn.danger{color:var(--err);border-color:var(--err-line)}
.btn.outline{border-color:var(--accent);color:var(--accent);font-weight:600}
.btn.outline:hover{background:#2A2419;color:var(--accent-hi)}
.btn.saved{background:var(--ok-bg);border-color:var(--ok-line);color:#C7E0AE}
.linkbtn{background:none;border:0;padding:0;color:var(--link);font-size:inherit;text-decoration:underline;text-underline-offset:3px}
.linkbtn:hover{color:var(--accent-hi)}
.linkbtn.muted{color:var(--soft)} .linkbtn.red{color:var(--err)}
.pill{background:#2A2622;border:1px solid transparent;color:var(--ink);border-radius:18px;padding:7px 13px;font-size:13px;line-height:1.3;text-align:left}
.pill:hover{border-color:var(--line2)}
.pill[aria-pressed="true"]{background:var(--accent);color:var(--on-accent);font-weight:600}
.eyebrow{font-size:12px;letter-spacing:1.3px;text-transform:uppercase;color:var(--faint);font-weight:600;margin:0}
.field-in,select.field-in,textarea.field-in{width:100%;background:var(--field);border:1px solid var(--line2);border-radius:8px;color:var(--ink);padding:9px 11px;font-size:14px;outline:none}
.field-in:focus{border-color:var(--accent)}
select.field-in{appearance:none;background-image:linear-gradient(45deg,transparent 50%,var(--muted) 50%),linear-gradient(135deg,var(--muted) 50%,transparent 50%);background-position:calc(100% - 15px) 55%,calc(100% - 10px) 55%;background-size:5px 5px;background-repeat:no-repeat;padding-right:28px}
input[type=checkbox]{accent-color:var(--accent);width:16px;height:16px;margin:0}
.check{display:flex;align-items:center;gap:9px;color:var(--soft);font-size:14px;cursor:pointer;padding:3px 0}
.check .n{margin-left:auto;color:var(--faint);font-size:13px}
.info{font-size:13.5px;color:var(--soft);display:flex;gap:8px;align-items:flex-start;line-height:1.5}
.info svg{flex:none;margin-top:3px}
.fine{color:var(--ok)}
.muted{color:var(--muted)}

/* ---------- filtros (se reutilizan en tres lugares) ---------- */
.fgroup{display:flex;flex-direction:column;gap:8px}
.fgroup h3{font-size:12px;letter-spacing:1.2px;text-transform:uppercase;color:var(--faint);font-weight:600;margin:0}
.yrs{display:flex;align-items:center;gap:8px}
.yrs span{color:var(--faint)}
.yrs select.field-in{flex:1;min-width:0;font-size:13.5px;padding:8px 24px 8px 10px;background-position:calc(100% - 13px) 55%,calc(100% - 8px) 55%}
.filters{display:flex;flex-direction:column;gap:24px}

/* ---------- INICIO ---------- */
.home{display:flex;gap:56px;padding:104px 72px 60px 96px;max-width:1500px}
.home-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:26px;max-width:760px}
.home-main .eyebrow{color:var(--accent);letter-spacing:1.5px;font-size:13px}
.home h1{margin:0;font:400 60px/1.08 var(--serif);letter-spacing:-.5px;color:var(--hi)}
.bigask{background:var(--field);border:1px solid var(--line2);border-radius:16px;position:relative;transition:border-color .15s}
.bigask:focus-within{border-color:#6B5636}
.bigask textarea{display:block;width:100%;background:transparent;border:0;outline:0;resize:none;font-size:19px;line-height:1.45;padding:22px 24px 8px;min-height:92px;color:var(--ink)}
.bigask textarea::placeholder{color:#7E766C}
.askbar{display:flex;align-items:center;gap:8px;padding:10px 12px 12px 18px;flex-wrap:wrap}
.chip{background:#2A2622;border:0;color:var(--soft);border-radius:8px;padding:8px 12px;font-size:13px;display:inline-flex;gap:6px;align-items:center}
.chip:hover,.chip[aria-expanded="true"]{background:#35302A;color:var(--ink)}
.askbar .btn{margin-left:auto;height:46px}
.pop{position:absolute;left:12px;top:calc(100% + 8px);z-index:15;width:min(520px,calc(100% - 24px));background:var(--panel);border:1px solid var(--line2);border-radius:var(--r-lg);padding:20px;box-shadow:0 18px 40px rgba(0,0,0,.45)}
.pop .filters{display:grid;grid-template-columns:1fr 1fr;gap:20px 24px}
.pop .close{position:absolute;top:10px;right:12px;background:none;border:0;color:var(--muted);font-size:20px;line-height:1;padding:4px 8px}
.examples{display:flex;flex-direction:column}
.home-main .examples .eyebrow{margin-bottom:4px;text-transform:none;letter-spacing:0;font-weight:500;font-size:13px;color:var(--faint)}
#exList{display:flex;flex-direction:column}
.examples button{background:none;border:0;border-bottom:1px solid var(--line);text-align:left;color:var(--soft);font-size:15px;padding:11px 0}
.examples button:hover{color:var(--accent-hi)}
.home-side{width:340px;flex:none;display:flex;flex-direction:column;gap:18px;padding-top:64px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:var(--r-lg);padding:20px}
.card-head{display:flex;justify-content:space-between;align-items:baseline;gap:10px;margin-bottom:10px}
.card-head h2{margin:0;font-size:15px;font-weight:600}
.recent-ref{font:15px/1.45 var(--serif);color:#D9D1C6;padding:10px 0;border-top:1px solid var(--line)}
.recent-ref .who{display:block;font:600 13px var(--sans);color:var(--accent);margin-bottom:2px}
.recent-ref:first-of-type{border-top:0;padding-top:0}
.recent-q{display:block;width:100%;text-align:left;background:none;border:0;color:var(--soft);font-size:14px;padding:7px 0}
.recent-q:hover{color:var(--accent-hi)}
.recent-q small{display:block;color:var(--faint);font-size:12px}
.empty-small{font-size:13.5px;color:var(--faint);margin:0}

/* ---------- RESULTADOS ---------- */
.rhead{border-bottom:1px solid var(--line);background:var(--bg);position:sticky;top:0;z-index:10}
.rtop{display:flex;align-items:center;gap:24px;padding:18px 48px 8px}
.wordmark{width:220px;flex:none;background:none;border:0;padding:0;text-align:left;font:24px var(--serif);color:var(--hi)}
.wordmark small{display:block;font:12px var(--sans);color:var(--faint)}
.wordmark:hover small{color:var(--accent)}
.qpill{flex:1;max-width:760px;display:flex;align-items:center;gap:12px;background:var(--field);border:1px solid var(--line2);border-radius:26px;padding:4px 4px 4px 18px}
.qpill:focus-within{border-color:#6B5636}
.qpill input{flex:1;min-width:0;background:transparent;border:0;outline:0;font-size:15px;height:40px}
.qpill .btn{height:40px;border-radius:20px}
.toplink{margin-left:auto;color:var(--soft);text-decoration:none;font-size:14px;display:flex;gap:8px;align-items:center;background:none;border:0}
.toplink:hover{color:var(--ink)}
.badge-n{background:#2A2622;color:var(--accent);font-size:12px;font-weight:600;padding:1px 8px;border-radius:10px}
.stabs{display:flex;align-items:center;gap:2px;padding:0 48px 0 292px;font-size:14px;overflow-x:auto}
.stab{background:none;border:0;border-bottom:2px solid transparent;color:var(--muted);padding:10px 14px;white-space:nowrap}
.stab:hover{color:var(--ink)}
.stab[aria-selected="true"]{color:var(--ink);border-bottom-color:var(--accent)}
.stabs .freechip{margin-left:auto;display:flex;align-items:center;gap:8px;color:var(--soft);font-size:13.5px;white-space:nowrap;padding:6px 0}
.rbody{display:flex;gap:48px;padding:26px 48px 80px}
.rbody > aside{width:220px;flex:none}
.rbody > aside .filters{position:sticky;top:132px}
.rmain{flex:1;min-width:0;max-width:980px;display:flex;flex-direction:column;gap:18px}
.fsum{display:none}
.alsoin{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:13.5px}

.band{background:var(--panel);border:1px solid var(--line);border-radius:var(--r-lg);padding:16px 18px;display:flex;flex-direction:column;gap:12px}
.band-head{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}
.band-head .right{display:flex;gap:16px;align-items:center;font-size:13px}
.lint-ok{color:var(--ok)} .lint-bad{color:var(--err)}
.ccards{display:flex;align-items:stretch;gap:10px;flex-wrap:wrap}
.ccard{flex:1 1 170px;min-width:0;background:var(--kb);border:1px solid var(--kl);border-radius:var(--r);padding:11px 13px;display:flex;flex-direction:column;gap:3px}
.ccard .cat{display:flex;justify-content:space-between;align-items:center;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--k)}
.ccard .lbl{font-size:15px;font-weight:600;color:var(--hi);line-height:1.3}
.ccard .syn{font-size:12px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ccard .or{font-size:11px;font-weight:600;color:var(--faint);margin:0 4px}
.xbtn{background:none;border:0;color:var(--faint);font-size:17px;line-height:1;padding:0 2px;border-radius:4px}
.xbtn:hover{color:var(--err)}
.joiner{display:flex;align-items:center;font-size:11px;font-weight:700;color:var(--accent)}
.joiner.not{color:var(--err)}
.addc{flex:0 0 118px;background:transparent;border:1.5px dashed #3E3934;border-radius:var(--r);color:var(--muted);font-size:13px;min-height:74px}
.addc:hover{border-color:var(--accent);color:var(--ink)}
.addform{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.addform input{flex:1;min-width:220px}
.qband{background:var(--warn-bg);border:1px solid var(--warn-line);border-radius:var(--r);padding:12px 14px;display:flex;flex-direction:column;gap:10px}
.qband .qtop{display:flex;align-items:center;gap:12px;justify-content:space-between;flex-wrap:wrap}
.qband .qt{font-size:14.5px;color:var(--warn-ink)}
.qband .qt b{font-weight:600;color:var(--accent)}
.opts{display:flex;gap:8px;flex-wrap:wrap}
.textq{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.textq input{flex:1;min-width:200px}
.qsub{font-size:12.5px;color:var(--muted)}
.qdone{display:flex;align-items:center;gap:10px;flex-wrap:wrap;font-size:13.5px;color:var(--soft)}
.qdone .ans{color:var(--ink)}
.qlist{display:flex;flex-direction:column;gap:14px;padding-top:4px}
.qlist .qitem{display:flex;flex-direction:column;gap:8px}
.qlist .qitem > span{font-size:14px;color:var(--soft)}
.notes{margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:6px}
#errors:empty,#advice:empty{display:none}
.ccard .lbl .xbtn,.col .head .xbtn{margin-left:6px}
.countline{display:flex;justify-content:space-between;gap:12px;font-size:13px;color:var(--faint);flex-wrap:wrap}
.advice{background:var(--panel);border:1px solid var(--line);border-left:0;border-radius:var(--r);padding:12px 16px;font-size:14px;color:var(--soft)}
.advice b{color:var(--ink)}
.errors{background:var(--err-bg);border:1px solid var(--err-line);color:#F2C4BA;border-radius:var(--r);padding:12px 16px;font-size:14px}
.results{display:flex;flex-direction:column}
.res{display:flex;flex-direction:column;gap:5px;padding:20px 0;border-bottom:1px solid #24211E}
.res:first-child{padding-top:4px}
.res .src{display:flex;gap:8px;align-items:center;flex-wrap:wrap;font-size:12.5px;color:var(--muted)}
.res .src i{font-style:italic}
.tag{background:#2A2622;color:var(--soft);font-size:11.5px;padding:2px 8px;border-radius:10px}
.tag.free{background:var(--ok-bg);color:#C7E0AE}
.res h3{margin:0;font:400 21px/1.3 var(--serif)}
.res h3 a{color:var(--accent-hi);text-decoration:none}
.res h3 a:hover{text-decoration:underline;text-underline-offset:4px}
.res .who{font-size:13px;color:var(--muted)}
.res .abs{margin:2px 0 0;font-size:14px;line-height:1.62;color:var(--soft);max-width:78ch}
.res .acts{display:flex;gap:18px;align-items:center;margin-top:8px;font-size:13px;flex-wrap:wrap}
.res .acts a,.res .acts .linkbtn{color:var(--soft)}
.res .acts a:hover,.res .acts .linkbtn:hover{color:var(--accent-hi)}
.loading{padding:40px 0;color:var(--muted);display:flex;gap:12px;align-items:center}
.spin{width:18px;height:18px;border:2px solid var(--line2);border-top-color:var(--accent);border-radius:50%;animation:sp 0.8s linear infinite}
@keyframes sp{to{transform:rotate(360deg)}}
.placeholder{border:1px dashed var(--line2);border-radius:var(--r-lg);padding:28px;color:var(--muted);font-size:14.5px}
.placeholder b{color:var(--ink);font-weight:600}
.moreres{align-self:center;margin-top:20px}

/* ---------- ECUACIÓN ---------- */
.eqpage{display:flex;min-height:100vh}
.eqmain{flex:1;min-width:0;padding:44px 48px 60px 64px;display:flex;flex-direction:column;gap:26px}
.pagehead{display:flex;flex-direction:column;gap:6px}
.pagehead h1{margin:0;font:400 42px/1.15 var(--serif);color:var(--hi)}
.pagehead p{margin:0;font-size:14px;color:var(--muted);max-width:80ch}
.pagehead .quote{font-size:14px;color:var(--faint)}
.cols{display:flex;align-items:stretch;gap:12px;flex-wrap:wrap}
.col{flex:1 1 180px;min-width:0;background:var(--kb);border:1px solid var(--kl);border-radius:var(--r-lg);padding:18px;display:flex;flex-direction:column;gap:10px}
.col .cat{display:flex;justify-content:space-between;align-items:center;font-size:12px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--k)}
.col .heads{display:flex;flex-direction:column;gap:4px}
.col .head{display:flex;justify-content:space-between;align-items:center;gap:8px;font-size:18px;font-weight:600;color:var(--hi)}
.col .terms{font-size:13px;color:var(--soft);line-height:1.8}
.col .terms b{color:var(--faint);font-size:11px;font-weight:600;margin:0 3px}
.col .orhead{font-size:11px;color:var(--faint);font-weight:700}
.colsep{display:flex;align-items:center;font-size:12px;font-weight:700;color:var(--accent)}
.colsep.not{color:var(--err)}
.addcol{flex:0 0 130px;background:transparent;border:1.5px dashed #3E3934;border-radius:var(--r-lg);color:var(--muted);font-size:14px;min-height:140px}
.addcol:hover{border-color:var(--accent);color:var(--ink)}
.syntax{background:var(--panel);border:1px solid var(--line);border-radius:var(--r-lg);overflow:hidden}
.syntabs{display:flex;align-items:center;border-bottom:1px solid var(--line);padding:0 8px;flex-wrap:wrap;gap:4px}
.syntab{background:none;border:0;border-bottom:2px solid transparent;color:var(--muted);padding:12px 14px;font-size:13px}
.syntab[aria-selected="true"]{color:var(--ink);border-bottom-color:var(--accent)}
.syntabs .right{margin-left:auto;display:flex;align-items:center;gap:12px;font-size:13px;padding:6px 6px}
.eqwrap{position:relative}
.eqwrap pre,.eqwrap textarea{margin:0;padding:18px 20px;font:13px/1.75 var(--mono);white-space:pre-wrap;word-break:break-word;border:0}
.eqwrap pre{color:var(--soft);min-height:120px}
.eqwrap.editing pre{position:absolute;inset:0;pointer-events:none;overflow:hidden}
.eqwrap textarea{display:none;width:100%;background:transparent;color:transparent;caret-color:var(--accent);resize:vertical;outline:0;min-height:160px}
.eqwrap.editing textarea{display:block}
.eqwrap.editing{background:#171615;box-shadow:inset 0 0 0 1px #6B5636}
.tk-op{color:var(--accent);font-weight:600} .tk-not{color:var(--err);font-weight:600} .tk-q{color:#9FD3C7} .tk-tag{color:#7F776E} .tk-trunc{color:#BDB7EC;font-weight:600}
.eqfoot{display:flex;flex-direction:column;gap:10px;padding:12px 20px 16px;border-top:1px solid var(--line)}
.eqstate{display:flex;gap:12px;align-items:center;font-size:13px;color:var(--muted);flex-wrap:wrap}
.issues{margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:6px}
.issues li{font-size:13.5px;padding:8px 12px;border-radius:8px;background:var(--warn-bg);border:1px solid var(--warn-line);color:var(--warn-ink)}
.issues li.error{background:var(--err-bg);border-color:var(--err-line);color:#F2C4BA}
.issues li.ok{background:var(--ok-bg);border-color:var(--ok-line);color:#C7E0AE}
.side{width:360px;flex:none;background:var(--panel);border-left:1px solid var(--line);padding:44px 32px;display:flex;flex-direction:column;gap:22px;position:sticky;top:0;height:100vh;overflow-y:auto}
.side h2{margin:0;font-size:16px;font-weight:600}
.side .gohint{font-size:13px;color:var(--err);margin:-10px 0 0}
.side .gohint:empty{display:none}
.side .push{margin-top:auto}
.bigbtn{height:56px;width:100%;font-size:16px;border-radius:12px}
.emptybox{max-width:560px;margin:14vh auto;padding:0 24px;text-align:center;display:flex;flex-direction:column;gap:14px;align-items:center}
.emptybox h1{margin:0;font:400 34px var(--serif);color:var(--hi)}
.emptybox p{margin:0;color:var(--muted)}

/* ---------- CITADOS ---------- */
.citpage{display:flex;min-height:100vh}
.citmain{flex:1;min-width:0;padding:44px 48px 60px 64px;display:flex;flex-direction:column;gap:20px}
.headrow{display:flex;align-items:flex-end;justify-content:space-between;gap:24px;flex-wrap:wrap}
.headrow .pagehead{flex:1;min-width:280px}
.seg{display:flex;background:var(--field);border:1px solid var(--line2);border-radius:var(--r);padding:3px}
.seg button{background:transparent;border:0;color:var(--muted);border-radius:8px;padding:8px 14px;font-size:13px}
.seg button[aria-pressed="true"]{background:#2A2622;color:var(--accent);font-weight:600}
.tools{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.searchbox{flex:1;min-width:220px;display:flex;align-items:center;gap:10px;background:var(--field);border:1px solid var(--line2);border-radius:var(--r);padding:0 14px;height:44px}
.searchbox:focus-within{border-color:#6B5636}
.searchbox input{flex:1;min-width:0;background:transparent;border:0;outline:0;font-size:14px}
.typechips{display:flex;gap:6px;flex-wrap:wrap}
.typechips button{background:transparent;border:1px solid var(--line);color:var(--muted);border-radius:16px;padding:6px 12px;font-size:13px}
.typechips button[aria-pressed="true"]{background:#2A2622;border-color:transparent;color:var(--ink)}
.reflist{background:var(--panel);border:1px solid var(--line);border-radius:var(--r-lg)}
.ref{display:flex;flex-direction:column;gap:10px;padding:18px 22px;border-top:1px solid var(--line)}
.ref:first-child{border-top:0}
.ref.flash{animation:fl 1.6s ease-out}
@keyframes fl{from{background:#2E2618}to{background:transparent}}
.ref .meta{display:flex;align-items:center;gap:10px;font-size:12px;color:var(--faint)}
.kind{font-size:11.5px;font-weight:600;padding:3px 9px;border-radius:10px;background:#2A2622;color:var(--warn-ink)}
.kind.web{background:#1B2422;color:#9FD3C7}
.apa{margin:0;padding-left:36px;text-indent:-36px;font:16.5px/1.62 var(--serif);color:var(--ink);word-break:break-word}
.ref .row{display:flex;align-items:center;gap:16px;font-size:13px;flex-wrap:wrap}
.ref .row .it{color:var(--faint)} .ref .row .it span{color:var(--soft)}
.ref .row .acts{margin-left:auto;display:flex;gap:16px;flex-wrap:wrap}
.cited-empty{padding:34px 24px;text-align:center;color:var(--muted);font-size:14.5px}
.addref{width:420px;flex:none;background:var(--panel);border-left:1px solid var(--line);padding:44px 32px;display:flex;flex-direction:column;gap:16px;position:sticky;top:0;height:100vh;overflow-y:auto}
.addref h2{margin:0;font-size:17px;font-weight:600}
.addtabs{display:flex;border-bottom:1px solid var(--line)}
.addtabs button{background:none;border:0;border-bottom:2px solid transparent;color:var(--muted);padding:10px 12px;font-size:14px}
.addtabs button[aria-selected="true"]{color:var(--ink);border-bottom-color:var(--accent);font-weight:600}
.fl{display:flex;flex-direction:column;gap:5px}
.fl label{font-size:12.5px;color:var(--muted)}
.fl .hint{font-size:12px;color:var(--faint);line-height:1.45}
.fl2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.fl3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}
.inrow{display:flex;gap:8px}
.inrow .field-in{flex:1;min-width:0}
.status{font-size:12.5px;line-height:1.45}
.status:empty{display:none}
.status.ok{color:var(--ok)} .status.err{color:var(--err)} .status.wait{color:var(--muted)}
.preview{background:var(--bg);border:1px solid var(--line2);border-radius:12px;padding:14px 16px;display:flex;flex-direction:column;gap:8px}
.preview .apa{font-size:15.5px;padding-left:28px;text-indent:-28px}
.preview .pn{font-size:12px;color:var(--muted);line-height:1.5;margin:0;padding-left:14px}
.editing-note{font-size:13px;color:var(--warn-ink);background:var(--warn-bg);border:1px solid var(--warn-line);border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;gap:10px;align-items:center}

/* ---------- HISTORIAL ---------- */
.histpage{display:flex;min-height:100vh}
.histmain{flex:1;min-width:0;padding:44px 48px 60px 64px;display:flex;flex-direction:column;gap:20px}
.histmain .searchbox{flex:none;min-height:44px}
.hgroup{display:flex;flex-direction:column;gap:8px}
.hgroup h2{margin:6px 0 0;font-size:12px;letter-spacing:1.2px;text-transform:uppercase;color:var(--faint);font-weight:600}
.hrow{display:flex;flex-direction:column;gap:8px;padding:14px 18px;border-radius:12px;background:var(--panel);border:1px solid var(--line);text-align:left;width:100%;color:inherit}
.hrow:hover{border-color:var(--line2)}
.hrow[aria-pressed="true"]{background:#221F1C;border-color:var(--warn-line)}
.hrow .t{display:flex;justify-content:space-between;gap:16px;align-items:baseline}
.hrow .q{font-size:16px;font-weight:500;color:var(--hi)}
.hrow .when{font-size:12.5px;color:var(--faint);white-space:nowrap}
.hchips{display:flex;gap:6px;flex-wrap:wrap}
.hchip{font-size:12px;padding:4px 10px;border-radius:12px;background:var(--kb);color:var(--k)}
.hrow .facts{display:flex;gap:18px;font-size:12.5px;color:var(--muted);flex-wrap:wrap}
.hdetail{width:440px;flex:none;background:var(--panel);border-left:1px solid var(--line);padding:44px 32px;display:flex;flex-direction:column;gap:18px;position:sticky;top:0;height:100vh;overflow-y:auto}
.hdetail h2.q{margin:0;font:400 26px/1.25 var(--serif);color:var(--hi)}
.tiles{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.tile{background:var(--bg);border:1px solid var(--line);border-radius:var(--r);padding:12px}
.tile b{display:block;font-size:20px;font-weight:600}
.tile span{font-size:12px;color:var(--muted)}
.codebox{margin:0;background:var(--bg);border:1px solid var(--line);border-radius:var(--r);padding:12px 14px;font:12px/1.65 var(--mono);color:var(--soft);white-space:pre-wrap;word-break:break-word;max-height:220px;overflow:auto}
.hsaved{font:14.5px/1.45 var(--serif);color:#D9D1C6;background:none;border:0;text-align:left;padding:0}
.hsaved:hover{color:var(--accent-hi)}

/* ---------- avisos flotantes ---------- */
.toast{position:fixed;left:50%;bottom:26px;transform:translate(-50%,20px);background:var(--hi);color:#1A1917;padding:11px 18px;border-radius:10px;font-size:14px;font-weight:500;box-shadow:0 12px 30px rgba(0,0,0,.4);opacity:0;pointer-events:none;transition:.2s;z-index:50;max-width:min(560px,90vw)}
.toast.on{opacity:1;transform:translate(-50%,0)}
.offline{position:fixed;inset:0;background:rgba(10,9,8,.86);display:none;place-items:center;z-index:60;padding:24px}
.offline.on{display:grid}
.offline > div{max-width:460px;background:var(--panel);border:1px solid var(--line2);border-radius:16px;padding:28px}
.offline h2{margin:0 0 8px;font:400 26px var(--serif)}
.offline p{margin:0;color:var(--muted)}

/* ---------- pantallas más angostas ---------- */
@media (max-width:1280px){
  .home{padding:80px 48px 60px 56px;gap:40px}
  .home-side{width:300px}
  .stabs{padding-left:48px}
  .wordmark{width:auto}
  .side,.addref,.hdetail{width:340px}
}
@media (max-width:1100px){
  .home{flex-direction:column}
  .home-side{width:auto;padding-top:0;display:grid;grid-template-columns:1fr 1fr}
  .rbody{flex-direction:column;gap:22px}
  .rbody > aside{width:auto}
  .fsum{display:flex;align-items:center;gap:8px;cursor:pointer;background:var(--panel);border:1px solid var(--line);border-radius:var(--r);padding:12px 16px;font-size:14px;color:var(--soft);list-style:none}
  .fsum::-webkit-details-marker{display:none}
  .fsum::after{content:"▾";margin-left:auto;color:var(--faint)}
  .fdet[open] .fsum{margin-bottom:10px}
  .rbody > aside .filters{position:static;display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:18px 24px;background:var(--panel);border:1px solid var(--line);border-radius:var(--r-lg);padding:18px}
  .eqpage,.citpage,.histpage{flex-direction:column}
  .side,.addref,.hdetail{width:auto;height:auto;position:static;border-left:0;border-top:1px solid var(--line)}
}
@media (max-width:760px){
  .rail{inset:auto 0 0 0;width:auto;height:64px;flex-direction:row;justify-content:space-around;padding:4px 6px;border-right:0;border-top:1px solid var(--line)}
  .logo,.rail .grow{display:none}
  .ritem{width:auto;flex:1;padding:6px 0;font-size:10.5px}
  .stage{margin-left:0;padding-bottom:70px}
  .home{padding:40px 20px}
  .home h1{font-size:40px}
  .home-side{grid-template-columns:1fr}
  .rtop{flex-wrap:wrap;padding:14px 18px 6px;gap:12px}
  .stabs{padding:0 18px}
  .rbody,.eqmain,.citmain,.histmain{padding-left:18px;padding-right:18px}
  .pop .filters{grid-template-columns:1fr}
}
</style>
</head>
<body>
<div class="app">

<nav class="rail" aria-label="Secciones">
  <button class="logo" type="button" data-go="home" data-new title="Nueva búsqueda" aria-label="Nueva búsqueda">
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1A1917" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M4 5h11a4 4 0 014 4v10H8a4 4 0 01-4-4z"/><path d="M8 10h7M8 14h5"/></svg>
  </button>
  <button class="ritem" type="button" data-go="search" aria-current="page"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>Buscar</button>
  <button class="ritem" type="button" data-go="eq"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h6M14 7h6M4 17h6M14 17h6M7 7v10M17 7v10"/></svg>Ecuación</button>
  <button class="ritem" type="button" data-go="cited"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 3h12v18l-6-4-6 4z"/></svg>Citados<span class="dot" id="railCount"></span></button>
  <button class="ritem" type="button" data-go="hist"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>Historial</button>
  <div class="grow"></div>
  <a class="ritem" href="/ayuda" target="_blank" rel="noopener"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 114 2c-1 .6-1.5 1.2-1.5 2.5M12 17h.01"/></svg>Ayuda</a>
  <button class="ritem" type="button" id="quitBtn" title="Cerrar el programa"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 3v8"/><path d="M6.3 7.3a8 8 0 1011.4 0"/></svg>Cerrar</button>
</nav>

<div class="stage">

<!-- ================================ INICIO ================================ -->
<main class="view on" id="v-home" aria-label="Inicio">
  <div class="home">
    <div class="home-main">
      <p class="eyebrow">Buscador académico booleano</p>
      <h1>¿Qué quieres<br>investigar hoy?</h1>
      <form class="bigask" id="homeForm" autocomplete="off">
        <label class="sr" for="ask">Tu pregunta</label>
        <textarea id="ask" rows="2" placeholder="Escribe tu pregunta como se la harías a un bibliotecario…"></textarea>
        <div class="askbar">
          <button class="chip" type="button" data-pop="y" aria-expanded="false"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg><span id="chipYears">Años</span></button>
          <button class="chip" type="button" data-pop="s" aria-expanded="false"><span id="chipSrc">3 bases</span></button>
          <button class="chip" type="button" data-pop="f" aria-expanded="false"><span id="chipMore">Filtros</span></button>
          <button class="btn primary" type="submit">Convertir y buscar</button>
        </div>
        <div class="pop" id="homePop" hidden>
          <button class="close" type="button" aria-label="Cerrar filtros" id="popClose">×</button>
          <div class="filters" data-filters="home"></div>
        </div>
      </form>
      <div class="examples">
        <p class="eyebrow">Ejemplos</p>
        <div id="exList"></div>
      </div>
    </div>
    <aside class="home-side" aria-label="Actividad reciente">
      <section class="card">
        <div class="card-head"><h2>Citados recientes</h2><button class="linkbtn" type="button" data-go="cited" id="seeAllCited">Ver todos</button></div>
        <div id="recentCited"></div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Búsquedas recientes</h2><button class="linkbtn" type="button" data-go="hist">Historial</button></div>
        <div id="recentHist"></div>
      </section>
    </aside>
  </div>
</main>

<!-- ============================== RESULTADOS ============================== -->
<main class="view" id="v-search" aria-label="Resultados">
  <header class="rhead">
    <div class="rtop">
      <button class="wordmark" type="button" data-go="home" data-new>Académico<small>Nueva búsqueda</small></button>
      <form class="qpill" id="pillForm" autocomplete="off">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#8F877D" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
        <label class="sr" for="ask2">Tu pregunta</label>
        <input id="ask2">
        <button class="btn primary" type="submit" id="pillBtn">Buscar</button>
      </form>
      <button class="toplink" type="button" data-go="cited">Citados <span class="badge-n" id="topCount">0</span></button>
    </div>
    <div class="stabs" role="tablist" aria-label="Tipo de estudio" id="stabs"></div>
  </header>

  <div class="rbody">
    <aside aria-label="Filtros">
      <details class="fdet" id="fdet" open><summary class="fsum">Filtros, años y fuentes</summary>
        <div class="filters" data-filters="side"></div>
      </details>
    </aside>

    <div class="rmain">
      <section class="band" id="band" aria-label="Tu búsqueda">
        <div class="band-head">
          <h2 class="eyebrow">Así quedó tu búsqueda</h2>
          <div class="right"><span id="lintMini"></span><button class="linkbtn" type="button" data-go="eq">Ver y editar ecuación</button></div>
        </div>
        <div class="ccards" id="ccards"></div>
        <form class="addform" id="addForm1" hidden autocomplete="off">
          <label class="sr" for="addIn1">Nuevo concepto</label>
          <input class="field-in" id="addIn1" placeholder="Escribe el concepto en español, ej. ejercicio">
          <button class="btn primary sm" type="submit">Agregar</button>
          <button class="btn sm" type="button" data-cancel-add>Cancelar</button>
        </form>
        <div id="removedNote" class="info" hidden></div>
        <div id="qarea"></div>
        <ul class="notes" id="bandNotes"></ul>
      </section>

      <div class="countline" id="countline" hidden></div>
      <div id="errors"></div>
      <div id="advice"></div>
      <div class="results" id="results"></div>
      <button class="btn moreres" id="moreBtn" type="button" hidden>Cargar más resultados</button>
    </div>
  </div>
</main>

<!-- =============================== ECUACIÓN =============================== -->
<main class="view" id="v-eq" aria-label="Ecuación">
  <div class="emptybox" id="eqEmpty">
    <h1>Todavía no hay ecuación</h1>
    <p>Escribe tu pregunta en español y aquí verás cómo se traduce a una búsqueda con AND, OR y NOT.</p>
    <button class="btn primary" type="button" data-go="home">Escribir una pregunta</button>
  </div>
  <div class="eqpage" id="eqPage" hidden>
    <div class="eqmain">
      <div class="pagehead">
        <div class="quote" id="eqQuote"></div>
        <h1>Así quedó tu búsqueda</h1>
        <p>Cada columna es un concepto. Dentro de ella, sus sinónimos se unen con <b>OR</b> (basta con uno). Entre columnas se usa <b>AND</b>: deben aparecer todos. Lo que se excluye va con <b style="color:var(--err)">NOT</b>.</p>
      </div>
      <div class="cols" id="cols"></div>
      <form class="addform" id="addForm2" hidden autocomplete="off">
        <label class="sr" for="addIn2">Nuevo concepto</label>
        <input class="field-in" id="addIn2" placeholder="Escribe el concepto en español, ej. ejercicio">
        <button class="btn primary sm" type="submit">Agregar</button>
        <button class="btn sm" type="button" data-cancel-add>Cancelar</button>
      </form>
      <div id="removedNote2" class="info" hidden></div>

      <section class="syntax" aria-label="Sintaxis de la ecuación">
        <div class="syntabs" role="tablist">
          <button class="syntab" role="tab" type="button" data-mode="pubmed" aria-selected="true">PubMed</button>
          <button class="syntab" role="tab" type="button" data-mode="generic" aria-selected="false">Europe PMC, SciELO, BVS</button>
          <button class="syntab" role="tab" type="button" data-mode="scholar" aria-selected="false">Google Académico</button>
          <div class="right"><span id="lintState"></span><button class="btn soft sm" type="button" id="editBtn">Editar a mano</button></div>
        </div>
        <div class="eqwrap" id="eqwrap">
          <pre id="eqHi" aria-hidden="true"></pre>
          <label class="sr" for="eq">Ecuación booleana</label>
          <textarea id="eq" spellcheck="false"></textarea>
        </div>
        <div class="eqfoot">
          <div class="eqstate"><span id="eqState"></span><button class="linkbtn" type="button" id="restoreBtn" hidden>Restaurar la automática</button></div>
          <ul class="issues" id="issues"></ul>
          <ul class="notes" id="eqNotes"></ul>
        </div>
      </section>
    </div>
    <aside class="side" aria-label="Antes de buscar">
      <h2>Antes de buscar</h2>
      <div class="filters" data-filters="eq"></div>
      <div class="push"></div>
      <p class="gohint" id="goHint" aria-live="polite"></p>
      <button class="btn primary bigbtn" type="button" id="eqSearchBtn">Buscar artículos →</button>
    </aside>
  </div>
</main>

<!-- =============================== CITADOS =============================== -->
<main class="view" id="v-cited" aria-label="Citados">
  <div class="citpage">
    <div class="citmain">
      <div class="headrow">
        <div class="pagehead">
          <h1>Citados</h1>
          <p id="citedSub">Tus referencias en APA 7.ª edición, en orden alfabético. Se guardan en tu computadora.</p>
        </div>
        <div class="seg" role="group" aria-label="Idioma de la cita">
          <button type="button" data-style="es" aria-pressed="true">APA en español</button>
          <button type="button" data-style="en" aria-pressed="false">APA en inglés</button>
        </div>
      </div>
      <div class="tools">
        <div class="searchbox">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8F877D" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
          <label class="sr" for="citedFilter">Filtrar citados</label>
          <input id="citedFilter" placeholder="Filtrar por autor, título o año">
        </div>
        <button class="btn primary" type="button" id="copyAll">Copiar todas</button>
        <a class="btn" id="dlRtf" href="#" download>Descargar para Word</a>
        <a class="btn" id="dlTxt" href="#" download>Descargar texto</a>
      </div>
      <div class="typechips" role="group" aria-label="Tipo de referencia" id="typeChips"></div>
      <section class="reflist" id="refs" aria-live="polite"></section>
      <div><button class="linkbtn red" type="button" id="clearAll">Vaciar la lista</button></div>
    </div>

    <aside class="addref" aria-label="Agregar una referencia">
      <h2 id="addTitle">Agregar una referencia</h2>
      <div class="addtabs" role="tablist">
        <button type="button" role="tab" data-add="link" aria-selected="true">Enlace (página web)</button>
        <button type="button" role="tab" data-add="doi" aria-selected="false">DOI</button>
        <button type="button" role="tab" data-add="manual" aria-selected="false">Manual</button>
      </div>
      <div id="editNote" class="editing-note" hidden><span>Editando una referencia guardada.</span><button class="linkbtn" type="button" id="cancelEdit">Cancelar</button></div>

      <form class="fl" id="paneLink" autocomplete="off">
        <label for="linkIn">Pega el enlace de la página</label>
        <div class="inrow"><input class="field-in" id="linkIn" placeholder="https://www.who.int/es/…"><button class="btn primary sm" type="submit" style="height:40px">Leer</button></div>
        <span class="hint">Leo el autor, la fecha, el título y el sitio desde la página. Siempre podrás corregirlos.</span>
      </form>
      <form class="fl" id="paneDoi" hidden autocomplete="off">
        <label for="doiIn">Escribe o pega el DOI del artículo</label>
        <div class="inrow"><input class="field-in" id="doiIn" placeholder="10.1056/NEJMoa2034577"><button class="btn primary sm" type="submit" style="height:40px">Buscar</button></div>
        <span class="hint">El DOI aparece en la primera página del artículo, casi siempre empieza con «10.».</span>
      </form>
      <div class="fl" id="paneManual" hidden>
        <label for="kindSel">¿Qué quieres citar?</label>
        <select class="field-in" id="kindSel"><option value="web">Página web</option><option value="article">Artículo de revista</option></select>
      </div>
      <div class="status" id="addStatus" aria-live="polite"></div>

      <form id="refForm" hidden autocomplete="off" style="display:flex;flex-direction:column;gap:12px"></form>
      <div class="preview" id="preview" hidden>
        <p class="eyebrow">Vista previa APA 7</p>
        <p class="apa" id="prevApa"></p>
        <div class="muted" style="font-size:12.5px">En el texto: <span id="prevIn" style="color:var(--soft)"></span></div>
        <ul class="pn" id="prevNotes"></ul>
      </div>
      <button class="btn primary" type="button" id="saveRef" hidden style="height:48px">Guardar en Citados</button>
    </aside>
  </div>
</main>

<!-- =============================== HISTORIAL =============================== -->
<main class="view" id="v-hist" aria-label="Historial">
  <div class="histpage">
    <div class="histmain">
      <div class="headrow">
        <div class="pagehead">
          <h1>Historial</h1>
          <p>Tus búsquedas anteriores, con la ecuación y los filtros que usaste. Se guardan en tu computadora.</p>
        </div>
        <button class="linkbtn red" type="button" id="clearHist">Borrar historial</button>
      </div>
      <div class="searchbox">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8F877D" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
        <label class="sr" for="histFilter">Buscar en el historial</label>
        <input id="histFilter" placeholder="Buscar en el historial">
      </div>
      <div id="histList"></div>
    </div>
    <aside class="hdetail" id="hDetail" aria-label="Detalle de la búsqueda"></aside>
  </div>
</main>

</div>
</div>

<div class="toast" id="toast" role="status"></div>
<div class="offline" id="offline"><div><h2>El programa está cerrado</h2><p>Para seguir, vuelve a abrir el buscador con doble clic en su icono. Tus citas y tu historial no se pierden.</p></div></div>
<script>
"use strict";
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const SRC_NAMES = {pubmed:"PubMed", europepmc:"Europe PMC", openalex:"OpenAlex"};
const STUDY_TABS = [["any","Todos"],["sr","Revisiones sistemáticas"],["rct","Ensayos clínicos"],["guide","Guías clínicas"],["obs","Observacionales"]];
const S = {
  cfg:null, view:"home", text:"", answers:{}, tr:null, mode:"pubmed", editing:false,
  generated:{pubmed:"", generic:""}, queries:{pubmed:"", generic:""}, edited:{pubmed:false, generic:false},
  lint:{pubmed:[], generic:[]}, skip:false, searching:false, searched:false, showAnswers:false,
  results:[], seen:new Map(), page:1, epmcCursor:"*", epmcLoaded:0, totals:{}, links:[],
  cited:new Set(), style:"es", citedItems:[], typeFilter:"all", hist:[], histSel:null, histId:null,
  f:{y0:"", y1:"", src:{pubmed:true, europepmc:true, openalex:true}, langs:[], free:false, humans:false},
  addTab:"link", formKind:null, formBase:{}, editId:null, yearNote:""
};

async function api(path, body){
  try{
    const opt = body === undefined ? {} : {method:"POST", headers:{"Content-Type":"application/json","X-Buscador":"1"}, body:JSON.stringify(body)};
    const r = await fetch(path, opt);
    const data = await r.json();
    if (data && data.error) throw new Error(data.error);
    return data;
  }catch(e){
    if (e instanceof TypeError) $("#offline").classList.add("on");
    throw e;
  }
}
let toastT;
function toast(msg){ const t=$("#toast"); t.textContent=msg; t.classList.add("on"); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.remove("on"), 3200); }
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(()=>fn(...a), ms); }; };
const range = (a,b) => { const o=[]; for(let y=a;y>=b;y--) o.push(y); return o; };
const cleanTerm = t => t.replace(/\[[^\]]*\]/g,"").replace(/"/g,"").trim();
const INFO_ICON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>`;

/* ================================================================ navegación */
function go(v){
  if (v === "search" && !S.tr) v = "home";
  S.view = v;
  $$(".view").forEach(el => el.classList.toggle("on", el.id === "v-"+v));
  $$(".rail [data-go]").forEach(b => {
    const on = b.dataset.go === v || (b.dataset.go === "search" && v === "home");
    if (b.classList.contains("ritem")) on ? b.setAttribute("aria-current","page") : b.removeAttribute("aria-current");
  });
  closePop();
  if (v === "home") renderHome();
  if (v === "eq") renderEqView();
  if (v === "cited") renderCited();
  if (v === "hist") renderHist();
  if (v === "search") $("#ask2").value = S.text;
  window.scrollTo(0,0);
}
document.addEventListener("click", e => {
  const b = e.target.closest("[data-go]");
  if (b){ e.preventDefault(); if (b.hasAttribute("data-new")){ $("#ask").value = ""; } go(b.dataset.go); if (b.hasAttribute("data-new")) $("#ask").focus(); }
});

/* ================================================================ filtros */
function filtersHtml(scope){
  const Y = S.cfg.year;
  const y0 = `<option value="">Sin límite</option>` + range(Y,1950).map(y=>`<option>${y}</option>`).join("");
  const y1 = `<option value="">Actual</option>` + range(Y-1,1950).map(y=>`<option>${y}</option>`).join("");
  const id = k => `f-${scope}-${k}`;
  return `
  <div class="fgroup" data-part="y"><h3>Años</h3>
    <div class="yrs"><label class="sr" for="${id("y0")}">Desde</label><select class="field-in" id="${id("y0")}" data-f="y0">${y0}</select><span>–</span>
    <label class="sr" for="${id("y1")}">Hasta</label><select class="field-in" id="${id("y1")}" data-f="y1">${y1}</select></div></div>
  <div class="fgroup" data-part="s"><h3>Fuentes</h3>
    ${Object.entries(SRC_NAMES).map(([k,n])=>`<label class="check"><input type="checkbox" data-f="src.${k}"> ${n}<span class="n" data-n="${n}"></span></label>`).join("")}</div>
  <div class="fgroup" data-part="f"><h3>Idioma</h3>
    <label class="check"><input type="checkbox" data-f="lang.es"> Español</label>
    <label class="check"><input type="checkbox" data-f="lang.en"> Inglés</label>
    <label class="check"><input type="checkbox" data-f="lang.pt"> Portugués</label></div>
  <div class="fgroup" data-part="f"><h3>Opciones</h3>
    <label class="check"><input type="checkbox" data-f="free"> Solo texto completo gratis</label>
    <label class="check"><input type="checkbox" data-f="humans"> Solo estudios en humanos</label></div>
  ${scope === "side" ? `<div class="fgroup"><h3>Buscar también en</h3><div class="alsoin" id="alsoIn"><span class="muted" style="font-size:13px">Aparecen al buscar.</span></div></div>` : ""}`;
}
function syncFilters(){
  $$("[data-f]").forEach(el => {
    const k = el.dataset.f;
    if (k === "y0" || k === "y1") el.value = S.f[k];
    else if (k.startsWith("src.")) el.checked = S.f.src[k.slice(4)];
    else if (k.startsWith("lang.")) el.checked = S.f.langs.includes(k.slice(5));
    else el.checked = !!S.f[k];
  });
  const y0 = S.f.y0 || "Sin límite", y1 = S.f.y1 || "Actual";
  $("#chipYears").textContent = `${y0} – ${y1}`;
  const n = Object.values(S.f.src).filter(Boolean).length;
  $("#chipSrc").textContent = n === 3 ? "3 bases" : n === 1 ? "1 base" : `${n} bases`;
  const extra = S.f.langs.length + (S.f.free?1:0) + (S.f.humans?1:0);
  $("#chipMore").textContent = extra ? `Filtros · ${extra}` : "Filtros";
  $$(".freechip input").forEach(c => c.checked = S.f.free);
}
document.addEventListener("change", e => {
  const el = e.target.closest("[data-f]");
  if (!el) return;
  const k = el.dataset.f;
  if (k === "y0" || k === "y1") S.f[k] = el.value;
  else if (k.startsWith("src.")) S.f.src[k.slice(4)] = el.checked;
  else if (k.startsWith("lang.")){ const l = k.slice(5); S.f.langs = el.checked ? [...new Set([...S.f.langs, l])] : S.f.langs.filter(x=>x!==l); }
  else S.f[k] = el.checked;
  syncFilters(); updateGo();
  if (k === "humans"){ if (S.tr) doTranslate(false).then(autoSearch); return; }
  if (S.view === "search" && S.searched) reSearch();
});
const reSearch = debounce(() => { if (readyMsg() === "") doSearch(1); }, 450);
function years(){
  const a = S.f.y0 ? +S.f.y0 : null, b = S.f.y1 ? +S.f.y1 : null;
  return {y0:a, y1:b, err: a && b && a > b ? "El año «desde» no puede ser posterior al año «hasta»." : ""};
}
function sources(){ return Object.entries(S.f.src).filter(([,v])=>v).map(([k])=>k); }

/* popover de filtros en el inicio */
$$("[data-pop]").forEach(b => b.onclick = () => {
  const pop = $("#homePop"), open = !pop.hidden && pop.dataset.part === b.dataset.pop;
  closePop();
  if (open) return;
  pop.hidden = false; pop.dataset.part = b.dataset.pop;
  b.setAttribute("aria-expanded","true");
  const first = pop.querySelector(`[data-part="${b.dataset.pop}"] select, [data-part="${b.dataset.pop}"] input`);
  if (first) first.focus();
});
function closePop(){ $("#homePop").hidden = true; $$("[data-pop]").forEach(b=>b.setAttribute("aria-expanded","false")); }
$("#popClose").onclick = closePop;
document.addEventListener("keydown", e => { if (e.key === "Escape") closePop(); });
document.addEventListener("mousedown", e => { if (!$("#homePop").hidden && !e.target.closest("#homePop") && !e.target.closest("[data-pop]")) closePop(); });

/* ================================================================ inicio */
async function init(){
  S.cfg = await api("/api/config");
  S.f.y0 = String(S.cfg.year - 10);
  $$("[data-filters]").forEach(el => el.innerHTML = filtersHtml(el.dataset.filters));
  syncFilters();
  $("#exList").innerHTML = S.cfg.examples.map(e=>`<button type="button">${esc(e)}</button>`).join("");
  $$("#exList button").forEach(b=>b.onclick=()=>{ $("#ask").value=b.textContent; startTranslate(b.textContent); });
  $("#stabs").innerHTML = STUDY_TABS.map(([v,l])=>`<button class="stab" role="tab" type="button" data-study="${v}" aria-selected="false">${l}</button>`).join("")
    + `<label class="freechip"><input type="checkbox" data-f="free"> Solo texto gratis</label>`;
  $$("[data-study]").forEach(b => b.onclick = () => pickStudy(b.dataset.study));
  syncFilters();
  if (matchMedia("(max-width:1100px)").matches) $("#fdet").open = false;
  await refreshCited();
  await refreshHist();
  renderHome();
  $("#ask").focus();
  setInterval(()=>api("/api/ping",{}).catch(()=>{}), 20000);
}
function renderHome(){
  const rc = [...S.citedItems].sort((a,b)=>(b.saved||0)-(a.saved||0)).slice(0,3);
  const cut = (t,n) => t.length > n ? t.slice(0,n).replace(/\s+\S*$/,"") + "…" : t;
  $("#recentCited").innerHTML = rc.length ? rc.map(c=>`<div class="recent-ref"><span class="who">${esc(c.intext.replace(/^\(|\)$/g,""))}</span>${esc(cut(c.meta.title||"",95))}</div>`).join("")
    : `<p class="empty-small">Aquí verás las referencias que guardes. Cada artículo trae su cita APA lista para copiar.</p>`;
  $("#seeAllCited").textContent = S.citedItems.length ? `Ver ${S.citedItems.length === 1 ? "la cita" : "las " + S.citedItems.length}` : "Abrir";
  const seenQ = new Set(), rh = S.hist.filter(h => !seenQ.has(h.text) && seenQ.add(h.text)).slice(0,4);
  $("#recentHist").innerHTML = rh.length ? rh.map((h,i)=>`<button class="recent-q" type="button" data-rh="${i}">${esc(h.text)}<small>${esc(whenLabel(h.at))}</small></button>`).join("")
    : `<p class="empty-small">Tus búsquedas se guardarán aquí para repetirlas con un clic.</p>`;
  $$("[data-rh]").forEach(b=>b.onclick=()=>repeatHist(rh[+b.dataset.rh], true));
}
$("#homeForm").onsubmit = e => { e.preventDefault(); startTranslate($("#ask").value); };
$("#ask").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey){ e.preventDefault(); startTranslate($("#ask").value); }});
$("#pillForm").onsubmit = e => {
  e.preventDefault();
  const t = $("#ask2").value.trim();
  if (t && t !== S.text) startTranslate(t);
  else if (readyMsg() === "") doSearch(1);
  else { toast(readyMsg()); }
};

/* ================================================================ traducción y preguntas */
async function startTranslate(text, keep){
  text = (text||"").trim();
  if (!text){ toast("Primero escribe tu pregunta en el recuadro."); $("#ask").focus(); return; }
  S.text = text; S.skip = false; S.showAnswers = false; S.searched = false; S.histId = null;
  if (!keep) S.answers = {};
  $("#ask").value = text; $("#ask2").value = text;
  clearResults();
  await doTranslate(true);
  go("search");
  autoSearch();
}
async function doTranslate(first){
  if (!S.text) return;
  const tr = await api("/api/translate", {text:S.text, answers:S.answers, humans:S.f.humans});
  S.tr = tr;
  S.generated = {pubmed:tr.query_pubmed, generic:tr.query_generic};
  S.queries = {...S.generated};
  S.edited = {pubmed:false, generic:false};
  S.editing = false;
  if (first){
    S.yearNote = "";
    if (tr.years.from || tr.years.to){
      S.f.y0 = tr.years.from ? String(tr.years.from) : "";
      S.f.y1 = tr.years.to && tr.years.to < S.cfg.year ? String(tr.years.to) : "";
      const f = tr.years.from, t = tr.years.to;
      const rango = f && t ? (t >= S.cfg.year ? `desde ${f} hasta hoy` : `de ${f} a ${t}`) : f ? `desde ${f} hasta hoy` : `hasta ${t}`;
      S.yearNote = `Detecté un periodo en tu pregunta (${rango}) y ajusté los años.`;
      syncFilters();
    }
  }
  renderBand(); renderTabs();
  if (S.view === "eq") renderEqView();
  lintBoth();
  updateGo();
}
function autoSearch(){ if (S.view === "search" && readyMsg() === "") doSearch(1); }
function answer(qid, value){ S.answers[qid] = value; doTranslate(false).then(autoSearch); }

function activeStudy(){
  if (S.answers.study_type !== undefined) return S.answers.study_type;
  const keys = (S.tr ? S.tr.rows.flat() : []).filter(c=>c.category==="study_type").map(c=>c.key);
  if (keys.some(k=>/systematic_review|meta_analysis/.test(k))) return "sr";
  if (keys.some(k=>/rct/.test(k))) return "rct";
  if (keys.some(k=>/guideline/.test(k))) return "guide";
  if (keys.some(k=>/cohort|case_control|cross_sectional/.test(k))) return "obs";
  return keys.length ? "" : "any";
}
function renderTabs(){
  const a = activeStudy();
  $$("[data-study]").forEach(b => b.setAttribute("aria-selected", b.dataset.study === a));
}
function pickStudy(v){
  if (!S.tr) return;
  const fromText = S.tr.rows.flat().filter(c=>c.category==="study_type" && c.source !== "answer").map(c=>c.key);
  S.answers.removed = [...new Set([...(S.answers.removed||[]), ...fromText])];
  S.answers.study_type = v;
  doTranslate(false).then(autoSearch);
}

function conceptCard(row, neg){
  const cat = neg ? "not" : row[0].category;
  const catLabel = neg ? "Se excluye" : row[0].category_label;
  const labels = row.map(c => `${esc(c.label)}<button type="button" class="xbtn" data-rm="${esc(c.key)}" title="Quitar este concepto" aria-label="Quitar ${esc(c.label)}">×</button>`).join(`<span class="or">o</span>`);
  const syn = [...new Set(row.flatMap(c=>c.terms).map(cleanTerm))];
  const synTxt = syn.slice(0,3).join(" · ") + (syn.length > 3 ? ` · +${syn.length-3}` : "");
  return `<div class="ccard k-${cat}"><div class="cat">${esc(catLabel)}</div><div class="lbl">${labels}</div><div class="syn" title="${esc(syn.join(", "))}">${esc(synTxt)}</div></div>`;
}
function renderBand(){
  const tr = S.tr;
  let h = tr.rows.map(r=>conceptCard(r,false)).join(`<div class="joiner">Y</div>`);
  if (tr.excluded.length) h += `<div class="joiner not">SIN</div>` + conceptCard(tr.excluded, true);
  if (S.f.humans) h += `<div class="joiner not">SIN</div><div class="ccard k-not"><div class="cat">Filtro</div><div class="lbl">Estudios solo en animales</div><div class="syn">Animals NOT Humans</div></div>`;
  if (!tr.rows.length) h = `<div class="info">${INFO_ICON}<span>Todavía no reconozco ningún concepto. Responde la pregunta de abajo o escribe tu pregunta con otras palabras.</span></div>`;
  $("#ccards").innerHTML = h + `<button class="addc" type="button" data-add-concept="1">+ Concepto</button>`;
  bindConceptButtons();
  renderRemoved("#removedNote");
  renderQuestions();
  const notes = [...(S.yearNote ? [S.yearNote] : []), ...tr.notes];
  let nh = notes.map(n=>`<li class="info">${INFO_ICON}<span>${esc(n)}</span></li>`).join("");
  if (tr.doi) nh += `<li class="info">${INFO_ICON}<span>Esto parece un DOI (${esc(tr.doi)}). <button class="linkbtn" type="button" id="doiQuick">Agregarlo a Citados</button></span></li>`;
  $("#bandNotes").innerHTML = nh;
  if (tr.doi) $("#doiQuick").onclick = () => { go("cited"); setAddTab("doi"); $("#doiIn").value = tr.doi; lookupDoi(); };
}
function bindConceptButtons(){
  $$("[data-rm]").forEach(x=>x.onclick=()=>{
    S.answers.removed = [...(S.answers.removed||[]), x.dataset.rm];
    doTranslate(false).then(autoSearch);
  });
  $$("[data-add-concept]").forEach(b=>b.onclick=()=>{
    const f = S.view === "eq" ? $("#addForm2") : $("#addForm1");
    f.hidden = false; f.querySelector("input").focus();
  });
}
function renderRemoved(sel){
  const rm = $(sel), tr = S.tr;
  if (tr.removed.length){
    rm.innerHTML = `${INFO_ICON}<span>Quitaste: ${tr.removed.map(r=>esc(r.label)).join(", ")}. <button type="button" class="linkbtn" data-undo>Volver a ponerlos</button></span>`;
    rm.hidden = false;
    rm.querySelector("[data-undo]").onclick = () => { S.answers.removed = []; delete S.answers.study_type; doTranslate(false).then(autoSearch); };
  } else rm.hidden = true;
}
$$(".addform").forEach(f => {
  f.onsubmit = e => {
    e.preventDefault();
    const v = f.querySelector("input").value.trim();
    if (!v) return;
    f.querySelector("input").value = ""; f.hidden = true;
    S.text = `${S.text} y ${v}`; $("#ask").value = S.text; $("#ask2").value = S.text;
    doTranslate(false).then(autoSearch);
    toast(`Agregué «${v}» a tu búsqueda.`);
  };
  f.querySelector("[data-cancel-add]").onclick = () => { f.hidden = true; };
});

function optLabel(q){
  if (q.type !== "single") return q.value || "(omitido)";
  const o = q.options.find(o=>o.value===q.value);
  return o ? o.label : q.value;
}
function questionHtml(q, i){
  if (q.type === "single"){
    return `<div class="opts" role="group" aria-label="${esc(q.text)}">` + q.options.map(o=>
      `<button type="button" class="pill" data-q="${esc(q.id)}" data-v="${esc(o.value)}" aria-pressed="${q.answered && q.value===o.value}">${esc(o.label)}</button>`).join("") + `</div>`;
  }
  const val = q.value && !String(q.value).startsWith("concept:") ? q.value : (q.suggestion || "");
  const dym = q.did_you_mean ? `<button type="button" class="btn primary sm" data-dym="${esc(q.id)}" data-v="${esc(q.did_you_mean.value)}">Sí, «${esc(q.did_you_mean.label)}»</button>` : "";
  let h = `<div class="textq">${dym}<input class="field-in" id="tq${i}" value="${esc(val)}" placeholder="${esc(q.placeholder||"término en inglés")}" aria-label="${esc(q.text)}">
    <button type="button" class="btn sm" data-tq="${esc(q.id)}" data-in="tq${i}">${q.did_you_mean?"No, usar este":"Usar este término"}</button>
    ${q.id.startsWith("term:")?`<button type="button" class="btn sm" data-skip="${esc(q.id)}">Omitir</button>`:""}</div>`;
  if (q.did_you_mean && !q.answered) h += `<div class="qsub">Mientras no respondas, busco «${esc(q.did_you_mean.label)}».</div>`;
  else if (q.suggestion && !q.answered) h += `<div class="qsub">Traducción sugerida: «${esc(q.suggestion)}». Corrígela si no es el término correcto en inglés.</div>`;
  return h;
}
function renderQuestions(){
  const qs = S.tr.questions, pending = qs.filter(q=>!q.answered), answered = qs.filter(q=>q.answered);
  const box = $("#qarea");
  if (pending.length && !S.skip){
    const q = pending[0], i = qs.indexOf(q);
    box.innerHTML = `<div class="qband"><div class="qtop"><span class="qt"><b>${pending.length === 1 ? "Falta un dato" : `Faltan ${pending.length} datos`}:</b> ${esc(q.text)}</span>
      <button class="btn sm" type="button" id="skipBtn">Buscar sin responder</button></div>${questionHtml(q, i)}</div>`;
    $("#skipBtn").onclick = () => { S.skip = true; renderQuestions(); updateGo(); doSearch(1); };
  } else if (answered.length || (pending.length && S.skip)){
    const summary = answered.map(q=>`<span class="ans">${esc(optLabel(q))}</span>`).join(" · ");
    box.innerHTML = `<div class="qdone">${answered.length ? `Tus respuestas: ${summary}` : "Buscaste sin responder las preguntas."}
      <button class="linkbtn" type="button" id="toggleAns">${S.showAnswers ? "Ocultar" : pending.length ? "Responder ahora" : "Cambiar respuestas"}</button></div>`
      + (S.showAnswers ? `<div class="qlist">${qs.map((q,i)=>`<div class="qitem"><span>${esc(q.text)}</span>${questionHtml(q,i)}</div>`).join("")}</div>` : "");
    $("#toggleAns").onclick = () => { S.showAnswers = !S.showAnswers; renderQuestions(); };
  } else box.innerHTML = "";
  $$("#qarea [data-q]").forEach(b=>b.onclick=()=>answer(b.dataset.q, b.dataset.v));
  $$("#qarea [data-dym]").forEach(b=>b.onclick=()=>answer(b.dataset.dym, b.dataset.v));
  $$("#qarea [data-tq]").forEach(b=>b.onclick=()=>answer(b.dataset.tq, $("#"+b.dataset.in).value.trim()));
  $$("#qarea [data-skip]").forEach(b=>b.onclick=()=>answer(b.dataset.skip, ""));
  $$("#qarea .textq input").forEach(inp=>inp.onkeydown=e=>{ if(e.key==="Enter"){ e.preventDefault(); inp.parentElement.querySelector("[data-tq]").click(); }});
}
</script>
<script>
/* ================================================================ ecuación */
function renderEqView(){
  const has = !!S.tr;
  $("#eqEmpty").hidden = has; $("#eqPage").hidden = !has;
  if (!has) return;
  const tr = S.tr;
  $("#eqQuote").textContent = `«${S.text}»`;
  const col = (row, neg) => {
    const cat = neg ? "not" : row[0].category;
    const heads = row.map(c=>`<div class="head">${esc(c.label)}<button type="button" class="xbtn" data-rm="${esc(c.key)}" aria-label="Quitar ${esc(c.label)}">×</button></div>`).join(`<div class="orhead">OR</div>`);
    const terms = [...new Set(row.flatMap(c=>c.terms).map(cleanTerm))];
    return `<div class="col k-${cat}"><div class="cat">${neg ? "NOT · se excluye" : esc(row[0].category_label)}</div><div class="heads">${heads}</div>
      <div class="terms">${terms.map(esc).join(" <b>OR</b> ")}</div></div>`;
  };
  let h = tr.rows.map(r=>col(r,false)).join(`<div class="colsep">AND</div>`);
  if (tr.excluded.length) h += `<div class="colsep not">NOT</div>` + col(tr.excluded, true);
  if (S.f.humans) h += `<div class="colsep not">NOT</div><div class="col k-not"><div class="cat">NOT · filtro</div><div class="heads"><div class="head">Estudios solo en animales</div></div><div class="terms">Animals [MeSH] <b>NOT</b> Humans [MeSH]</div></div>`;
  if (!tr.rows.length) h = `<div class="placeholder">Todavía no reconozco ningún concepto. Ve a <b>Buscar</b> y responde la pregunta pendiente, o agrega un concepto.</div>`;
  $("#cols").innerHTML = h + `<button class="addcol" type="button" data-add-concept="1">+ Agregar concepto</button>`;
  bindConceptButtons();
  renderRemoved("#removedNote2");
  $("#eqNotes").innerHTML = tr.notes.map(n=>`<li class="info">${INFO_ICON}<span>${esc(n)}</span></li>`).join("");
  renderEquation(); renderIssues(); updateGo();
}
$$(".syntab").forEach(t => t.onclick = () => setMode(t.dataset.mode));
function setMode(m){
  S.mode = m;
  $$(".syntab").forEach(t => t.setAttribute("aria-selected", t.dataset.mode === m));
  if (m === "scholar") setEditing(false);
  $("#editBtn").hidden = m === "scholar";
  renderEquation(); renderIssues();
}
function currentQuery(){ return S.mode === "scholar" ? (S.tr ? S.tr.query_scholar : "") : S.queries[S.mode]; }
function renderEquation(){
  const ta = $("#eq");
  if (!(S.editing && document.activeElement === ta)) ta.value = currentQuery();
  syncHighlight(); updateEqState();
}
function highlight(t){
  return esc(t)
    .replace(/(&quot;.*?&quot;)/g, '<span class="tk-q">$1</span>')
    .replace(/(\[[^\]]*\])/g, '<span class="tk-tag">$1</span>')
    .replace(/\b(AND|OR)\b/g, '<span class="tk-op">$1</span>')
    .replace(/\bNOT\b/g, '<span class="tk-not">NOT</span>')
    .replace(/(^|\s)-(?=\S)/g, '$1<span class="tk-not">-</span>')
    .replace(/\*/g, '<span class="tk-trunc">*</span>') + "\n";
}
function syncHighlight(){
  const ta = $("#eq");
  $("#eqHi").innerHTML = highlight(S.editing ? ta.value : currentQuery());
  if (S.editing){ ta.style.height = "auto"; ta.style.height = Math.max(160, ta.scrollHeight + 4) + "px"; }
}
function setEditing(on){
  S.editing = on;
  $("#eqwrap").classList.toggle("editing", on);
  $("#editBtn").textContent = on ? "Listo" : "Editar a mano";
  if (on){ const ta = $("#eq"); ta.value = currentQuery(); syncHighlight(); ta.focus(); }
}
$("#editBtn").onclick = () => setEditing(!S.editing);
const lintLater = debounce(m => lintOne(m), 350);
$("#eq").addEventListener("input", () => {
  if (S.mode === "scholar") return;
  S.queries[S.mode] = $("#eq").value;
  S.edited[S.mode] = S.queries[S.mode] !== S.generated[S.mode];
  syncHighlight(); updateEqState(); updateGo();
  lintLater(S.mode);
});
function updateEqState(){
  const ed = S.mode !== "scholar" && S.edited[S.mode];
  $("#eqState").textContent = S.mode === "scholar" ? "Versión corta para Google Académico y ScienceDirect (no admiten * ni ecuaciones largas)."
    : ed ? "Editada a mano. Si respondes otra pregunta o quitas un concepto, se vuelve a generar." : "Generada automáticamente a partir de tu pregunta.";
  $("#eqState").style.color = ed ? "var(--warn-ink)" : "";
  $("#restoreBtn").hidden = !ed;
}
$("#restoreBtn").onclick = () => { S.queries[S.mode] = S.generated[S.mode]; S.edited[S.mode] = false; $("#eq").value = S.queries[S.mode]; renderEquation(); lintOne(S.mode); updateGo(); };
async function lintOne(mode){
  try{
    const res = await api("/api/lint", {query:S.queries[mode], mode});
    S.lint[mode] = res.issues; S.lint[mode+"Fix"] = res.fixed;
  }catch{ return; }
  renderIssues(); renderLintMini(); updateGo();
}
function lintBoth(){ lintOne("pubmed"); lintOne("generic"); }
function renderLintMini(){
  const bad = ["pubmed","generic"].some(m => (S.lint[m]||[]).some(i=>i.level==="error"));
  const warn = ["pubmed","generic"].some(m => (S.lint[m]||[]).length);
  const el = $("#lintMini");
  el.className = bad ? "lint-bad" : "lint-ok";
  el.textContent = bad ? "La ecuación tiene un error" : warn ? "Sintaxis con avisos" : "✓ Sintaxis correcta";
  $("#lintState").className = el.className; $("#lintState").textContent = el.textContent;
}
function renderIssues(){
  const ul = $("#issues");
  if (S.mode === "scholar"){ ul.innerHTML = ""; return; }
  const list = S.lint[S.mode] || [], fix = S.lint[S.mode+"Fix"];
  if (!list.length){ ul.innerHTML = S.edited[S.mode] ? `<li class="ok">La sintaxis se ve correcta.</li>` : ""; return; }
  ul.innerHTML = list.map(i=>`<li class="${i.level}">${esc(i.msg)}</li>`).join("") +
    (fix ? `<li class="ok"><button type="button" class="btn sm" id="autofix">Corregir automáticamente</button></li>` : "");
  if (fix) $("#autofix").onclick = () => { S.queries[S.mode] = fix; S.edited[S.mode] = fix !== S.generated[S.mode]; $("#eq").value = fix; renderEquation(); lintOne(S.mode); updateGo(); };
}
$("#eqSearchBtn").onclick = () => { const m = readyMsg(); if (m){ toast(m); return; } go("search"); doSearch(1); };

/* ================================================================ búsqueda */
function readyMsg(){
  if (!S.tr) return "Primero escribe tu pregunta.";
  const errs = sources().includes("pubmed") && (S.lint.pubmed||[]).some(i=>i.level==="error") ? "PubMed"
             : (S.lint.generic||[]).some(i=>i.level==="error") && sources().some(s=>s!=="pubmed") ? "otras bases" : "";
  return years().err
    || (!sources().length ? "Marca al menos una base de datos." : "")
    || (S.tr.needs_clarification && !S.skip ? "Responde la pregunta pendiente o pulsa «Buscar sin responder»." : "")
    || (!S.queries.pubmed.trim() && !S.queries.generic.trim() ? "La ecuación está vacía. Responde la pregunta o escribe otra pregunta." : "")
    || (errs ? `La ecuación para ${errs} tiene un error: revisa los avisos en rojo de la sección «Ecuación».` : "");
}
function updateGo(){
  const m = readyMsg();
  $("#goHint").textContent = S.tr ? m : "";
  $("#eqSearchBtn").disabled = !!m || S.searching;
  $("#pillBtn").disabled = S.searching;
  if (S.view === "search" && S.tr && !S.searched && !S.searching) showPlaceholder();
}
function showPlaceholder(){
  const m = readyMsg();
  $("#results").innerHTML = `<div class="placeholder">${m ? `<b>La búsqueda está en pausa.</b> ${esc(m)}` : `<b>Todo listo.</b> Pulsa «Buscar» para ver los artículos.`}</div>`;
}
$("#moreBtn").onclick = () => doSearch(S.page + 1);
function clearResults(){
  S.results = []; S.seen = new Map(); S.totals = {}; S.page = 1; S.epmcCursor = "*"; S.epmcLoaded = 0; S.links = [];
  $("#countline").hidden = true; $("#errors").innerHTML = ""; $("#advice").innerHTML = ""; $("#results").innerHTML = "";
  $("#moreBtn").hidden = true; $$("[data-n]").forEach(n=>n.textContent="");
  const al = $("#alsoIn"); if (al) al.innerHTML = `<span class="muted" style="font-size:13px">Aparecen al buscar.</span>`;
}
async function doSearch(page){
  if (S.searching) return;
  const msg = readyMsg();
  if (msg){ toast(msg); return; }
  const {y0, y1} = years();
  let srcs = sources();
  if (page === 1){
    clearResults();
    $("#results").innerHTML = `<div class="loading"><span class="spin"></span>Buscando en ${srcs.map(s=>SRC_NAMES[s]).join(", ")}…</div>`;
  } else {
    if ((page-1)*20 >= (S.totals["PubMed"]||0)) srcs = srcs.filter(s=>s!=="pubmed");
    if (!S.epmcCursor || S.epmcLoaded >= (S.totals["Europe PMC"]||0)) srcs = srcs.filter(s=>s!=="europepmc");
    if ((page-1)*20 >= (S.totals["OpenAlex"]||0)) srcs = srcs.filter(s=>s!=="openalex");
  }
  S.searching = true; updateGo();
  $("#pillBtn").textContent = "Buscando…"; $("#moreBtn").disabled = true;
  const body = {
    q_pubmed:S.queries.pubmed, q_generic:S.queries.generic, q_plain: S.edited.generic ? null : S.tr.query_plain,
    y0, y1, sources:srcs, page, epmc_cursor:S.epmcCursor, langs:S.f.langs, free_only:S.f.free,
    links_queries:{pubmed:S.queries.pubmed, generic:S.queries.generic, simple:S.tr.query_simple, scholar:S.tr.query_scholar}
  };
  try{
    const res = await api("/api/search", body);
    S.searched = true;
    showResults(res, page);
    if (page === 1) saveHistory(res);
  }catch(e){
    $("#results").innerHTML = ""; $("#errors").innerHTML = `<div class="errors">${esc(e.message||"No se pudo completar la búsqueda.")}</div>`;
  }finally{
    S.searching = false; $("#pillBtn").textContent = "Buscar"; $("#moreBtn").disabled = false; updateGo();
  }
}
async function saveHistory(res){
  const concepts = [...S.tr.rows.flat().map(c=>({label:c.label, category:c.category})),
                    ...S.tr.excluded.map(c=>({label:"Sin: "+c.label, category:"not"}))];
  try{
    const r = await api("/api/history/add", {entry:{
      text:S.text, answers:S.answers, humans:S.f.humans, y0:S.f.y0, y1:S.f.y1, sources:sources(), langs:S.f.langs,
      free_only:S.f.free, concepts, totals:res.totals, query_pubmed:S.queries.pubmed, query_generic:S.queries.generic, edited:S.edited}});
    S.histId = r.id;
    refreshHist();
  }catch{}
}
const recKey = r => r.doi ? "doi:"+r.doi.toLowerCase() : r.pmid ? "pmid:"+r.pmid : "t:"+(r.title||"").toLowerCase().replace(/[^a-z0-9]/g,"").slice(0,80);
function showResults(res, page){
  S.page = page;
  if (page === 1){ $("#results").innerHTML = ""; Object.assign(S.totals, res.totals); window.scrollTo({top:0}); }
  if ("Europe PMC" in res.totals){ S.epmcCursor = res.epmc_cursor; S.epmcLoaded += res.results.filter(r=>r.source==="Europe PMC").length; }
  const box = $("#results");
  for (const r of res.results){
    const tkey = "t:"+(r.title||"").toLowerCase().replace(/[^a-z0-9]/g,"").slice(0,80);
    const keys = [recKey(r), tkey].filter(k=>k.length > 8);
    const dup = keys.map(k=>S.seen.get(k)).find(Boolean);
    if (dup){ addSource(dup, r); continue; }
    const card = resultCard(r);
    keys.forEach(k=>S.seen.set(k, {card, rec:r}));
    S.results.push(r);
    box.appendChild(card);
  }
  for (const [n,t] of Object.entries(S.totals)) $$(`[data-n="${n}"]`).forEach(x=>x.textContent = t.toLocaleString("es-MX"));
  const total = Object.values(S.totals).reduce((a,b)=>a+b,0), nb = Object.keys(S.totals).length;
  const cl = $("#countline");
  cl.innerHTML = `<span>${total ? `${total.toLocaleString("es-MX")} resultados en ${nb === 1 ? "1 base" : nb+" bases"} · mostrando ${S.results.length}, los más relevantes primero` : ""}</span><span>Sin duplicados entre bases</span>`;
  cl.hidden = !total;
  const errs = Object.entries(res.errors).map(([k,v])=>k==="general"?v:`${k}: ${v}`);
  $("#errors").innerHTML = errs.length ? `<div class="errors">${errs.map(esc).join("<br>")}</div>` : "";
  if (page === 1){
    const max = Math.max(0, ...Object.values(S.totals));
    $("#advice").innerHTML = max === 0 && !errs.length
      ? `<div class="advice"><b>No hubo resultados.</b> Amplía el rango de años, quita un concepto con × o elige «Todos» en las pestañas de arriba.</div>`
      : max > 3000 ? `<div class="advice"><b>Hay muchos resultados.</b> Para enfocarlos, elige un tipo de estudio en las pestañas de arriba, agrega una población o acorta el rango de años.</div>` : "";
    S.links = res.links || [];
    const al = $("#alsoIn");
    if (al) al.innerHTML = S.links.map(l=>`<a href="${esc(l.url)}" target="_blank" rel="noopener" title="${esc(l.hint)}">${esc(l.name)}</a>`).join("");
  }
  const more = ((S.page*20 < (S.totals["PubMed"]||0)) && "PubMed" in S.totals) || (S.epmcCursor && S.epmcLoaded < (S.totals["Europe PMC"]||0)) || ((S.page*20 < (S.totals["OpenAlex"]||0)) && "OpenAlex" in S.totals);
  $("#moreBtn").hidden = !more;
}
function addSource(dup, r){
  const s = dup.card.querySelector(".srcnames");
  if (!s.textContent.includes(r.source)) s.textContent += ` · ${r.source}`;
  const rec = dup.rec;
  if (!rec.abstract && r.abstract){ rec.abstract = r.abstract; fillAbstract(dup.card, rec); }
  if (!rec.free_url && r.free_url){
    rec.free_url = r.free_url;
    dup.card.querySelector(".acts").insertAdjacentHTML("beforeend", `<a href="${esc(r.free_url)}" target="_blank" rel="noopener">Leer gratis</a>`);
    dup.card.querySelector(".src").insertAdjacentHTML("beforeend", `<span class="tag free">Texto gratis</span>`);
  }
  for (const k of ["doi","volume","issue","pages"]) if (!rec[k] && r[k]) rec[k] = r[k];
}
function authorsShort(a){
  if (!a || !a.length) return "Sin autores registrados";
  const n = a.map(x=>x.family + (x.initials && !x.collective ? " " + x.initials.replace(/[.\s]/g,"") : ""));
  return n.length > 4 ? `${n.slice(0,3).join(", ")} y otros` : n.join(", ");
}
function titleCase(s){ return (s||"").replace(/\b([a-záéíóúñ])([a-záéíóúñ]{3,})/g, (m,a,b)=>a.toUpperCase()+b); }
function resultCard(r){
  const el = document.createElement("article");
  el.className = "res";
  const types = (r.pub_types||[]).filter(t=>t && !/journal article|journal-article|^article$/i.test(t)).slice(0,2);
  el.innerHTML = `
    <div class="src"><span class="srcnames">${esc(r.source)}</span>${r.journal?`<span>·</span><i>${esc(titleCase(r.journal))}</i>`:""}${r.year?`<span>·</span><span>${esc(r.year)}</span>`:""}
      ${types.map(t=>`<span class="tag">${esc(t)}</span>`).join("")}${r.free_url?`<span class="tag free">Texto gratis</span>`:""}</div>
    <h3><a href="${esc(r.url)}" target="_blank" rel="noopener">${esc(r.title||"Sin título")}</a></h3>
    <div class="who">${esc(authorsShort(r.authors))}</div>
    <div class="absbox"></div>
    <div class="acts">
      <button type="button" class="btn sm save"></button>
      <button type="button" class="linkbtn copyapa">Copiar cita APA</button>
      <a href="${esc(r.url)}" target="_blank" rel="noopener">Abrir artículo</a>
      ${r.free_url?`<a href="${esc(r.free_url)}" target="_blank" rel="noopener">Leer gratis</a>`:""}
    </div>`;
  fillAbstract(el, r);
  const btn = el.querySelector(".save");
  paintSave(btn, S.cited.has(r.rid || recKey(r)));
  btn.onclick = () => toggleSave(r, btn);
  el.querySelector(".copyapa").onclick = async () => {
    try{ const p = await api("/api/apa/preview", {record:{...r, kind:"article"}, style:S.style}); copyRich(p.html, p.text, "Cita APA copiada. Pégala en tu documento."); }
    catch(e){ toast(e.message); }
  };
  return el;
}
function fillAbstract(el, r){
  const box = el.querySelector(".absbox");
  if (!r.abstract){ box.innerHTML = ""; return; }
  const short = r.abstract.length > 340 ? r.abstract.slice(0, 340).replace(/\s+\S*$/, "") + "…" : r.abstract;
  box.innerHTML = `<p class="abs">${esc(short)}</p>` + (short !== r.abstract ? `<button type="button" class="linkbtn muted" style="font-size:13px">Ver resumen completo</button>` : "");
  const b = box.querySelector("button");
  if (b) b.onclick = () => { const open = b.textContent.startsWith("Ver"); box.querySelector("p").textContent = open ? r.abstract : short; b.textContent = open ? "Ver menos" : "Ver resumen completo"; };
}
function paintSave(btn, saved){
  btn.textContent = saved ? "✓ Guardado en Citados" : "Guardar en Citados";
  btn.classList.toggle("saved", saved);
  btn.classList.toggle("outline", !saved);
}
async function toggleSave(r, btn){
  btn.disabled = true;
  try{
    const res = await api("/api/cited/toggle", {record:r, search_id:S.histId});
    res.saved ? S.cited.add(res.id) : S.cited.delete(res.id);
    r.rid = res.id;
    paintSave(btn, res.saved);
    setCount(res.count);
    toast(res.saved ? "Guardado. Su cita APA está en «Citados»." : "Quitado de Citados.");
    refreshCited(); refreshHist();
  }catch(e){ toast(e.message); }
  btn.disabled = false;
}
function setCount(n){ $("#railCount").textContent = n || ""; $("#topCount").textContent = n; }
</script>
<script>
/* ================================================================ citados */
async function refreshCited(){
  const res = await api("/api/cited?style="+S.style);
  S.citedItems = res.items;
  S.cited = new Set(res.items.map(i=>i.id));
  setCount(res.items.length);
  $("#dlRtf").href = "/api/export?fmt=rtf&style="+S.style;
  $("#dlTxt").href = "/api/export?fmt=txt&style="+S.style;
  return res.items;
}
function markSaved(){ for (const {card, rec} of S.seen.values()) paintSave(card.querySelector(".save"), S.cited.has(rec.rid || recKey(rec))); }
async function renderCited(flashId){
  const items = await refreshCited();
  const nArt = items.filter(c=>c.kind!=="web").length, nWeb = items.length - nArt;
  $("#citedSub").textContent = items.length
    ? `${items.length === 1 ? "1 referencia" : items.length + " referencias"} en APA 7.ª edición, en orden alfabético. Se guardan en tu computadora.`
    : "Tus referencias en APA 7.ª edición, en orden alfabético. Se guardan en tu computadora.";
  $("#typeChips").innerHTML = [["all",`Todas · ${items.length}`],["article",`Artículos · ${nArt}`],["web",`Páginas web · ${nWeb}`]]
    .map(([v,l])=>`<button type="button" data-type="${v}" aria-pressed="${S.typeFilter===v}">${l}</button>`).join("");
  $$("#typeChips button").forEach(b=>b.onclick=()=>{ S.typeFilter=b.dataset.type; renderCited(); });
  const q = $("#citedFilter").value.trim().toLowerCase();
  const shown = items.filter(c => (S.typeFilter==="all" || (S.typeFilter==="web") === (c.kind==="web")) && (!q || c.text.toLowerCase().includes(q)));
  ["#copyAll","#clearAll"].forEach(s=>$(s).disabled = !items.length);
  ["#dlRtf","#dlTxt"].forEach(s=>{ $(s).style.pointerEvents = items.length ? "" : "none"; $(s).style.opacity = items.length ? "" : ".45"; });
  const box = $("#refs");
  if (!items.length){
    box.innerHTML = `<div class="cited-empty">Aún no guardas referencias. Pulsa «Guardar en Citados» en un resultado, o agrega una página web, un DOI o una referencia manual con el panel de la derecha.</div>`;
    return;
  }
  if (!shown.length){ box.innerHTML = `<div class="cited-empty">Ninguna referencia coincide con el filtro.</div>`; return; }
  const origin = c => c.meta.source === "Enlace" ? "Agregado por enlace" : c.meta.source === "DOI (Crossref)" ? "Agregado por DOI"
    : c.meta.source === "Agregado a mano" ? "Agregado a mano" : c.meta.source ? `Guardado desde ${c.meta.source}` : "";
  box.innerHTML = shown.map((c,i)=>`
    <article class="ref${c.id===flashId?" flash":""}" data-id="${esc(c.id)}">
      <div class="meta"><span class="kind${c.kind==="web"?" web":""}">${c.kind==="web"?"Página web":"Artículo"}</span><span>${esc(origin(c))}</span></div>
      <p class="apa">${c.html}</p>
      <div class="row"><span class="it">En el texto: <span>${esc(c.intext)}</span></span>
        <span class="acts">
          <button type="button" class="linkbtn" data-copy="${i}">Copiar cita</button>
          <button type="button" class="linkbtn muted" data-copyin="${i}">Copiar en el texto</button>
          ${c.meta.url ? `<a href="${esc(c.meta.url)}" target="_blank" rel="noopener" style="color:var(--soft)">Abrir</a>` : ""}
          <button type="button" class="linkbtn muted" data-edit="${i}">Editar</button>
          <button type="button" class="linkbtn red" data-rmc="${esc(c.id)}">Quitar</button>
        </span></div>
    </article>`).join("");
  $$("#refs [data-copy]").forEach(b=>b.onclick=()=>{ const c=shown[+b.dataset.copy]; copyRich(c.html, c.text, "Cita copiada. Pégala en tu documento con Ctrl+V (Cmd+V en Mac)."); });
  $$("#refs [data-copyin]").forEach(b=>b.onclick=()=>{ const c=shown[+b.dataset.copyin]; copyRich(esc(c.intext), c.intext, "Cita en el texto copiada."); });
  $$("#refs [data-edit]").forEach(b=>b.onclick=()=>startEdit(shown[+b.dataset.edit]));
  $$("#refs [data-rmc]").forEach(b=>b.onclick=async()=>{ await api("/api/cited/remove",{id:b.dataset.rmc}); toast("Quitado de Citados."); await renderCited(); markSaved(); refreshHist(); });
  if (flashId){ const el = box.querySelector(".flash"); if (el) el.scrollIntoView({block:"nearest", behavior:"smooth"}); }
}
$("#citedFilter").addEventListener("input", debounce(()=>renderCited(), 200));
async function copyRich(html, text, msg){
  try{
    if (window.ClipboardItem && navigator.clipboard && navigator.clipboard.write){
      const wrapped = `<p style="font-family:'Times New Roman',serif;font-size:12pt;margin-left:.5in;text-indent:-.5in">${html}</p>`;
      await navigator.clipboard.write([new ClipboardItem({"text/html":new Blob([wrapped],{type:"text/html"}), "text/plain":new Blob([text],{type:"text/plain"})})]);
    } else await navigator.clipboard.writeText(text);
  }catch{
    const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove();
  }
  toast(msg);
}
$("#copyAll").onclick = () => copyRich(S.citedItems.map(c=>`<p style="margin-left:.5in;text-indent:-.5in">${c.html}</p>`).join(""), S.citedItems.map(c=>c.text).join("\n\n"), "Todas las citas copiadas. Pégalas en tu documento.");
$("#clearAll").onclick = async () => { if (!confirm("¿Quitar todas las referencias guardadas? No se puede deshacer.")) return; await api("/api/cited/clear",{}); await renderCited(); markSaved(); };
$$("[data-style]").forEach(b => b.onclick = () => {
  S.style = b.dataset.style;
  $$("[data-style]").forEach(x=>x.setAttribute("aria-pressed", x.dataset.style===S.style));
  renderCited(); updatePreview();
});

/* ---------- agregar referencias: enlace, DOI o manual ---------- */
$$("[data-add]").forEach(b => b.onclick = () => setAddTab(b.dataset.add));
function setAddTab(t, keepForm){
  S.addTab = t;
  $$("[data-add]").forEach(b=>b.setAttribute("aria-selected", b.dataset.add===t));
  $("#paneLink").hidden = t !== "link"; $("#paneDoi").hidden = t !== "doi"; $("#paneManual").hidden = t !== "manual";
  if (!keepForm){
    setStatus("");
    if (t === "manual") showForm($("#kindSel").value, {});
    else hideForm();
  }
}
$("#kindSel").onchange = () => showForm($("#kindSel").value, collect(true));
function setStatus(msg, kind){ const s = $("#addStatus"); s.textContent = msg; s.className = "status " + (kind||""); }
function hideForm(){ $("#refForm").hidden = true; $("#preview").hidden = true; $("#saveRef").hidden = true; S.formKind = null; }
const FIELDS = {
  web: [
    ["authors_str","Autor (persona u organización)","Personas: Apellido, iniciales; separa varias con punto y coma. Organización: su nombre completo."],
    ["date_str","Fecha de publicación","dd/mm/aaaa, mm/aaaa o solo el año. Vacío si la página no tiene fecha.", "half"],
    ["site","Nombre del sitio","", "half"],
    ["title","Título de la página"],
    ["url","Enlace (URL)"],
    ["changes","La página cambia con frecuencia (agrega «Recuperado el…»)","", "check"]
  ],
  article: [
    ["authors_str","Autores","Apellido, iniciales; separa varios con punto y coma. Ej.: Pérez, J. A.; López, M."],
    ["year","Año","", "third"], ["volume","Volumen","", "third"], ["issue","Número","", "third"],
    ["title","Título del artículo"],
    ["journal","Revista","", "twothirds"], ["pages","Páginas","", "third2"],
    ["doi","DOI","Si no tiene DOI, deja este campo vacío y escribe el enlace abajo."],
    ["url","Enlace (solo si no hay DOI)"]
  ]
};
function showForm(kind, data){
  S.formKind = kind;
  if (S.addTab === "manual") $("#kindSel").value = kind;
  const input = (k, label, hint) => `<div class="fl"><label for="rf-${k}">${label}</label><input class="field-in" id="rf-${k}" data-k="${k}" value="${esc(data[k] ?? "")}">${hint?`<span class="hint">${hint}</span>`:""}</div>`;
  let h = "", buf = [];
  const flush = cls => { if (buf.length){ h += `<div class="${cls}">${buf.join("")}</div>`; buf = []; } };
  for (const [k,label,hint,lay] of FIELDS[kind]){
    if (lay === "check"){ flush("fl2"); h += `<label class="check"><input type="checkbox" data-k="${k}" ${data[k]?"checked":""}> ${label}</label>`; continue; }
    if (lay === "half"){ buf.push(input(k,label,hint)); if (buf.length === 2) flush("fl2"); continue; }
    if (lay === "third"){ buf.push(input(k,label,hint)); if (buf.length === 3) flush("fl3"); continue; }
    if (lay === "twothirds"){ buf.push(`<div style="grid-column:span 2">${input(k,label,hint)}</div>`); continue; }
    if (lay === "third2"){ buf.push(input(k,label,hint)); flush("fl3"); continue; }
    flush("fl2"); h += input(k,label,hint);
  }
  flush("fl2");
  const f = $("#refForm");
  f.innerHTML = h; f.hidden = false; $("#preview").hidden = false; $("#saveRef").hidden = false;
  $("#saveRef").textContent = S.editId ? "Guardar cambios" : "Guardar en Citados";
  f.querySelectorAll("[data-k]").forEach(el => el.addEventListener(el.type === "checkbox" ? "change" : "input", previewLater));
  updatePreview();
}
function collect(raw){
  const out = {};
  $$("#refForm [data-k]").forEach(el => out[el.dataset.k] = el.type === "checkbox" ? el.checked : el.value);
  if (raw) return out;
  const base = {...S.formBase}; delete base.authors; delete base.authors_str; delete base.date_str;
  return {...base, ...out, kind:S.formKind};
}
const previewLater = debounce(()=>updatePreview(), 300);
async function updatePreview(){
  if (!S.formKind) return;
  try{
    const p = await api("/api/apa/preview", {record:collect(), style:S.style});
    $("#prevApa").innerHTML = p.html; $("#prevIn").textContent = p.intext;
    $("#prevNotes").innerHTML = p.notes.map(n=>`<li>${esc(n)}</li>`).join("");
  }catch{}
}
$("#paneLink").onsubmit = async e => {
  e.preventDefault();
  const url = $("#linkIn").value.trim();
  if (!url){ setStatus("Pega primero el enlace de la página.", "err"); return; }
  setStatus("Leyendo la página…", "wait");
  try{
    const r = await api("/api/link", {url});
    S.formBase = r.record;
    showForm(r.kind, r.record);
    setStatus("✓ " + r.note, "ok");
  }catch(err){ setStatus(err.message, "err"); hideForm(); }
};
$("#paneDoi").onsubmit = e => { e.preventDefault(); lookupDoi(); };
async function lookupDoi(){
  const doi = $("#doiIn").value.trim();
  if (!doi){ setStatus("Escribe un DOI, por ejemplo 10.1056/NEJMoa2034577.", "err"); return; }
  setStatus("Buscando el DOI…", "wait");
  try{
    const r = await api("/api/doi", {doi});
    S.formBase = r.fields;
    showForm("article", r.fields);
    setStatus("✓ Encontré el artículo. Revisa los datos y guárdalo.", "ok");
  }catch(err){ setStatus(err.message, "err"); hideForm(); }
}
$("#saveRef").onclick = async () => {
  const rec = collect();
  if (!rec.title && !rec.url && !rec.doi){ setStatus("Falta al menos el título o el enlace.", "err"); return; }
  try{
    const r = await api("/api/cited/add", {record:rec, replace_id:S.editId});
    toast(S.editId ? "Referencia actualizada." : r.replaced ? "Esa referencia ya estaba: la actualicé." : "Agregada a Citados.");
    endEdit(true);
    $("#linkIn").value = ""; $("#doiIn").value = "";
    await renderCited(r.id); markSaved();
  }catch(err){ setStatus(err.message, "err"); }
};
function startEdit(c){
  S.editId = c.id;
  S.formBase = c.meta;
  $("#editNote").hidden = false; $("#addTitle").textContent = "Editar referencia";
  setAddTab("manual", true);
  const m = c.meta, kind = c.kind === "web" ? "web" : "article";
  const d = {...m};
  const ini = x => x.includes(".") ? x : x.replace(/[^A-Za-zÁÉÍÓÚÑÜ-]/g,"").split("-").map(p=>p.split("").join(". ")+".").join("-");
  d.authors_str = (m.authors||[]).map(a => a.collective || !a.initials ? a.family : `${a.family}, ${ini(a.initials)}`).join("; ");
  const mm = +m.month || 0, dd = +m.day || 0;
  d.date_str = m.year ? (mm && dd ? `${String(dd).padStart(2,"0")}/${String(mm).padStart(2,"0")}/${m.year}` : mm ? `${String(mm).padStart(2,"0")}/${m.year}` : m.year) : "";
  showForm(kind, d);
  setStatus("");
  $("#refForm").querySelector("input").focus();
}
function endEdit(clear){
  S.editId = null; S.formBase = {};
  $("#editNote").hidden = true; $("#addTitle").textContent = "Agregar una referencia";
  if (clear){ setAddTab(S.addTab === "manual" ? "manual" : S.addTab); }
}
$("#cancelEdit").onclick = () => { endEdit(true); setStatus(""); };

/* ================================================================ historial */
async function refreshHist(){
  try{ S.hist = (await api("/api/history?style="+S.style)).items; }catch{ S.hist = []; }
  if (S.view === "home") renderHome();
  if (S.view === "hist") renderHist();
}
function dayDiff(ts){
  const d = new Date(ts*1000), n = new Date();
  const a = new Date(d.getFullYear(), d.getMonth(), d.getDate()), b = new Date(n.getFullYear(), n.getMonth(), n.getDate());
  return Math.round((b - a) / 86400000);
}
function whenLabel(ts){
  const d = new Date(ts*1000), dd = dayDiff(ts);
  const hm = d.toLocaleTimeString("es-MX", {hour:"2-digit", minute:"2-digit"});
  if (dd === 0) return `Hoy, ${hm}`;
  if (dd === 1) return `Ayer, ${hm}`;
  if (dd < 7) return d.toLocaleDateString("es-MX", {weekday:"long"}).replace(/^./, c=>c.toUpperCase());
  return d.toLocaleDateString("es-MX", {day:"numeric", month:"short", year: d.getFullYear() === new Date().getFullYear() ? undefined : "numeric"});
}
function groupOf(ts){ const dd = dayDiff(ts); return dd === 0 ? "Hoy" : dd === 1 ? "Ayer" : dd < 7 ? "Esta semana" : "Anteriores"; }
const yrsLabel = h => `${h.y0 || "Sin límite"} – ${h.y1 || "Actual"}`;
const totalOf = h => Object.values(h.totals||{}).reduce((a,b)=>a+b,0);
function renderHist(){
  const q = $("#histFilter").value.trim().toLowerCase();
  const items = S.hist.filter(h => !q || h.text.toLowerCase().includes(q) || (h.concepts||[]).some(c=>c.label.toLowerCase().includes(q)));
  $("#clearHist").hidden = !S.hist.length;
  const list = $("#histList");
  if (!S.hist.length){
    list.innerHTML = `<div class="placeholder"><b>Aún no hay búsquedas.</b> Cada vez que busques, la pregunta, la ecuación y los filtros se guardarán aquí para que puedas repetirla con un clic.</div>`;
    $("#hDetail").innerHTML = ""; $("#hDetail").hidden = true; return;
  }
  $("#hDetail").hidden = false;
  if (!S.histSel || !S.hist.some(h=>h.id===S.histSel)) S.histSel = S.hist[0].id;
  const groups = {};
  items.forEach(h => (groups[groupOf(h.at)] ||= []).push(h));
  list.innerHTML = items.length ? ["Hoy","Ayer","Esta semana","Anteriores"].filter(g=>groups[g]).map(g=>`
    <section class="hgroup"><h2>${g}</h2>${groups[g].map(h=>`
      <button type="button" class="hrow" data-h="${esc(h.id)}" aria-pressed="${h.id===S.histSel}">
        <span class="t"><span class="q">${esc(h.text)}</span><span class="when">${esc(whenLabel(h.at))}</span></span>
        <span class="hchips">${(h.concepts||[]).map(c=>`<span class="hchip k-${esc(c.category)}">${esc(c.label)}</span>`).join("")}</span>
        <span class="facts"><span>${esc(yrsLabel(h))}</span><span>${totalOf(h).toLocaleString("es-MX")} resultados</span><span>${h.saved.length ? (h.saved.length===1?"1 guardado":h.saved.length+" guardados") : "Sin guardados"}</span></span>
      </button>`).join("")}</section>`).join("")
    : `<div class="placeholder">Ninguna búsqueda coincide.</div>`;
  $$("#histList [data-h]").forEach(b=>b.onclick=()=>{ S.histSel = b.dataset.h; renderHist(); });
  renderHistDetail(S.hist.find(h=>h.id===S.histSel));
}
$("#histFilter").addEventListener("input", debounce(renderHist, 150));
function renderHistDetail(h){
  const box = $("#hDetail");
  if (!h){ box.innerHTML = ""; return; }
  const src = (h.sources||[]).map(s=>SRC_NAMES[s]||s).join(", ");
  box.innerHTML = `
    <p class="eyebrow">Detalle de la búsqueda</p>
    <h2 class="q">${esc(h.text)}</h2>
    <div class="muted" style="font-size:13px">${esc(whenLabel(h.at))} · ${esc(yrsLabel(h))} · ${esc(src)}</div>
    <div class="tiles"><div class="tile"><b>${totalOf(h).toLocaleString("es-MX")}</b><span>resultados</span></div>
      <div class="tile"><b>${h.saved.length}</b><span>guardados</span></div>
      <div class="tile"><b>${(h.concepts||[]).length}</b><span>conceptos</span></div></div>
    <div class="fl"><div class="card-head" style="margin:0"><span style="font-size:13px;font-weight:600;color:var(--soft)">Ecuación usada (PubMed)</span><button class="linkbtn" type="button" id="hCopy">Copiar</button></div>
      <pre class="codebox">${highlight(h.query_pubmed||"")}</pre></div>
    ${h.saved.length ? `<div class="fl"><span style="font-size:13px;font-weight:600;color:var(--soft)">Artículos que guardaste</span>
      ${h.saved.map(s=>`<button type="button" class="hsaved" data-go="cited">${esc(s.intext)} ${esc(s.title.length>80?s.title.slice(0,80)+"…":s.title)}</button>`).join("")}</div>` : ""}
    <div class="push" style="margin-top:auto"></div>
    <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn primary" type="button" id="hRepeat" style="flex:1;height:48px">Repetir búsqueda</button>
      <button class="btn" type="button" id="hEdit" style="height:48px">Editar ecuación</button></div>
    <button class="linkbtn red" type="button" id="hDel" style="align-self:flex-start;font-size:13px">Eliminar del historial</button>`;
  $("#hCopy").onclick = () => copyRich(esc(h.query_pubmed), h.query_pubmed, "Ecuación copiada.");
  $("#hRepeat").onclick = () => repeatHist(h, true);
  $("#hEdit").onclick = () => repeatHist(h, false);
  $("#hDel").onclick = async () => { await api("/api/history/remove", {id:h.id}); S.histSel = null; toast("Búsqueda eliminada del historial."); refreshHist(); };
}
$("#clearHist").onclick = async () => { if (!confirm("¿Borrar todo el historial de búsquedas? Tus citados no se borran.")) return; await api("/api/history/clear", {}); refreshHist(); };
async function repeatHist(h, search){
  S.f = {y0:h.y0||"", y1:h.y1||"", src:{pubmed:false, europepmc:false, openalex:false}, langs:h.langs||[], free:!!h.free_only, humans:!!h.humans};
  (h.sources||["pubmed","europepmc","openalex"]).forEach(s => S.f.src[s] = true);
  syncFilters();
  S.text = h.text; S.answers = h.answers || {}; S.skip = true; S.showAnswers = false; S.searched = false;
  $("#ask").value = h.text; $("#ask2").value = h.text;
  clearResults();
  await doTranslate(false);
  if (h.edited && h.edited.pubmed) { S.queries.pubmed = h.query_pubmed; S.edited.pubmed = true; }
  if (h.edited && h.edited.generic) { S.queries.generic = h.query_generic; S.edited.generic = true; }
  lintBoth();
  S.histId = h.id;
  if (search){ go("search"); doSearch(1); } else go("eq");
}

/* ================================================================ modo aplicación (ventana propia) */
const bridge = () => (window.pywebview && window.pywebview.api) ? window.pywebview.api : null;
["#dlRtf","#dlTxt"].forEach(sel => $(sel).addEventListener("click", async e => {
  const b = bridge();
  if (!b || !b.export) return;                        // en el navegador, la descarga normal funciona
  e.preventDefault();
  try{
    const path = await b.export(sel === "#dlRtf" ? "rtf" : "txt", S.style);
    if (path) toast("Guardado en " + path);
  }catch{ toast("No se pudo guardar el archivo."); }
}));
document.addEventListener("click", e => {
  const a = e.target.closest('a[target="_blank"]');
  const b = bridge();
  if (!a || !b || !b.open_url) return;
  e.preventDefault();
  b.open_url(new URL(a.getAttribute("href"), location.href).href);   // artículos y ayuda: en el navegador
});

/* ================================================================ cerrar */
$("#quitBtn").onclick = async () => {
  if (!confirm("¿Cerrar el buscador? Tus citas y tu historial no se pierden.")) return;
  try{ await api("/api/shutdown", {}); }catch{}
  document.body.innerHTML = `<div style="max-width:520px;margin:18vh auto;padding:0 24px;font-family:var(--sans);color:#EDE7DF"><h1 style="font:400 34px var(--serif);margin:0 0 10px">Listo, el buscador se cerró.</h1><p style="color:#A59D93;margin:0">Ya puedes cerrar esta pestaña. Para volver a usarlo, abre el programa con doble clic.</p></div>`;
};

init().catch(()=>{});
</script>
</body>
</html>
"""


if __name__ == "__main__":
    main()
