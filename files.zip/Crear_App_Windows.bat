@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Crear la aplicacion - Buscador Academico
echo.
echo  ================================================================
echo    Crear "Buscador Academico.exe"
echo    La primera vez tarda de 2 a 5 minutos y necesita internet.
echo  ================================================================
echo.

if not exist "BuscadorAcademico.py" goto nofile

set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY goto nopy

echo  [1/4] Preparando un espacio de trabajo aparte...
if not exist ".venv_app\Scripts\python.exe" %PY% -m venv .venv_app || goto venverr
set "VPY=.venv_app\Scripts\python.exe"

echo  [2/4] Descargando las herramientas (PyInstaller, pywebview y Pillow)...
"%VPY%" -m pip install --upgrade pip >nul
"%VPY%" -m pip install --upgrade pyinstaller pywebview pillow || goto piperr

echo  [3/4] Preparando el icono y la guia...
set "ICON=icono.ico"
if not exist "icono.ico" set "ICON=icono.png"
if not exist "%ICON%" "%VPY%" BuscadorAcademico.py --crear-icono
set "GUIDE="
if exist "Instrucciones_de_uso.html" set GUIDE=--add-data "Instrucciones_de_uso.html;."
if not exist "Instrucciones_de_uso.html" echo      Aviso: falta Instrucciones_de_uso.html; la app se creara sin la guia completa.

echo  [4/4] Creando la aplicacion...
"%VPY%" -m PyInstaller --noconfirm --clean --onefile --windowed --name "Buscador Academico" --icon "%ICON%" %GUIDE% BuscadorAcademico.py || goto builderr

if exist "Instrucciones_de_uso.html" copy /y "Instrucciones_de_uso.html" "dist\" >nul
rmdir /s /q build >nul 2>nul
del /q "Buscador Academico.spec" >nul 2>nul
echo.
echo  LISTO. La aplicacion esta en la carpeta "dist":
echo      dist\Buscador Academico.exe
echo  Comparte ese archivo con tus testers (junto con Instrucciones_de_uso.html).
echo.
explorer dist
pause
exit /b 0

:nofile
echo  No encuentro "BuscadorAcademico.py" en esta carpeta.
echo  Pon este archivo en la misma carpeta que BuscadorAcademico.py
echo  (lo mas facil: descomprime BuscadorAcademico.zip y usa esa carpeta).
pause
exit /b 1

:nopy
echo  No encontre Python en esta computadora.
echo  1. Descargalo de https://www.python.org/downloads/
echo  2. Al instalar, marca la casilla "Add python.exe to PATH".
echo  3. Vuelve a hacer doble clic en este archivo.
start "" "https://www.python.org/downloads/"
pause
exit /b 1

:venverr
echo  No se pudo preparar el espacio de trabajo. Reinstala Python desde python.org y vuelve a intentar.
pause
exit /b 1

:piperr
echo.
echo  No se pudieron descargar las herramientas.
echo  - Revisa tu conexion a internet.
echo  - Si tu Python es muy nuevo, instala Python 3.12 o 3.13 desde python.org,
echo    borra la carpeta ".venv_app" y vuelve a intentar.
pause
exit /b 1

:builderr
echo.
echo  Algo fallo al crear la aplicacion. Copia el texto de arriba y envialo a quien te ayuda con el programa.
pause
exit /b 1
